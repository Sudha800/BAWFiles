package com.example.springbootswagger2.controller;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import javax.security.auth.Subject;
import com.filenet.api.collection.ContentElementList;
import com.filenet.api.collection.IndependentObjectSet;
import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.AutoUniqueName;
import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.Connection;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.ReferentialContainmentRelationship;
import com.filenet.api.property.Properties;
import com.filenet.api.query.SearchSQL;
import com.filenet.api.query.SearchScope;
import com.filenet.api.util.Id;
import com.filenet.api.util.UserContext;
import com.ibm.casemgmt.api.Case;
import com.ibm.casemgmt.api.CaseType;
import com.ibm.casemgmt.api.constants.ModificationIntent;
import com.ibm.casemgmt.api.exception.CaseMgmtException;
import com.ibm.casemgmt.api.objectref.ObjectStoreReference;
import com.ibm.casemgmt.api.properties.CaseMgmtProperties;
import com.itextpdf.forms.PdfAcroForm;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.PdfWriter;
public class QuotationRequest {
	private static Connection connection;
	private static Domain domain;
	private static ObjectStore objectStore;
	private static UserContext context;
	public ObjectStore getCeConnection() {
		System.out.println("ExecutableClass.getCeConnection()");
		String ceUri = "http://wf-dc-poc.ibm.edu:9080/wsi/FNCEWS40MTOM/";
		String userName = "admin";
		String password = "passw0rd";
		connection = Factory.Connection.getConnection(ceUri);
		Subject subject = UserContext.createSubject(connection, userName, password, null);
		context = UserContext.get();
		context.pushSubject(subject);
		domain = Factory.Domain.getInstance(connection, null);
		objectStore = Factory.ObjectStore.fetchInstance(domain, "tos", null);
		System.out.println(objectStore.get_SymbolicName());
		System.out.println(objectStore.get_DisplayName() + "\t" + objectStore.get_DatabaseSchemaName());
		return objectStore;
	}

	public void retrieveDocument(String folderPath) throws Exception {
		String documentClass="RequestQuotation";
		String METHOD_NAME = "retrieveDocument";
		System.out.println(METHOD_NAME);
		ObjectStore targetOS = getCeConnection();
		ObjectStoreReference targetOsRef = new ObjectStoreReference(targetOS);
		String passingQuery = "SELECT * from " + documentClass + " where DocumentTitle='RequestQuotation.pdf'";
		System.out.println("Template retrieval Query : " + passingQuery);
		SearchScope searchScope = new SearchScope(targetOS);
		SearchSQL searchSQL = new SearchSQL(passingQuery);
		IndependentObjectSet independentObjectSet = searchScope.fetchObjects(searchSQL, new Integer(10), null, new Boolean(true));
		if (!(independentObjectSet.isEmpty())) {
			Iterator<Document> iterator = independentObjectSet.iterator();
			while (iterator.hasNext()) {
				Document document = iterator.next();
				Properties properties = document.getProperties();
				ContentElementList contentElementList = document.get_ContentElements();
				Iterator<ContentTransfer> itr = contentElementList.iterator();
				while (itr.hasNext()) {
					ContentTransfer ct = itr.next();
					InputStream stream = ct.accessContentStream();
					ByteArrayOutputStream bout = new ByteArrayOutputStream();
					byte[] buffer = new byte[4096000];
					int bytesRead = 0;
					while ((bytesRead = stream.read(buffer)) != -1) {
						bout.write(buffer, 0, bytesRead);
					}
					// writing to the pdf
					manipulatePdf(targetOS, bout.toByteArray(), targetOsRef,documentClass,folderPath);
					stream.close();
				}
			}
		} else {
			System.out.println("Document search is not happening, please check the document class and Title of the document in the query.");
		}
	}

	private void manipulatePdf(ObjectStore objectStore, byte[] byteArr, ObjectStoreReference objectStoreReference,String documentClass,String folderPath) {

		String METHOD_NAME = "manipulatePdf";
		System.out.println(METHOD_NAME);
		// Initialize PDF document
		ByteArrayOutputStream bout = new ByteArrayOutputStream();
		PdfDocument pdf;
		try {
			pdf = new PdfDocument(new PdfReader(new ByteArrayInputStream(byteArr)), new PdfWriter(bout));
			PdfAcroForm form = PdfAcroForm.getAcroForm(pdf, true);
			Folder folder1=Factory.Folder.fetchInstance(objectStore,  new Id("{10FC3471-0000-C717-89BA-159ECB188384}"), null);
		    System.out.println("folder:"+folder1.get_FolderName());
		    
		    form.getFormFields().get("firstName").setValue("John").setFontSizeAutoScale();
			form.getFormFields().get("lastName").setValue("Mike").setFontSizeAutoScale();
			form.getFormFields().get("dob").setValue("12/04/2010").setFontSizeAutoScale();
			form.getFormFields().get("ssn").setValue("123").setFontSizeAutoScale();
			form.getFormFields().get("email").setValue("john@gmail.com").setFontSizeAutoScale();
			pdf.close();
			getCasePropertiesFromCase(objectStoreReference, "DEMO_StartApplication_000000110003", "Test");
			fileToCaseFolder(objectStore, bout, folderPath, documentClass);
		} catch (IOException e) {
			System.out.println("Exception Occured!");
			System.err.println(e.getMessage());
			System.out.println(e.getMessage());
		}
	}

	private void fileToCaseFolder(ObjectStore objectStore, ByteArrayOutputStream bout, String folderPath, String documentClass) {
		String METHOD_NAME = "fileToCaseFolder";
		System.out.println(METHOD_NAME);
		try {
			Document document = Factory.Document.createInstance(objectStore, documentClass);
			ContentElementList contentList = Factory.ContentElement.createList();
			ContentTransfer content = Factory.ContentTransfer.createInstance();
			InputStream is = new ByteArrayInputStream(bout.toByteArray());
			content.setCaptureSource(is);
			contentList.add(content);
			document.set_ContentElements(contentList);
			document.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
			Properties properties = document.getProperties();
			properties.putValue("DocumentTitle", "Request Quotation");
			document.set_MimeType("application/pdf");
			document.save(RefreshMode.REFRESH);
			System.out.println("Filing PDF file to : " + folderPath);

			Folder folder = Factory.Folder.fetchInstance(objectStore, new Id(folderPath), null);
			//Folder folder = Factory.Folder.fetchInstance(objectStore, folderPath, null);
			ReferentialContainmentRelationship ref = folder.file(document, AutoUniqueName.AUTO_UNIQUE, "Testing", null);
			ref.save(RefreshMode.REFRESH);
			System.out.println("PDF filed in CaseFolder.");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	public void getCasePropertiesFromCase(ObjectStoreReference objectStoreReference, String caseIdentifier,String caseType) {
		System.out.println("QuotationRequest.getCasePropertiesFromCase()");
	}
	public static void main(String[] args) {
		QuotationRequest quotationRequest = new QuotationRequest();
		try {
			quotationRequest.retrieveDocument("{A0592B71-0000-C61C-B30A-4429140E4752}");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}