/*
 * package com.example.springbootswagger2.controller;
 * 
 * import java.util.ArrayList; import java.util.Date;
 * 
 * 
 * import java.util.List; import java.util.stream.Collectors;
 * 
 * import org.apache.commons.json.JSONObject; import
 * org.springframework.web.bind.annotation.PathVariable; import
 * org.springframework.web.bind.annotation.RequestBody; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RequestMethod; import
 * org.springframework.web.bind.annotation.RequestParam; import
 * org.springframework.web.bind.annotation.ResponseBody; import
 * org.springframework.web.bind.annotation.RestController;
 * 
 * import com.example.springbootswagger2.model.DocDetailsJson; import
 * com.example.springbootswagger2.model.PathJson; import
 * com.example.springbootswagger2.model.Student; import com.google.gson.Gson;
 * 
 * import io.swagger.annotations.Api; import
 * io.swagger.annotations.ApiModelProperty; import
 * io.swagger.annotations.ApiOperation; import
 * io.swagger.annotations.ApiResponse; import
 * io.swagger.annotations.ApiResponses;
 * 
 * @Api(value = "Swagger2DemoRestController", description =
 * "REST Apis related to Student Entity!!!!")
 * 
 * @RestController public class controller_bkp {
 * 
 * List<Student> students = new ArrayList<Student>(); { students.add(new
 * Student("Sajal", "IV", "US")); students.add(new Student("Lokesh", "V",
 * "India")); students.add(new Student("Kajal", "III", "USA")); students.add(new
 * Student("Sukesh", "VI", "USA")); } //Student std=new Student();
 * 
 * ExecutableClass ec=new ExecutableClass();
 * 
 * String documentClass; String caseID;
 * 
 * 
 * 
 * @ApiOperation(value = "AttachPdf to Case", response = Student.class, tags =
 * "getAttachPdf")
 * 
 * @RequestMapping(value = "/getAttachPdf/{documentClass}"
 * ,method=RequestMethod.GET ,produces= {"application/json"})
 * 
 * public void getAttachPdf(@PathVariable(value = "documentClass") String
 * documentClass) throws Exception { System.out.println("in attach pdf"); Gson
 * gson = new Gson(); System.out.println("folderPath:"+folderPath); //String
 * folderPath1=folderPath; ec.retrieveDocument(documentClass, folderPath);
 * 
 * String objstrng = "Completed successfully"; String objjson=
 * gson.toJson(objstrng);
 * 
 * //return objjson; }
 * 
 * @ApiOperation(value = "Get specific Student in the System ",tags =
 * "DemoMethod")
 * 
 * @RequestMapping(value = "/DemoMethod" ,
 * method=RequestMethod.POST,consumes={"application/json"},produces=
 * {"application/json"}) public void DemoMethod(@RequestBody PathJson jsonData)
 * throws Exception{ String folderpath=fPath.getfPath(); String
 * Fname=fPath.getFname();
 * 
 * ec.retrieveDocument(jsonData);
 * 
 * }
 * 
 * @ApiOperation(value = "Get specific Student in the System ",tags =
 * "DemoMethod")
 * 
 * @RequestMapping(value =
 * "/DemoMethod/{fID}/{fname}/{lname}/{ssn}/{email}/{beneName}/{beneType}/{beneAmount}/{brokerName}"
 * , method=RequestMethod.POST,produces= {"application/json"})
 * 
 * @ResponseBody public DocDetailsJson DemoMethod(@PathVariable(value = "fID")
 * String fID,@PathVariable(value = "fname") String fname,@PathVariable(value =
 * "lname") String lname,@PathVariable(value = "ssn") String ssn,
 * 
 * @PathVariable(value = "email") String email,@PathVariable(value = "beneName")
 * String beneName,@PathVariable(value = "beneType") String
 * beneType,@PathVariable(value = "beneAmount") float
 * beneAmount,@PathVariable(value = "brokerName") String brokerName) throws
 * Exception{
 * 
 * DocDetailsJson DocDetails=new DocDetailsJson(); JSONObject jsonOutput = new
 * JSONObject();
 * 
 * jsonOutput= ec.retrieveDocument(fID, fname,
 * lname,ssn,email,beneName,beneType,beneAmount,brokerName); String
 * documentPath=jsonOutput.get("documentPath").toString(); String
 * docID=jsonOutput.get("documentId").toString();
 * 
 * DocDetails.setDocPath(documentPath); DocDetails.setDocID(docID);
 * 
 * 
 * 
 * 
 * System.out.println("Swagger2DemoRestController.DemoMethod()"+jsonOutput.get(
 * "documentPath")+"\t"+jsonOutput.get("documentId")); return DocDetails;
 * 
 * }
 * 
 * @ApiOperation(value = "Get specific Student in the System ",tags =
 * "DemoMethod")
 * 
 * @RequestMapping(value =
 * "/DemoMethod/{fID}/{fName}/{lName}/{ssn}/{date}/{amount}" ,
 * method=RequestMethod.POST,produces= {"application/json"}) public void
 * DemoMethod(@PathVariable(value = "fID") String fID,@PathVariable(value =
 * "fName") String fName,@PathVariable(value = "lName") String lName,
 * 
 * @PathVariable(value = "ssn") String ssn,@PathVariable(value = "date") String
 * date,@PathVariable(value = "amount") String amount) throws Exception{ //
 * String folderpath=fPath.getfPath();
 * 
 * System.out.println("in Demo method"); ec.retrieveDocument(fID, fName,
 * lName,ssn, date,amount);
 * 
 * }
 * 
 * @ApiOperation(value = "Get list of Students in the System ", response =
 * Iterable.class, tags = "getStudents")
 * 
 * @ApiResponses(value = {
 * 
 * @ApiResponse(code = 200, message = "Suceess|OK"),
 * 
 * @ApiResponse(code = 401, message = "not authorized!"),
 * 
 * @ApiResponse(code = 403, message = "forbidden!!!"),
 * 
 * @ApiResponse(code = 404, message = "not found!!!") })
 * 
 * @RequestMapping(value = "/getStudents" ,method=RequestMethod.GET ,produces=
 * {"application/json"}) public List<Student> getStudents() {
 * System.out.println("getStudents"); return students; }
 * 
 * @ApiOperation(value = "Get specific Student in the System ", response =
 * Student.class, tags = "getStudent")
 * 
 * @RequestMapping(value = "/getStudent/{name}" ,
 * method=RequestMethod.GET,produces= {"application/json"}) public Student
 * getStudent(@PathVariable(value = "name") String name) {
 * System.out.println("in getstudentName"); return students.stream().filter(x ->
 * x.getName().equalsIgnoreCase(name)).collect(Collectors.toList()).get(0); }
 * 
 * @ApiOperation(value = "Get specific Student By Country in the System ",
 * response = Student.class, tags = "getStudentByCountry")
 * 
 * @RequestMapping(value = "/getStudentByCountry/{country}"
 * ,method=RequestMethod.GET, produces= {"application/json"}) public
 * List<Student> getStudentByCountry(@PathVariable(value = "country") String
 * country) { System.out.println("Searching Student in country : " + country);
 * List<Student> studentsByCountry = students.stream().filter(x ->
 * x.getCountry().equalsIgnoreCase(country)) .collect(Collectors.toList());
 * System.out.println("in studentsByCountry"); return studentsByCountry; }
 * 
 * @ApiOperation(value = "Get specific Student By Class in the System ",response
 * = Student.class,tags="getStudentByClass")
 * 
 * @RequestMapping(value = "/getStudentByClass/{cls}",method=RequestMethod.GET,
 * produces= {"application/json"}) public List<Student>
 * getStudentByClass(@PathVariable(value = "cls") String cls) {
 * System.out.println("in get student by class"); return
 * students.stream().filter(x ->
 * x.getCls().equalsIgnoreCase(cls)).collect(Collectors.toList()); }
 * 
 * }
 */