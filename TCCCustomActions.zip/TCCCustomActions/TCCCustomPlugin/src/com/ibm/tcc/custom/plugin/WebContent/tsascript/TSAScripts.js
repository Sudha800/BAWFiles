require(["dojo/_base/lang",
         "ecm/model/SearchCriterion"], function(lang, Criterion){
      console.log("TSAScriptPlugin Scripts file loaded");
      lang.setObject("TSAScripts", {
            "passthrough": function(payload, solution, role, scriptAdaptor){
                  return payload;
            },
            
            testMethod:function(payload){debugger;
            }
      




      });
});
