package com.ibm.tcc.custom.plugin;
import java.util.Locale;
import com.ibm.ecm.extension.Plugin;
import com.ibm.ecm.extension.PluginAction;

public class TCCCustomPlugin extends Plugin {

	@Override
	public String getId() {
		return "TCCCustomPlugin";
	}

	@Override
	public String getName(Locale arg0) {
		return "IBM Case Manager TCC Custom plug-in";
	}

	@Override
	public String getVersion() {
		return "1.0.0";
	}

	@Override
	public PluginAction[] getActions() {
		return new PluginAction[] {
			new com.ibm.tcc.custom.plugin.actions.TCCBulkCaseCreationAction(),
			
		};
	}

	@Override
	public String getScript() {
		return "TCCCustomPlugin.js";
	}

	@Override
	public String getDojoModule() {
		return "tsascript";
	}


}
