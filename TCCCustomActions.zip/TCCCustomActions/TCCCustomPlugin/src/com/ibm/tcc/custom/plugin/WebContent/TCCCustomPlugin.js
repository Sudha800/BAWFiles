var tccContextRoot = "/TCCCustomActions";
var paths = {
	"tcccustom": tccContextRoot + "/tcccustom"
};
require({paths:paths});

require([
	"dojo/_base/declare",
	"dojo/_base/lang",
	 "tsascript/TSAScripts"
], function(declare, lang, scripts) {
	/**
	 * Use this function to add any global JavaScript methods your plug-in requires.
	 */console.log("TSA Scripts");

});



