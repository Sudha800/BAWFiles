package com.metlife.CEOperations.documentFiling;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.security.auth.Subject;

import org.apache.log4j.Logger;

import com.filenet.api.constants.RefreshMode;
import com.filenet.api.constants.TypeID;
import com.filenet.api.core.Connection;
import com.filenet.api.core.Domain;
import com.filenet.api.core.EntireNetwork;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.util.Id;
import com.filenet.api.util.UserContext;
import com.ibm.casemgmt.api.context.CaseMgmtContext;
import com.ibm.casemgmt.api.context.SimpleP8ConnectionCache;
import com.ibm.casemgmt.api.context.SimpleVWSessionCache;
import com.ibm.casemgmt.api.objectref.ObjectStoreReference;
import com.ibm.casemgmt.api.properties.CaseMgmtProperties;
import com.ibm.casemgmt.api.properties.CaseMgmtProperty;
import com.ibm.casemgmt.api.tasks.Task;
import com.metlife.CEOperations.documentFiling.Constants.IConstants;
import com.metlife.CEOperations.documentFiling.Constants.ILoggerConstants;
import com.metlife.CEOperations.documentFiling.Exceptions.EDMCaseOperationsException;
import com.metlife.CEOperations.documentFiling.Util.DocumentFilingUtil;
import filenet.vw.api.VWSession;
import filenet.vw.integrator.CMUserContext;
import filenet.vw.server.Configuration;
import filenet.vw.server.VWLoginModule;

public class EDMCaseOperationsImpl {

    private static final Logger LOGGER =Logger.getLogger(EDMCaseOperationsImpl.class);

    public static boolean log4jInitFlag=false;
    public EDMCaseOperationsImpl() throws Exception {
        
        if (!log4jInitFlag) {
            DocumentFilingUtil.loadLog4j();
            log4jInitFlag = true;
        }

        
    }
      private ObjectStore getConnection() throws Exception {
  
           String METHOD_NAME = "getConnection";
           DocumentFilingUtil.logtheMessage(LOGGER,
                   ILoggerConstants.LOGGER_LEVEL_INFO,
                   ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
            UserContext old = UserContext.get();
            CaseMgmtContext oldCmc = null;
            Subject sub = CMUserContext.getSubject();
            String ceURI = null;
            try {
                VWSession vwSession = VWLoginModule.getSession();
                String OSSymbolicName = vwSession.getObjectStoreSymbolicName();
                ceURI = Configuration.GetCEURI(null, null);
                Connection connection = Factory.Connection.getConnection(ceURI);
                UserContext uc = new UserContext();
                uc.pushSubject(sub);
                UserContext.set(uc);
                EntireNetwork entireNetwork = Factory.EntireNetwork.fetchInstance(
                        connection, null);
                if (entireNetwork == null) {
                    Exception e = new Exception();
                    throw e;
                }

                Domain domain = entireNetwork.get_LocalDomain();
                ObjectStore targetOS = (ObjectStore) domain.fetchObject(
                        IConstants.OBJECT_STORE, OSSymbolicName, null);
                SimpleVWSessionCache vwSessCache = new SimpleVWSessionCache();
                CaseMgmtContext cmc = new CaseMgmtContext(vwSessCache,
                        new SimpleP8ConnectionCache());

                oldCmc = CaseMgmtContext.set(cmc);
                return targetOS;
            } catch (Exception e) {
          
                LOGGER.error(e);
                throw new EDMCaseOperationsException(e);

            } finally {
                if (oldCmc != null) {
                    CaseMgmtContext.set(oldCmc);
                }
                if (old != null) {
                    UserContext.set(old);
                }
                DocumentFilingUtil.logtheMessage(LOGGER,
                        ILoggerConstants.LOGGER_LEVEL_INFO,
                        ILoggerConstants.METHOD_EXIT + METHOD_NAME);
            }
      }

      private String[] getTaskPropertyNames(String taskId, String[] customProperties, ObjectStore targetOS) throws Exception
      {
          String METHOD_NAME = "getTaskPropertyNames";
          DocumentFilingUtil.logtheMessage(LOGGER,
                  ILoggerConstants.LOGGER_LEVEL_INFO,
                  ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
          String[] taskProperties=null;
          Boolean flag=true;
          try{
      
          ObjectStoreReference targetOsRef = new ObjectStoreReference(targetOS);
          Task task = Task.fetchInstance(targetOsRef, new Id(taskId));
          CaseMgmtProperties taskProps = task.getProperties();
          
          List lst = taskProps.asList();
          Iterator it = lst.iterator();
          ArrayList taskPropNames = new ArrayList();
          while (it.hasNext())
          {
              flag=true;
            CaseMgmtProperty f = (CaseMgmtProperty)it.next();
            if ((!f.isSystemOwned()) && (!f.isInherited()))
            {
                for (String customProperty : customProperties) {
                    if(f.getSymbolicName().equals(customProperty))
                    {
                        flag=false;
                    }
                }
                
                if(flag){
                          if ((f.getPropertyType() == TypeID.BOOLEAN) || (f.getPropertyType() == TypeID.DATE) || (f.getPropertyType() == TypeID.DOUBLE) || (f.getPropertyType() == TypeID.STRING) || (f.getPropertyType() == TypeID.LONG))
                          {
                            taskPropNames.add(f.getSymbolicName());
                          }
                }
            }
          }
          taskProperties = new String[taskPropNames.size()];
          taskPropNames.toArray(taskProperties);
          DocumentFilingUtil.logtheMessage(LOGGER,
                  ILoggerConstants.LOGGER_LEVEL_INFO,
                  "Task Properties are obtained");
      }
          catch(Exception e){

              LOGGER.error(e);
              throw new EDMCaseOperationsException(e);
          }
          DocumentFilingUtil.logtheMessage(LOGGER,
                  ILoggerConstants.LOGGER_LEVEL_INFO,
                  ILoggerConstants.METHOD_EXIT + METHOD_NAME);
 
        return taskProperties;
      }


      public void copyPropertiesFromParentTask(String taskId,String []customProperties ,String allParentId) throws Exception
      {
          String METHOD_NAME = "copyPropertiesFromParentTask";
          DocumentFilingUtil.logtheMessage(LOGGER,
                  ILoggerConstants.LOGGER_LEVEL_INFO,
                  ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
          try{
          ObjectStore targetOS=getConnection();
          ObjectStoreReference targetOsRef = new ObjectStoreReference(targetOS);

          Task task = Task.fetchInstance(targetOsRef, new Id(taskId));
          CaseMgmtProperties taskProps = task.getProperties();
          CaseMgmtProperty property = taskProps.get(allParentId);
          String value = (String)property.getValue();
          DocumentFilingUtil.logtheMessage(LOGGER,
                  ILoggerConstants.LOGGER_LEVEL_INFO,
                  "AllParentId value : "+value);
          if(value!=null||value!="null"||value!="")
          {
              task.setUpdateSequenceNumber(null);
              task.save(RefreshMode.REFRESH);
              String[] parentTaskId=value.split(",");
              String immediateParentId=parentTaskId[parentTaskId.length-1];
              DocumentFilingUtil.logtheMessage(LOGGER,
                      ILoggerConstants.LOGGER_LEVEL_INFO,
                      "Immediate ParentId value : "+immediateParentId);
              String[] taskPropertyNames = getTaskPropertyNames(immediateParentId,customProperties,targetOS);
              Task parentTask = Task.fetchInstance(targetOsRef, new Id(immediateParentId));
              CaseMgmtProperties parentTaskProps = parentTask.getProperties();
              
              for (String taskProperty : taskPropertyNames) {
                  taskProps.get(taskProperty).setObjectValue(parentTaskProps.get(taskProperty).getValue());
            }
              DocumentFilingUtil.logtheMessage(LOGGER,
                      ILoggerConstants.LOGGER_LEVEL_INFO,
                      "Properties are copied from parent task to child task");
              task.save(RefreshMode.REFRESH);

          }
          }
          catch(Exception e)
          {
              LOGGER.error(e);
              throw new EDMCaseOperationsException(e);
          }
          DocumentFilingUtil.logtheMessage(LOGGER,
                  ILoggerConstants.LOGGER_LEVEL_INFO,
                  ILoggerConstants.METHOD_EXIT + METHOD_NAME);
      }
/*    public static void main(String[] args) throws Exception {
        
        EDMCaseOperationsImpl caseOperations;
        try {
            caseOperations = new EDMCaseOperationsImpl();
            String [] customProperties={"DM_ReOpen","DM_TaskStatus","DM_TaskSubStatus","DM_CaseStatus","DM_AllParentId","DM_TaskStep"};
            caseOperations.copyPropertiesFromParentTask("{00FA7D51-5623-4C79-8EBC-FAFB9A71DD53}",customProperties,"DM_AllParentId");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        
    }*/

}
