package com.metlife.CEOperations.documentFiling.Exceptions;

public class MetCaseOperationsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String message;

	public MetCaseOperationsException(){
		
		super();
		
			
	}
	
	public MetCaseOperationsException(String message){
		
		super(message);
		this.message = message;
	}
	
	public MetCaseOperationsException(Throwable cause){
		
		super(cause);
	}
	
	@Override
    public String toString() {

        return message;

    }

 

    @Override
    public String getMessage() {

        return message;

    }

}
