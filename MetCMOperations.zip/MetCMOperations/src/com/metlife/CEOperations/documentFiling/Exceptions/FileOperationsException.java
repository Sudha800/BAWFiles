package com.metlife.CEOperations.documentFiling.Exceptions;

/**
 * Handles all File related operations exceptions
 * @author Cognizant
 *
 */
public class FileOperationsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String message;

	public FileOperationsException(){
		
		super();
		
			
	}
	
	public FileOperationsException(String message){
		
		super(message);
		this.message = message;
	}
	
	public FileOperationsException(Throwable cause){
		
		super(cause);
	}
	
	@Override
    public String toString() {

        return message;

    }

 

    @Override
    public String getMessage() {

        return message;

    }

}
