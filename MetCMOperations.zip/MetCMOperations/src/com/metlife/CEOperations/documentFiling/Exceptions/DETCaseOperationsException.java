package com.metlife.CEOperations.documentFiling.Exceptions;

public class DETCaseOperationsException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private String message;

    public DETCaseOperationsException(){
        
        super();
        
            
    }
    
    public DETCaseOperationsException(String message){
        
        super(message);
        this.message = message;
    }
    
    public DETCaseOperationsException(Throwable cause){
        
        super(cause);
    }
    
    @Override
    public String toString() {

        return message;

    }

 

    @Override
    public String getMessage() {

        return message;

    }

}
