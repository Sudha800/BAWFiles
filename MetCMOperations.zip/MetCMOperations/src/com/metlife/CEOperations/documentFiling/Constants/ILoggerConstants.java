package com.metlife.CEOperations.documentFiling.Constants;

public interface  ILoggerConstants {
    
    
    String COMPLETE_INDEXING="Valid documents are moved into primary case and created a new case for invalid documents";
    String LOGIN_ERROR="Cannot log in to";
    String MANAGER_TO_EXAMINER="Invalid documents are moved to Research Queue";
    String TERMINATE_CASE="Deleted case with ID :";
    String FILING_INVALIDDOCUMENTS="Filed all the invalid documents to the Invalidcase";
    String FILING_VALIDDOCUMENTS="Valid documents are copied from indexing to digital claim";
    String CREATE_NEW_CASE="New Case with created with ID :";
    String DOCUMENT_FILING="Document filed into target case and deleted from existing case";
    String ADD_ATTACHMENTS_TO_CASE = "Copied the case properties into document";
    String SOURCE_ID="sourceCaseFolderId :";
    String VALID_ID="validDocuments ID :";
    String INVALID_ID="inValidDocument ID :";
    String SQL_SELECT="SELECT Id FROM ";
    String SQL_WHERE=" where ";
    String FILENOTFOUND_ERROR="File does not exist";
    String METHOD_ENTRY="Entering Method:";
    String METHOD_EXIT="Exiting Method:";
    int LOGGER_LEVEL_TRACE=0;
    int LOGGER_LEVEL_DEBUG=1;
    int LOGGER_LEVEL_INFO=2;
    int LOGGER_LEVEL_ERROR=3;



}
