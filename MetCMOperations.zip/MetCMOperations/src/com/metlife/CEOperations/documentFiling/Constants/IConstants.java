package com.metlife.CEOperations.documentFiling.Constants;

import java.io.File;

import com.metlife.CEOperations.documentFiling.Util.DocumentFilingUtil;

public interface IConstants {

    String JVM_CONFIG_VAR="IDI_CONFIGURATION";
    String CONFIG_DEFAULT_PATH=File.separator + "app" + File.separator
            + "IBM" + File.separator + "IDIConfiguration";
    String FOLDER_NAME=File.separator+"MetCaseOperations";
    String PROP_FILE=File.separator+"MetCaseOperations.properties";
    String LOG_FILE=File.separator+"log4j.properties";
    String VALID="valid";
    String INVALID="Invalid";
    String CLAIM_INDEXING="ClaimIndexing";
    String CLAIM_PROCESSING="ClaimProcessing";
    String OBJECT_STORE="ObjectStore";
    String DOCUMENTTITLE = "DocumentTitle";
    String DATECREATED = "DateCreated";
    String PRODDATECHECK = "MM/dd/yyyy HH:mm:ss"; 
    String PRODUCTIONDATE="IDIPhase12deploymentDate"; 
    String FIELDREFERRALDEPLOYMENTDATE= "FieldReferralDeploymentdate";
    String UTC_DATEFORMAT = "MM/dd/yyyy";
    String DATEFORMAT="yyyy-MM-dd-HHmmssSSS";
    String ATT_DOCUMENT_CLASS="IDI_ClaimAttachments";
    String ORIGNALASSOCCASE = "IDI_OriginalAssociatedCase";
    String ASSOCIATEDCASE = "CmAcmAssociatedCase";
    String DOCUMENTSCANNEDDATE="IDI_DocumentScannedDateandTime";
    String INDEXINGCASEFOLDERID = "IDI_IndexingCaseFolderID";
    String TIMEZONE="America/New_York";
    String SOURCE="IDI_Source"; 
    String INTERNAL_REFERRAL_FORM="Internal Referral Form";
    String DUPLICATE="IDI_Duplicate";
    String PROPERTIESLIST="propertieslist";
    String CASECOMMENTVALUE="casecommentvalue";
    String ASSOCIATEDCLAIMNUMBERS = "IDI_AssociatedClaimsNumbers";
    String CLAIMNUMBER = "IDI_UDSClaimNumber";
    String TASKPROPARRAY = "taskPropArray";
    String CLAIMREVIEWNAME = "Claim Review";
    String NEWCLAIMSETUPNAME = "New Claim Setup";
    String UDSSTATUSCODE = "IDI_UDSStatusCode";
    String ACTION= "IDI_Action";
    String REQUESTDATE = "IDI_ReviewerRequestDate";
    String CONSULTANT = "IDI_ReferralConsultant";
    String CMDATEFORMAT = "E MMM dd HH:mm:ss Z yyyy";
    String INBOX= "Inbox(0)";
    String EVENTQUERY="eventquery";
    String WINNINGTASKQUERY= "winningtaskquery";
    String LOSINGTASKQUERY = "losingtaskquery";
    String DELETEEVENT="deleteEvents";
    String DELETECASEORTASK = "deleteCaseorTask";
    String COPYCASEPROPS= "copyCaseprops";
    String YESVALUE= "Y";
    String DUPLICATECLAIMCOMMENT="Claim is Merge due to Duplicate Claims Found";
    String COMMENTDATE = "MM/dd/yyyy,hh:mm a";
    String REFERALTEMPLATES= "referaltemplateList";
    String DUPLICATECASEPROPERTY="IDI_QueueDate";
    String REFERALTEMPLATESPHASE14="referaltemplateListPhase14";
    String PRODUCTIONDATEPHASE14="IDIPhase14deploymentDate";
    String INDEXINGCASETYPE="IDI_ClaimIndexing";
    String DOCUMENTNOTES = "IDI_DocumentNotes";
}
