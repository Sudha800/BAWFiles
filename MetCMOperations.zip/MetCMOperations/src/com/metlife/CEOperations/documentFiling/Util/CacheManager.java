package com.metlife.CEOperations.documentFiling.Util;



import java.util.Properties;




/**
 * Handles Cache need
 * @author Cognizant
 *
 */
public class CacheManager {
    private CacheManager(){
        
    }

    public static Properties properties;
    public static boolean log4jInitFlag;
 
    public static Properties getProperties() {
        return properties;
    }
    public static void setProperties(Properties properties) {
        CacheManager.properties = properties;
    }
   
    
}
