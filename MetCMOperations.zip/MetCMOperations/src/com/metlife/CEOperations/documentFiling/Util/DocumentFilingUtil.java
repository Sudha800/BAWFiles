package com.metlife.CEOperations.documentFiling.Util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.TimeZone;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.metlife.CEOperations.documentFiling.Constants.IConstants;
import com.metlife.CEOperations.documentFiling.Constants.ILoggerConstants;
import com.metlife.CEOperations.documentFiling.Exceptions.FileOperationsException;


public class DocumentFilingUtil {
 private DocumentFilingUtil(){
        
    }
    private static final Logger LOGGER = Logger
            .getLogger(DocumentFilingUtil.class);

    /**
     * Method used to switch between logger levels and to make the respective
     * logger level enabled
     * 
     * 
     */
    public static void logtheMessage(Logger logger,int logLevel,String message){
        
        switch (logLevel) {
        case ILoggerConstants.LOGGER_LEVEL_TRACE:
               
               if(logger.isTraceEnabled()){
                     logger.trace(message);
               }

               break;

        case ILoggerConstants.LOGGER_LEVEL_INFO:
               
               if(logger.isInfoEnabled()){
                     logger.info(message);
               }

               break;

        case ILoggerConstants.LOGGER_LEVEL_DEBUG:
               if(logger.isDebugEnabled()){
                     logger.debug(message);
               }

               break;

        default:
               break;
        }
 }
    /**
     * Method used to load the log4j.properties file
     * 
     * @throws Exception
     * 
     */
    public static void loadLog4j() throws FileNotFoundException{
     
        String configFolderLocation=System.getProperty(IConstants.JVM_CONFIG_VAR);
        if(configFolderLocation!=null){
        configFolderLocation=configFolderLocation+IConstants.FOLDER_NAME;
        } else
        {
            configFolderLocation=IConstants.CONFIG_DEFAULT_PATH+IConstants.FOLDER_NAME;
        }
               String log4jProp = configFolderLocation+IConstants.LOG_FILE;
               File log4jFile = new File(log4jProp);
               if (log4jFile.exists()) {
                     PropertyConfigurator.configure(log4jProp);
               } else {
                     throw new FileNotFoundException(ILoggerConstants.FILENOTFOUND_ERROR);
               }
        }
    
    public static void loadMetCMProperties() throws FileOperationsException{
        
        final String methodName="loadMetCMProperties";
    
        LOGGER.info("Entering method:"+methodName);
            String configFolderLocation = System
                    .getProperty(IConstants.JVM_CONFIG_VAR);
            if (configFolderLocation != null) {
                
                configFolderLocation = configFolderLocation+File.separator
                        + IConstants.FOLDER_NAME;
            } else {
                
                configFolderLocation = IConstants.CONFIG_DEFAULT_PATH+File.separator
                        + IConstants.FOLDER_NAME;
            }
            String propFile = configFolderLocation +File.separator+ IConstants.PROP_FILE;
            CacheManager.properties=DocumentFilingUtil
                    .loadPropertyFile(propFile);
            LOGGER.info("Exiting method:"+methodName);
            
        
    }
    
    public static Properties loadPropertyFile(String propFilePath) throws FileOperationsException {

        final String methodName="loadPropertyFile";
        LOGGER.info("Entering method:"+methodName);
        
        Properties properties = new Properties();
        try {
            properties.load(new FileInputStream(propFilePath));
        } catch (IllegalArgumentException e) {
            
            LOGGER.error("Problem while loading property file, could be issue of malformed unicode escape sequence:"+propFilePath);
            throw new FileOperationsException(e);

        }catch (IOException e) {
            
            LOGGER.error("Problem while loading property file:"+propFilePath);
            throw new FileOperationsException(e);

        }
        LOGGER.info("Exiting method:"+methodName);
        return properties;
    }

    
    
	public static String getTimeInUTCTimeZone(String createDate,String format) throws ParseException {
		DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
		Date date = formatter.parse(createDate);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);			
		cal.add(Calendar.HOUR, 5);	
		date = cal.getTime();
		DateFormat displayFormat = new SimpleDateFormat(format);
		return displayFormat.format(date);
	}
	
	/**
	 * 
	 * @param key
	 * @return
	 */
	public static String getProperty(String key) {
	      Properties properties = CacheManager.getProperties();
	      String val = properties.getProperty(key);
	      if (val != null) {
	          val = val.trim();
	      }
	      return val;

	  }

}
