package com.metlife.CEOperations.documentFiling;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.RenderedImage;
import java.awt.image.WritableRaster;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.security.auth.Subject;

import org.apache.log4j.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;

import com.filenet.api.collection.BooleanList;
import com.filenet.api.collection.ContentElementList;
import com.filenet.api.collection.DateTimeList;
import com.filenet.api.collection.DocumentSet;
import com.filenet.api.collection.FolderSet;
import com.filenet.api.collection.IdList;
import com.filenet.api.collection.Integer32List;
import com.filenet.api.collection.ReferentialContainmentRelationshipSet;
import com.filenet.api.collection.RepositoryRowSet;
import com.filenet.api.collection.StringList;
import com.filenet.api.collection.VersionableSet;
import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.AutoUniqueName;
import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.DefineSecurityParentage;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.constants.TaskState;
import com.filenet.api.constants.VersionStatus;
import com.filenet.api.core.Annotation;
import com.filenet.api.core.CmTask;
import com.filenet.api.core.Connection;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.EntireNetwork;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.ReferentialContainmentRelationship;
import com.filenet.api.core.VersionSeries;
import com.filenet.api.core.Versionable;
import com.filenet.api.events.Event;
import com.filenet.api.property.Properties;
import com.filenet.api.property.Property;
import com.filenet.api.query.RepositoryRow;
import com.filenet.api.query.SearchSQL;
import com.filenet.api.query.SearchScope;
import com.filenet.api.util.Id;
import com.filenet.api.util.UserContext;
import com.ibm.casemgmt.api.Case;
import com.ibm.casemgmt.api.CaseType;
import com.ibm.casemgmt.api.Comment;
import com.ibm.casemgmt.api.constants.CommentContext;
import com.ibm.casemgmt.api.constants.TaskDisabledState;
import com.ibm.casemgmt.api.context.CaseMgmtContext;
import com.ibm.casemgmt.api.context.SimpleP8ConnectionCache;
import com.ibm.casemgmt.api.context.SimpleVWSessionCache;
import com.ibm.casemgmt.api.objectref.ObjectStoreReference;
import com.ibm.casemgmt.api.properties.CaseMgmtProperties;
import com.ibm.casemgmt.api.tasks.Task;
import com.ibm.casemgmt.api.tasks.WorkItem;
import com.lowagie.text.Image;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.RandomAccessFileOrArray;
import com.lowagie.text.pdf.codec.TiffImage;
import com.metlife.CEOperations.documentFiling.Constants.IConstants;
import com.metlife.CEOperations.documentFiling.Constants.ILoggerConstants;
import com.metlife.CEOperations.documentFiling.Exceptions.DETCaseOperationsException;
import com.metlife.CEOperations.documentFiling.Exceptions.FileOperationsException;
import com.metlife.CEOperations.documentFiling.Exceptions.MetCaseOperationsException;
import com.metlife.CEOperations.documentFiling.Util.DocumentFilingUtil;
import com.sun.media.jai.codec.ImageCodec;
import com.sun.media.jai.codec.ImageDecoder;
import com.sun.media.jai.codec.ImageEncoder;
import com.sun.media.jai.codec.JPEGDecodeParam;
import com.sun.media.jai.codec.MemoryCacheSeekableStream;
import com.sun.media.jai.codec.SeekableStream;
import com.sun.media.jai.codec.TIFFDecodeParam;
import com.sun.media.jai.codec.TIFFEncodeParam;

import filenet.vw.api.VWAttachment;
import filenet.vw.api.VWAttachmentType;
import filenet.vw.api.VWLibraryType;
import filenet.vw.api.VWParticipant;
import filenet.vw.api.VWSession;
import filenet.vw.integrator.CMUserContext;
import filenet.vw.ntutil.TempPath;
import filenet.vw.server.Configuration;
import filenet.vw.server.VWLoginModule;

public class DocumentFilingImpl {

	private static final Logger LOGGER = Logger.getLogger(DocumentFilingImpl.class);

	public static boolean log4jInitFlag;

	/**
	 * to get connection
	 * 
	 * @return
	 */

	public DocumentFilingImpl() throws Exception {
		if (!log4jInitFlag) {
			DocumentFilingUtil.loadLog4j();
			log4jInitFlag = true;

		}
	}

	/**
	 * To get connection
	 * 
	 * @return
	 * @throws Exception
	 */
	private ObjectStore getConnection() throws Exception {

		String METHOD_NAME = "getConnection";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		UserContext old = UserContext.get();
		CaseMgmtContext oldCmc = null;
		Subject sub = CMUserContext.getSubject();
		String ceURI = null;

		try {

			VWSession vwSession = VWLoginModule.getSession();
			String OSSymbolicName = vwSession.getObjectStoreSymbolicName();
			ceURI = Configuration.GetCEURI(null, null);
			Connection connection = Factory.Connection.getConnection(ceURI);
			UserContext uc = new UserContext();
			uc.pushSubject(sub);
			UserContext.set(uc);
			EntireNetwork entireNetwork = Factory.EntireNetwork.fetchInstance(connection, null);
			if (entireNetwork == null) {
				Exception e = new Exception(
						new StringBuilder().append(ILoggerConstants.LOGIN_ERROR).append(ceURI).toString());
				throw e;
			}

			Domain domain = entireNetwork.get_LocalDomain();
			ObjectStore targetOS = (ObjectStore) domain.fetchObject(IConstants.OBJECT_STORE, OSSymbolicName, null);
			SimpleVWSessionCache vwSessCache = new SimpleVWSessionCache();
			CaseMgmtContext cmc = new CaseMgmtContext(vwSessCache, new SimpleP8ConnectionCache());

			oldCmc = CaseMgmtContext.set(cmc);
			return targetOS;
		} catch (Exception e) {
			LOGGER.error(e);

			throw new MetCaseOperationsException(e);

		} finally {
			if (oldCmc != null) {
				CaseMgmtContext.set(oldCmc);
			}
			if (old != null) {
				UserContext.set(old);
			}
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.METHOD_EXIT + METHOD_NAME);
		}

	}

	/**
	 * Indexer able to find the Claim Number Valid documents are moved into
	 * existing primary case and create a new case for invalid documents
	 * 
	 * @param sourceCaseFolderId
	 * @param propSearchCriteria
	 *            - claim number property to search for a case
	 * @param propCriteriaValue
	 *            - claim number value
	 * @param digitalCaseType
	 * @param indexingCaseType
	 * @param targetDocumentClass
	 * @param documentTypeProperty
	 * @param subDocumentTypeProperty
	 * @param docPropArray
	 * @param indexingPropArray
	 * @param RouteDirectToResearch
	 *            - value used for routing in workflow
	 */
	public void completeIndexing(String sourceCaseFolderId, String propSearchCriteria, String propCriteriaValue,
			String digitalCaseType, String indexingCaseType, String targetDocumentClass, String documentTypeProperty,
			String subDocumentTypeProperty, String[] docPropArray, String[] indexingPropArray,
			String RouteDirectToResearch, String IndexingStartFlag) throws MetCaseOperationsException {

		String METHOD_NAME = "completeIndexing";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			ObjectStore targetOS = getConnection();
			Map<String, List<String>> documentIDs = classifyValidAndInvalidDocuments(sourceCaseFolderId,
					documentTypeProperty, targetOS);
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.SOURCE_ID + ": " + sourceCaseFolderId);
			List<String> validDocument = documentIDs.get(IConstants.VALID);
			List<String> inValidDocument = documentIDs.get(IConstants.INVALID);
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.VALID_ID + validDocument.toString());
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.INVALID_ID + inValidDocument.toString());

			if (validDocument.size() != 0) {
				filingValidDocuments(validDocument, null, sourceCaseFolderId, propSearchCriteria, propCriteriaValue,
						digitalCaseType, targetDocumentClass, documentTypeProperty, subDocumentTypeProperty, targetOS,
						docPropArray, IConstants.INDEXINGCASEFOLDERID);
			}

			if (inValidDocument.size() != 0) {
				filingInvalidDocuments(inValidDocument, null, indexingCaseType, sourceCaseFolderId, targetOS,
						indexingPropArray, RouteDirectToResearch, IndexingStartFlag, IConstants.INDEXINGCASEFOLDERID);
			}
			// terminateCase(sourceCaseFolderId);
			DocumentFilingUtil.logtheMessage(LOGGER, 3, ILoggerConstants.COMPLETE_INDEXING);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);

	}

	/**
	 * Indexer Not able to find the Claim Number Invalid documents will be
	 * routed to Research queue
	 * 
	 * @param sourceCaseFolderId
	 * @param documentTypeProperty
	 * @param indexingCaseType
	 * @param indexingPropArray
	 * @param RouteDirectToResearch
	 *            - value used for routing in workflow
	 */
	public void managerToClaimExaminer(String sourceCaseFolderId, String documentTypeProperty, String indexingCaseType,
			String[] indexingPropArray, String RouteDirectToResearch, String IndexingStartFlag, String AllValid)
			throws MetCaseOperationsException {
		String METHOD_NAME = "managerToClaimExaminer";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			ObjectStore targetOS = getConnection();
			Map<String, List<String>> documentIDs = classifyValidAndInvalidDocuments(sourceCaseFolderId,
					documentTypeProperty, targetOS);
			List<String> inValidDocument = documentIDs.get(IConstants.INVALID);
			List<String> validDocument = documentIDs.get(IConstants.VALID);
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.SOURCE_ID + sourceCaseFolderId);
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.INVALID_ID + inValidDocument.toString());

			if (inValidDocument.size() != 0 && validDocument.size() != 0) {
				filingInvalidDocuments(inValidDocument, null, indexingCaseType, sourceCaseFolderId, targetOS,
						indexingPropArray, RouteDirectToResearch, IndexingStartFlag, IConstants.INDEXINGCASEFOLDERID);
			} else if (inValidDocument.size() != 0 && validDocument.size() == 0) {
				ObjectStoreReference osr = new ObjectStoreReference(targetOS);
				Case invalidCase = Case.fetchInstance(osr, new Id(sourceCaseFolderId), null, null);
				invalidCase.getProperties().putObjectValue(AllValid, true);
				invalidCase.save(RefreshMode.REFRESH, null, null);
			}
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.MANAGER_TO_EXAMINER);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
			// TODO: handle exception
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
	}

	/**
	 * Routed from Claim Manager Cases without Claim Number Creates a new
	 * primary case and merge all documents
	 * 
	 * @param sourceCaseFolderId
	 * @param digitalCaseType
	 * @param targetDocumentClass
	 * @param documentTypeProp
	 * @param subDocumentTypeProp
	 * @param IsCaseCreatedByIndexing
	 * @param docPropArray
	 * @param casePropArray
	 * @param AssignToFromIndexer
	 * @throws Exception
	 */
	public void requestNewClaim(String sourceCaseFolderId, String digitalCaseType, String targetDocumentClass,
			String documentTypeProp, String subDocumentTypeProp, String originator, String[] docPropArray,
			String[] casePropArray, String AssignToFromIndexer, String RouteDirectToResearch, String IndexingStartFlag,
			String indexingcaseType, String AssignTo) throws MetCaseOperationsException {
		String METHOD_NAME = "requestNewClaim";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			LOGGER.info("Originator value in RequestNewClaim method " + originator);
			ObjectStore targetOS = getConnection();
			String targetCaseFolderId = null;
			Map<String, List<String>> documentIDs = classifyValidAndInvalidDocuments(sourceCaseFolderId,
					documentTypeProp, targetOS);
			List<String> validDocument = documentIDs.get(IConstants.VALID);
			List<String> inValidDocument = documentIDs.get(IConstants.INVALID);
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.VALID_ID + validDocument.toString());
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.INVALID_ID + inValidDocument.toString());

			if (validDocument.size() != 0) {
				Folder sourcefolder = Factory.Folder.fetchInstance(targetOS, sourceCaseFolderId, null);
				if (validDocument.size() != 0) {

					targetCaseFolderId = createNewCase(targetOS, digitalCaseType, casePropArray, sourcefolder, null,
							originator, AssignToFromIndexer, IndexingStartFlag, AssignTo);
					filingValidDocuments(validDocument, targetCaseFolderId, sourceCaseFolderId, null, null,
							digitalCaseType, targetDocumentClass, documentTypeProp, subDocumentTypeProp, targetOS,
							docPropArray, IConstants.INDEXINGCASEFOLDERID);
					
				}

			}
			if (inValidDocument.size() != 0) {
				LOGGER.info("Inside Requestnew Claim Invaliddocumentif" + targetCaseFolderId);
				filingInvalidDocuments(inValidDocument, null, indexingcaseType, sourceCaseFolderId, targetOS,
						casePropArray, RouteDirectToResearch, IndexingStartFlag, IConstants.INDEXINGCASEFOLDERID);

			}
			// terminateCase(sourceCaseFolderId, targetOS);

		} catch (Exception e) {
			e.printStackTrace();
			throw new MetCaseOperationsException(e);
			// TODO: handle exception
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
	}

	/**
	 * All documents will get merge with Invalid Case
	 * 
	 * @param sourceCaseFolderId
	 * @param propSearchCriteria
	 * @param propCriteriaValue
	 * @param indexingCaseType
	 * @throws Exception
	 */
	public void sendToInvalidCase(String sourceCaseFolderId, String propSearchCriteria, String propCriteriaValue,
			String indexingCaseType) throws MetCaseOperationsException {
		String METHOD_NAME = "sendToInvalidCase";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			ObjectStore targetOS = getConnection();
			String invalidCaseID = searchCase(propSearchCriteria, propCriteriaValue, targetOS, indexingCaseType);
			Folder sourcefolder = Factory.Folder.fetchInstance(targetOS, sourceCaseFolderId, null);
			Folder targetCaseFolder = Factory.Folder.fetchInstance(targetOS, new Id(invalidCaseID), null);
			DocumentSet docs = ((com.filenet.api.core.Folder) sourcefolder).get_ContainedDocuments();
			@SuppressWarnings("unchecked")
			Iterator<Document> documents = docs.iterator();
			ReferentialContainmentRelationship relTo = null;
			ReferentialContainmentRelationship relFrom = null;
			while (documents.hasNext()) {
				Document doc = documents.next();
				relTo = targetCaseFolder.file(doc, AutoUniqueName.AUTO_UNIQUE, doc.get_Name(),
						DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
				relFrom = sourcefolder.unfile(doc);
				relTo.save(RefreshMode.REFRESH);
				relFrom.save(RefreshMode.REFRESH);
			
			}

			// terminateCase(sourceCaseFolderId);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
	}

	/**
	 * Invalid documents will get merge in Invalid case and valid documents
	 * forwarded to primary case
	 * 
	 * @param sourceCaseFolderId
	 * @param documentType
	 * @param propSearchCriteria
	 * @param propCriteriaValue
	 * @param indexingCaseType
	 * @param RouteDirectToResearch
	 *            - used for routing in workflow
	 */
	public void sendToClaimManager(String sourceCaseFolderId, String documentType, String propSearchCriteria,
			String propCriteriaValue, String indexingCaseType, String RouteDirectToResearch, String IndexingStartFlag,
			String AllValid) throws MetCaseOperationsException {
		String METHOD_NAME = "sendToClaimManager";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			ObjectStore targetOS = getConnection();
			Map<String, List<String>> documentIDs = classifyValidAndInvalidDocuments(sourceCaseFolderId, documentType,
					targetOS);
			List<String> inValidDocument = documentIDs.get(IConstants.INVALID);
			List<String> validDocument = documentIDs.get(IConstants.VALID);
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.INVALID_ID + inValidDocument.toString());
			if (inValidDocument.size() != 0) {
				String invalidCaseID = searchCase(propSearchCriteria, propCriteriaValue, targetOS, indexingCaseType);
				if (invalidCaseID != null)
					filingInvalidDocuments(inValidDocument, invalidCaseID, null, sourceCaseFolderId, targetOS, null,
							RouteDirectToResearch, IndexingStartFlag, IConstants.INDEXINGCASEFOLDERID);
			}

			if (validDocument.size() == 0) {
				ObjectStoreReference osr = new ObjectStoreReference(targetOS);
				Case invalidCase = Case.fetchInstance(osr, new Id(sourceCaseFolderId), null, null);
				invalidCase.getProperties().putObjectValue(AllValid, true);
				invalidCase.save(RefreshMode.REFRESH, null, null);

			}
			if (validDocument.size() != 0) {
				ObjectStoreReference osr = new ObjectStoreReference(targetOS);
				Case invalidCase = Case.fetchInstance(osr, new Id(sourceCaseFolderId), null, null);
				LOGGER.info("Get iscase created by indexing Property value"
						+ invalidCase.getProperties().getObjectValue(AllValid));
				if (invalidCase.getProperties().getObjectValue(AllValid).equals(true)) {
					LOGGER.info("Condition satisfied");
					invalidCase.getProperties().putObjectValue(AllValid, false);
					invalidCase.save(RefreshMode.REFRESH, null, null);
				}

			}

		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
	}

	/**
	 * 
	 * @param attachments
	 * @param targetCaseFolderId
	 * @param targetDocumentClass
	 * @param documentTypeProp
	 * @param subDocumentTypeProp
	 * @param documentTypeValue
	 * @param subDocumentTypeValue
	 * @param attachmentFilingFolderName
	 *            -FileName in which document gets saved while adding as an
	 *            attachment
	 * @param propArray
	 * @param attachmentDocumentClass
	 * @throws MetCaseOperationsException
	 */
	public void addAttachmentsToCase(VWAttachment[] attachments, String targetCaseFolderId, String targetDocumentClass,
			String documentTypeProp, String subDocumentTypeProp, String documentTypeValue, String subDocumentTypeValue,
			String attachmentFilingFolderName, String[] propArray, String attachmentDocumentClass,
			String formDocumentClass, String formSubDocumentClass, String source, String sourceValue, String addedBy)
			throws MetCaseOperationsException {
		String METHOD_NAME = "addAttachmentsToCase";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			ObjectStore targetOS = getConnection();
			Folder targetFolder = Factory.Folder.fetchInstance(targetOS, targetCaseFolderId, null);
			StringBuilder docFilingFolderPath = new StringBuilder();
			if (subDocumentTypeValue.equals("")) {

				docFilingFolderPath.append(targetFolder.get_PathName()).append("/").append(documentTypeValue);
			} else {
				docFilingFolderPath.append(targetFolder.get_PathName()).append("/").append(documentTypeValue)
						.append("/").append(subDocumentTypeValue);
			}
			LOGGER.info("Filing Path:"+docFilingFolderPath);

			Folder targetDocFolder = Factory.Folder.fetchInstance(targetOS, docFilingFolderPath.toString(), null);
			
			LOGGER.info("after Folder ");
		/*	for (VWAttachment attachment : attachments) {
				VersionSeries vs = Factory.VersionSeries.fetchInstance(targetOS, new Id(attachment.getId()), null);
				Document doc = (Document) vs.get_CurrentVersion();

				if (formSubDocumentClass.equals(doc.getClassName())) {
					Properties properties = doc.getProperties();
					associatedCaseValue = properties.getIdValue(IConstants.ASSOCIATEDCASE).toString();
					break;
				}
			}*/
			if(attachments!=null)
			{
			for (VWAttachment attachment : attachments) {
				if(attachment.getId()!=null){
				    
				VersionSeries vs = Factory.VersionSeries.fetchInstance(targetOS, new Id(attachment.getId()), null);
				Document doc = (Document) vs.get_CurrentVersion();
				LOGGER.info("doc name"+doc.get_Name());
				LOGGER.info("Add attachment case" +doc.getProperties().getStringValue("IDI_Source"));
/*				if (formDocumentClass.equals(doc.getClassName())) {
					if (targetDocumentClass != null)
						doc.changeClass(formSubDocumentClass);
					Properties properties = doc.getProperties();
					DateFormat df = new SimpleDateFormat(IConstants.DATEFORMAT);
					String finaldates = "";
					finaldates = df.format(properties.getDateTimeValue(IConstants.DATECREATED));

					String docTitle = properties.get(IConstants.DOCUMENTTITLE).getStringValue();
					properties.putValue((IConstants.DOCUMENTTITLE), docTitle + "--" + finaldates);
					if (propArray != null) {
						for (String property : propArray) {
							properties.putValue(property, targetFolder.getProperties().getStringValue(property));
						}
					}
					doc.save(RefreshMode.REFRESH);
				}
				if (formSubDocumentClass.equals(doc.getClassName())) {
					Properties properties = doc.getProperties();
					DateFormat df = new SimpleDateFormat(IConstants.DATEFORMAT);
					String finaldates = "";
					finaldates = df.format(properties.getDateTimeValue(IConstants.DATECREATED));

					String docTitle = properties.get(IConstants.DOCUMENTTITLE).getStringValue();
					properties.putValue((IConstants.DOCUMENTTITLE), docTitle + "--" + finaldates);

					doc.save(RefreshMode.REFRESH);

				}*/
				if (attachmentDocumentClass.equals(doc.getClassName())) {
					if (targetDocumentClass != null)
						doc.changeClass(targetDocumentClass);
					Properties properties = doc.getProperties();
					DateFormat df = new SimpleDateFormat(IConstants.DATEFORMAT);
					String finaldates = "";
					finaldates = df.format(properties.getDateTimeValue(IConstants.DATECREATED));
					//String docTitle = properties.get(IConstants.DOCUMENTTITLE).getStringValue();
					//String associatedCaseValue = properties.getIdValue(IConstants.ASSOCIATEDCASE).toString();
					properties.putValue((IConstants.DOCUMENTTITLE), finaldates);
					properties.putValue(IConstants.ORIGNALASSOCCASE, targetCaseFolderId);
					properties.putValue(source, sourceValue);
					properties.putValue(addedBy, doc.get_Creator());
					LOGGER.info("Source----" + sourceValue);
					LOGGER.info("addedBy----" + doc.get_Creator());
					// properties.putValue(IConstants.ORIGNALASSOCCASE,
					// properties
					// .getIdValue(IConstants.ASSOCIATEDCASE).toString());

					if (propArray != null) {
						for (String property : propArray) {
							properties.putValue(property, targetFolder.getProperties().getStringValue(property));
						}
					}
					properties.putValue(documentTypeProp, documentTypeValue);
					properties.putValue(subDocumentTypeProp, subDocumentTypeValue);
					doc.save(RefreshMode.REFRESH);
					ReferentialContainmentRelationship relTo = targetDocFolder.file(doc, AutoUniqueName.AUTO_UNIQUE,
							doc.get_Name(), DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
					relTo.save(RefreshMode.REFRESH);

					ReferentialContainmentRelationshipSet rcrs = doc.get_Containers();

					Iterator iter = rcrs.iterator();
					while (iter.hasNext()) {
						ReferentialContainmentRelationship rcr = (ReferentialContainmentRelationship) iter.next();

						Folder folder = (Folder) rcr.get_Tail();

						if (folder.get_PathName().contains(attachmentFilingFolderName)) {
							rcr.delete();
							rcr.save(RefreshMode.REFRESH);
						}
					}

				}
			}
			}
		}
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.ADD_ATTACHMENTS_TO_CASE);
			
		}

		catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
	}
	

	/**
	 * 
	 * @param attachments
	 * @param targetCaseFolderId
	 * @param targetDocumentClass
	 * @param documentTypeProp
	 * @param subDocumentTypeProp
	 * @param documentTypeValue
	 * @param subDocumentTypeValue
	 * @param attachmentFilingFolderName
	 * @param propArray
	 * @param attachmentDocumentClass
	 * @param formDocumentClass
	 * @param formSubDocumentClass
	 * @param source
	 * @param sourceValue
	 * @param addedBy
	 * @throws MetCaseOperationsException
	 * copy of addattachmenttocase
	 */

	public void caseAttachment(VWAttachment[] attachments, String targetCaseFolderId, String targetDocumentClass,
			String documentTypeProp, String subDocumentTypeProp, String documentTypeValue, String subDocumentTypeValue,
			String attachmentFilingFolderName, String[] propArray, String attachmentDocumentClass,
			String formDocumentClass, String formSubDocumentClass, String source, String sourceValue, String addedBy)
			throws MetCaseOperationsException {
		String METHOD_NAME = "caseAttachment";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			LOGGER.info("Sourcevalue while entering method----" + sourceValue);
			LOGGER.info("Sourceproperty while entering method----" + source);
			LOGGER.info("Addedbyproperty while entering method----" + addedBy);
			ObjectStore targetOS = getConnection();
			Folder targetFolder = Factory.Folder.fetchInstance(targetOS, targetCaseFolderId, null);
			String associatedCaseValue = null;
			StringBuilder docFilingFolderPath = new StringBuilder();
			if (subDocumentTypeValue.equals("")) {

				docFilingFolderPath.append(targetFolder.get_PathName()).append("/").append(documentTypeValue);
			} else {
				docFilingFolderPath.append(targetFolder.get_PathName()).append("/").append(documentTypeValue)
						.append("/").append(subDocumentTypeValue);
			}

			Folder targetDocFolder = Factory.Folder.fetchInstance(targetOS, docFilingFolderPath.toString(), null);

		/*	for (VWAttachment attachment : attachments) {
				VersionSeries vs = Factory.VersionSeries.fetchInstance(targetOS, new Id(attachment.getId()), null);
				Document doc = (Document) vs.get_CurrentVersion();

				if (formSubDocumentClass.equals(doc.getClassName())) {
					Properties properties = doc.getProperties();
					associatedCaseValue = properties.getIdValue(IConstants.ASSOCIATEDCASE).toString();
					break;
				}
			}*/

			if(attachments!=null)
			{
			for (VWAttachment attachment : attachments) {
				VersionSeries vs = Factory.VersionSeries.fetchInstance(targetOS, new Id(attachment.getId()), null);
				Document doc = (Document) vs.get_CurrentVersion();
		/*		if (formDocumentClass.equals(doc.getClassName())) {
					LOGGER.info("formDocumentClassif----");
					if (targetDocumentClass != null)
						doc.changeClass(formSubDocumentClass);
					Properties properties = doc.getProperties();
					DateFormat df = new SimpleDateFormat(IConstants.DATEFORMAT);
					String finaldates = "";
					finaldates = df.format(properties.getDateTimeValue(IConstants.DATECREATED));

					String docTitle = properties.get(IConstants.DOCUMENTTITLE).getStringValue();
					properties.putValue((IConstants.DOCUMENTTITLE), docTitle + "--" + finaldates);
					if (propArray != null) {
						for (String property : propArray) {
							properties.putValue(property, targetFolder.getProperties().getStringValue(property));
						}
					}
					doc.save(RefreshMode.REFRESH);
				}
				if (formSubDocumentClass.equals(doc.getClassName())) {
					LOGGER.info("formSubDocumentClassif----");
					Properties properties = doc.getProperties();
					DateFormat df = new SimpleDateFormat(IConstants.DATEFORMAT);
					String finaldates = "";
					finaldates = df.format(properties.getDateTimeValue(IConstants.DATECREATED));

					String docTitle = properties.get(IConstants.DOCUMENTTITLE).getStringValue();
					properties.putValue((IConstants.DOCUMENTTITLE), docTitle + "--" + finaldates);

					doc.save(RefreshMode.REFRESH);

				}*/
				LOGGER.info("AddAttachment Class " + doc.getClassName());
				LOGGER.info("AddAttachment Class4 " + attachmentDocumentClass);
				LOGGER.info("AddAttachment Class1 " + attachmentDocumentClass.equals(doc.getClassName()));
				LOGGER.info("AddAttachment Class2 " + attachmentDocumentClass == doc.getClassName());

				if (attachmentDocumentClass.equals(doc.getClassName())) {
					LOGGER.info("AttachmentDocumentClassif----");
					if (targetDocumentClass != null)
						doc.changeClass(targetDocumentClass);
					Properties properties = doc.getProperties();
					String sprop = properties.get(source).getStringValue();
					LOGGER.info("Source Property using get property" + sprop);
					String addprop = properties.get(addedBy).getStringValue();
					LOGGER.info("Source Property using get property" + addprop);
					DateFormat df = new SimpleDateFormat(IConstants.DATEFORMAT);
					String finaldates = "";
					finaldates = df.format(properties.getDateTimeValue(IConstants.DATECREATED));
					//String docTitle = properties.get(IConstants.DOCUMENTTITLE).getStringValue();
					//associatedCaseValue = properties.getIdValue(IConstants.ASSOCIATEDCASE).toString();
					properties.putValue((IConstants.DOCUMENTTITLE), finaldates);
					properties.putValue(IConstants.ORIGNALASSOCCASE, targetCaseFolderId);
					// properties.putValue(IConstants.ORIGNALASSOCCASE,
					// properties
					// .getIdValue(IConstants.ASSOCIATEDCASE).toString());

					if (propArray != null) {
						for (String property : propArray) {
							properties.putValue(property, targetFolder.getProperties().getStringValue(property));
						}
					}
					properties.putValue(documentTypeProp, documentTypeValue);
					properties.putValue(subDocumentTypeProp, subDocumentTypeValue);
					properties.putValue(source, sourceValue);
					properties.putValue(addedBy, doc.get_Creator());
					LOGGER.info("Source----" + sourceValue);
					LOGGER.info("addedBy----" + doc.get_Creator());
					doc.save(RefreshMode.REFRESH);
					ReferentialContainmentRelationship relTo = targetDocFolder.file(doc, AutoUniqueName.AUTO_UNIQUE,
							doc.get_Name(), DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
					relTo.save(RefreshMode.REFRESH);

					ReferentialContainmentRelationshipSet rcrs = doc.get_Containers();

					Iterator iter = rcrs.iterator();
					while (iter.hasNext()) {
						ReferentialContainmentRelationship rcr = (ReferentialContainmentRelationship) iter.next();

						Folder folder = (Folder) rcr.get_Tail();

						if (folder.get_PathName().contains(attachmentFilingFolderName)) {
							rcr.delete();
							rcr.save(RefreshMode.REFRESH);
						}
					}

				}
			}
		}
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.ADD_ATTACHMENTS_TO_CASE);
		}

		catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
	}

	/**
	 * To change the document class to IDIFormData from FormData for form
	 * documents
	 * 
	 * @param attachments
	 * @param formDocumentClass
	 * @param formtargetDocumentClass
	 * @param sourceCaseFolderId
	 * @param propArray
	 * @throws MetCaseOperationsException
	 */

	public void changeDocclass(VWAttachment[] attachments, String targetCaseFolderId, String targetDocumentClass,
			String documentTypeProp, String subDocumentTypeProp, String documentTypeValue, String subDocumentTypeValue,
			String attachmentFilingFolderName, String attachmentDocumentClass, String formDocumentClass,
			String formtargetDocumentClass, String[] propArray, String source, String sourceValue, String addedBy)
			throws MetCaseOperationsException {
		String METHOD_NAME = "changeDocclassupdated";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			ObjectStore targetOS = getConnection();
			LOGGER.info("CaseID :"+targetCaseFolderId);
			Folder targetFolder = Factory.Folder.fetchInstance(targetOS, targetCaseFolderId, null);
			StringBuilder docFilingFolderPath = new StringBuilder();
			if (subDocumentTypeValue.equals("")) {

				docFilingFolderPath.append(targetFolder.get_PathName()).append("/").append(documentTypeValue);
			} else {
				docFilingFolderPath.append(targetFolder.get_PathName()).append("/").append(documentTypeValue)
						.append("/").append(subDocumentTypeValue);
			}
			LOGGER.info("Filing Path :"+docFilingFolderPath);

/*			for (VWAttachment attachment : attachments) {
				VersionSeries vs = Factory.VersionSeries.fetchInstance(targetOS, new Id(attachment.getId()), null);
				Document doc = (Document) vs.get_CurrentVersion();
				if (doc.getClassName().equals(formDocumentClass)) {
					doc.changeClass(formtargetDocumentClass);
					Properties properties = doc.getProperties();
					DateFormat df = new SimpleDateFormat(IConstants.DATEFORMAT);
					String finaldates = "";
					finaldates = df.format(properties.getDateTimeValue(IConstants.DATECREATED));

					String docTitle = properties.get(IConstants.DOCUMENTTITLE).getStringValue();
					properties.putValue((IConstants.DOCUMENTTITLE), docTitle + "--" + finaldates);
					properties.putValue(IConstants.ORIGNALASSOCCASE,
							properties.getIdValue(IConstants.ASSOCIATEDCASE).toString());
					associatedCaseValue = properties.getIdValue(IConstants.ASSOCIATEDCASE).toString();
					LOGGER.info("Associated Case Value1" + associatedCaseValue);
					for (String property : propArray) {

						properties.putValue(property, targetFolder.getProperties().getStringValue(property));

					}

					doc.save(RefreshMode.REFRESH);
				}
			}*/
			LOGGER.info("Attachments length:"+attachments.length);
			for (VWAttachment attachment : attachments) {
				if(attachment.getId()!=null){
				LOGGER.info("Attachment ID" + attachment.getId());
				VersionSeries vs = Factory.VersionSeries.fetchInstance(targetOS, new Id(attachment.getId()), null);
				Document doc = (Document) vs.get_CurrentVersion();
				if (attachmentDocumentClass.equals(doc.getClassName())) {
					LOGGER.info("AttachementDocumentclassupdated1" + attachmentDocumentClass);
					LOGGER.info("ChangeClass" + targetDocumentClass);
					ReferentialContainmentRelationship relTo = targetFolder.file(doc, AutoUniqueName.AUTO_UNIQUE,
							doc.get_Name(), DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
					relTo.save(RefreshMode.REFRESH);
					LOGGER.info("Document filed in target" + targetFolder.get_PathName());

					if (targetDocumentClass != null)
						doc.changeClass(targetDocumentClass);
					Properties properties = doc.getProperties();
					DateFormat df = new SimpleDateFormat(IConstants.DATEFORMAT);
					String finaldates = "";
					finaldates = df.format(properties.getDateTimeValue(IConstants.DATECREATED));
					//String docTitle = properties.get(IConstants.DOCUMENTTITLE).getStringValue();
					//String associatedCaseValue  = properties.getIdValue(IConstants.ASSOCIATEDCASE).toString();
					LOGGER.info("Associated Case Value :" + targetCaseFolderId);
					properties.putValue((IConstants.DOCUMENTTITLE), finaldates);
					properties.putValue(IConstants.ORIGNALASSOCCASE, targetCaseFolderId);
					properties.putValue(source, sourceValue);
					properties.putValue(addedBy, doc.get_Creator());
					if (propArray != null) {
						for (String property : propArray) {
							properties.putValue(property, targetFolder.getProperties().getStringValue(property));
						}
					}

					// LOGGER.info("ReferentialContainmentRelationship: document filed");
					properties.putValue(documentTypeProp, documentTypeValue);
					properties.putValue(subDocumentTypeProp, subDocumentTypeValue);
					LOGGER.info("Sequencenumber1" + doc.getUpdateSequenceNumber());
					LOGGER.info("Sequencenumber2" + doc.getUpdateSequenceNumber());
					doc.setUpdateSequenceNumber(null);
					doc.save(RefreshMode.REFRESH);
					LOGGER.info("Source----" + sourceValue);
					LOGGER.info("addedBy----" + doc.get_Creator());
					// LOGGER.info("Associated Case
					// Value2"+properties.getStringValue("IDI_OriginalAssociatedCase"));

					ReferentialContainmentRelationshipSet rcrs = doc.get_Containers();

					Iterator iter = rcrs.iterator();
					while (iter.hasNext()) {
						ReferentialContainmentRelationship rcr = (ReferentialContainmentRelationship) iter.next();

						Folder folder = (Folder) rcr.get_Tail();

						if (folder.get_PathName().contains(attachmentFilingFolderName)) {
							LOGGER.info("Attachment Deleted");
							rcr.delete();
							rcr.save(RefreshMode.REFRESH);
						}
					}

				}
			}
			}
		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}

	}

	/**
	 * 
	 * @param attachments
	 * @param targetCaseFolderId
	 * @param targetDocumentClass
	 * @param documentTypeProp
	 * @param subDocumentTypeProp
	 * @param documentTypeValue
	 * @param subDocumentTypeValue
	 * @param attachmentFilingFolderName
	 * @param attachmentDocumentClass
	 * @param formDocumentClass
	 * @param formtargetDocumentClass
	 * @param propArray
	 * @throws MetCaseOperationsException
	 */
	public void changeDocclasses(VWAttachment[] attachments, String targetCaseFolderId, String targetDocumentClass,
			String documentTypeProp, String subDocumentTypeProp, String documentTypeValue, String subDocumentTypeValue,
			String attachmentFilingFolderName, String attachmentDocumentClass, String formDocumentClass,
			String formtargetDocumentClass, String[] propArray) throws MetCaseOperationsException {
		String METHOD_NAME = "changeDocclass";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			ObjectStore targetOS = getConnection();
			Folder targetFolder = Factory.Folder.fetchInstance(targetOS, targetCaseFolderId, null);
			//String associatedCaseValue = null;
			StringBuilder docFilingFolderPath = new StringBuilder();
			if (subDocumentTypeValue.equals("")) {

				docFilingFolderPath.append(targetFolder.get_PathName()).append("/").append(documentTypeValue);
			} else {
				docFilingFolderPath.append(targetFolder.get_PathName()).append("/").append(documentTypeValue)
						.append("/").append(subDocumentTypeValue);
			}

/*			for (VWAttachment attachment : attachments) {
				VersionSeries vs = Factory.VersionSeries.fetchInstance(targetOS, new Id(attachment.getId()), null);
				Document doc = (Document) vs.get_CurrentVersion();
				if (doc.getClassName().equals(formDocumentClass)) {
					doc.changeClass(formtargetDocumentClass);
					Properties properties = doc.getProperties();
					DateFormat df = new SimpleDateFormat(IConstants.DATEFORMAT);
					String finaldates = "";
					finaldates = df.format(properties.getDateTimeValue(IConstants.DATECREATED));

					String docTitle = properties.get(IConstants.DOCUMENTTITLE).getStringValue();
					properties.putValue((IConstants.DOCUMENTTITLE), docTitle + "--" + finaldates);
					properties.putValue(IConstants.ORIGNALASSOCCASE,
							properties.getIdValue(IConstants.ASSOCIATEDCASE).toString());
					associatedCaseValue = properties.getIdValue(IConstants.ASSOCIATEDCASE).toString();
					for (String property : propArray) {

						properties.putValue(property, targetFolder.getProperties().getStringValue(property));

					}

					doc.save(RefreshMode.REFRESH);
				}
			}*/
			for (VWAttachment attachment : attachments) {
				VersionSeries vs = Factory.VersionSeries.fetchInstance(targetOS, new Id(attachment.getId()), null);
				Document doc = (Document) vs.get_CurrentVersion();
				if (attachmentDocumentClass.equals(doc.getClassName())) {
					if (targetDocumentClass != null)
						doc.changeClass(targetDocumentClass);
					Properties properties = doc.getProperties();
					DateFormat df = new SimpleDateFormat(IConstants.DATEFORMAT);
					String finaldates = "";
					finaldates = df.format(properties.getDateTimeValue(IConstants.DATECREATED));
					//String docTitle = properties.get(IConstants.DOCUMENTTITLE).getStringValue();
					//associatedCaseValue = properties.getIdValue(IConstants.ASSOCIATEDCASE).toString();
					properties.putValue((IConstants.DOCUMENTTITLE), finaldates);
					properties.putValue(IConstants.ORIGNALASSOCCASE, targetCaseFolderId);
					// properties.putValue(IConstants.ORIGNALASSOCCASE,
					// properties
					// .getIdValue(IConstants.ASSOCIATEDCASE).toString());

					if (propArray != null) {
						for (String property : propArray) {
							properties.putValue(property, targetFolder.getProperties().getStringValue(property));
						}
					}

					ReferentialContainmentRelationship relTo = targetFolder.file(doc, AutoUniqueName.AUTO_UNIQUE,
							doc.get_Name(), DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
					relTo.save(RefreshMode.REFRESH);

					properties.putValue(documentTypeProp, documentTypeValue);
					properties.putValue(subDocumentTypeProp, subDocumentTypeValue);
					doc.setUpdateSequenceNumber(null);
					doc.save(RefreshMode.REFRESH);

					ReferentialContainmentRelationshipSet rcrs = doc.get_Containers();

					Iterator iter = rcrs.iterator();
					while (iter.hasNext()) {
						ReferentialContainmentRelationship rcr = (ReferentialContainmentRelationship) iter.next();

						Folder folder = (Folder) rcr.get_Tail();

						if (folder.get_PathName().contains(attachmentFilingFolderName)) {
							rcr.delete();
							rcr.save(RefreshMode.REFRESH);
						}
					}

				}
			}
		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
	}

	/**
	 * 
	 * @param attachments
	 * @param caseFolderId
	 * @param documentTypeValue
	 * @param subDocumentTypeValue
	 * @return
	 * @throws Exception
	 */
	public VWAttachment[] addDocumentsToAttachment(VWAttachment[] attachments, String caseFolderId,
			String documentTypeValue, String subDocumentTypeValue) throws MetCaseOperationsException {

		String METHOD_NAME = "addDocumentsToAttachment";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		VWAttachment[] returnAttachment = null;
		try {
			ObjectStore targetOS = getConnection();
			Folder caseFolder = Factory.Folder.fetchInstance(targetOS, caseFolderId, null);
			StringBuilder folderPath = new StringBuilder();
			if (subDocumentTypeValue.equals("")) {
				folderPath.append(caseFolder.get_PathName()).append("/").append(documentTypeValue);
			} else {
				folderPath.append(caseFolder.get_PathName()).append("/").append(documentTypeValue).append("/")
						.append(subDocumentTypeValue);
			}
			Folder targetFolder = Factory.Folder.fetchInstance(targetOS, folderPath.toString(), null);
			DocumentSet documentSet = targetFolder.get_ContainedDocuments();
			Map<Date, Document> map = new TreeMap<Date, Document>();
			Document attachmentDocument = null;

			@SuppressWarnings("unchecked")
			Iterator<Document> document = documentSet.iterator();
			while (document.hasNext()) {
				Document doc = document.next();
				Date time = doc.getProperties().getDateTimeValue(IConstants.DATECREATED);
				map.put(time, doc);
			}

			if (!map.isEmpty()) {
				for (Entry<Date, Document> mapData : map.entrySet()) {
					attachmentDocument = mapData.getValue();
				}
				returnAttachment = new VWAttachment[attachments.length + 1];
				for (int i = 0; i < attachments.length; i++) {
					returnAttachment[i] = attachments[i];
				}
			} else {
				returnAttachment = new VWAttachment[attachments.length];
				for (int i = 0; i < attachments.length; i++) {
					returnAttachment[i] = attachments[i];
				}
			}

			if (attachmentDocument != null) {
				VWAttachment att = new VWAttachment();
				att.setAttachmentName(attachmentDocument.get_Name());
				att.setLibraryName(targetOS.get_Name().toString());
				att.setLibraryType(VWAttachmentType.ATTACHMENT_TYPE_DOCUMENT);
				att.setType(VWLibraryType.LIBRARY_TYPE_CONTENT_ENGINE);
				VersionSeries vs = attachmentDocument.get_VersionSeries();
				att.setId(vs.get_Id().toString());
				att.setVersion(attachmentDocument.get_Id().toString());
				returnAttachment[attachments.length] = att;

			}

		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
		return returnAttachment;
	}

	
	
	/**
     * to search a primary case by querying claimNumber
     * 
     * @param propSearchCriteria
     * @param propCriteriaValue
     * @param objectStore
     * @param targetCaseType
     * @return
     * @throws Exception
     */
    public void searchCaseToCheckDuplicates(String propSearchCriteria, String propCriteriaValue, 
            String targetCaseType,String sourcecaseId,String docType,String subDocType,String[] propArray,String documentclass) throws MetCaseOperationsException, FileOperationsException {
        String methodName = "searchCaseToCheckDuplicates";
        LOGGER.info("Entering method Name:"+methodName);
       
         String targetcaseID=null;
         boolean claimreviewstate=false;
         boolean claimsetupstate=false;
         sourcecaseId=null;
         DocumentFilingUtil.loadMetCMProperties();
        try {
            ObjectStore targetOS=getConnection();
            ObjectStoreReference osr = new ObjectStoreReference(targetOS);
            String winningtaskQuery = DocumentFilingUtil.getProperty(IConstants.WINNINGTASKQUERY);
            if (propSearchCriteria != null && propCriteriaValue != null) {
                SearchScope scope = new SearchScope(targetOS);
                StringBuilder claimquery = new StringBuilder();
                claimquery.append(ILoggerConstants.SQL_SELECT).append(targetCaseType).append(ILoggerConstants.SQL_WHERE).append(propSearchCriteria).append("='").append(propCriteriaValue).append("'");
                SearchSQL sql = new SearchSQL(claimquery.toString());
               LOGGER.info("sql Query : " + sql.toString());
                RepositoryRowSet rows = scope.fetchRows(sql, Integer.valueOf(10), null, Boolean.valueOf(true));
                @SuppressWarnings("rawtypes")
                Iterator<Document> itRow = rows.iterator();
                RepositoryRow row;
                // Iterate based on the claim number count.
                while (itRow.hasNext()) {
                    row = (RepositoryRow) itRow.next();
                    Properties props = row.getProperties();
                    @SuppressWarnings("rawtypes")
                    Iterator itProp = props.iterator();
                    Property prop;
                  
                    // Iterate depends on the number of properties in the select query statement (Here it is only once)
                    while (itProp.hasNext()) {
                        prop = (Property) itProp.next();
                     
                        LOGGER.info("Props" +prop.getObjectValue().toString());
                 
                             String caseId=prop.getObjectValue().toString();
                             String taskQuery = winningtaskQuery.replace("replacewinningcaseid", "'"+caseId+ "'");
                             List winningtaskList = taskqueryResults(taskQuery,targetOS);
                             for(int i=0; i<winningtaskList.size();i++)
                             {
                                 String taskId= winningtaskList.get(i).toString();
                                 Task task = Task.fetchInstance(osr, new Id(taskId));
                                 String taskname=task.getName();
                                 TaskState state = task.getState();
                                 if(taskname.equals(IConstants.CLAIMREVIEWNAME) && state.equals(TaskState.WORKING))
                                 {
                                     claimreviewstate=true;
                                     LOGGER.info("Claim review is working state");
                                 }
                                 else if(taskname.equals(IConstants.NEWCLAIMSETUPNAME) && state.equals(TaskState.WAITING_PRECONDITION))
                                 {
                                     claimsetupstate=true;
                                     LOGGER.info("ClaimSetup is in waiting state");
                                     
                                 }
                                 
                             }
                             if(claimreviewstate && claimsetupstate){
                                 targetcaseID=caseId;
                                 LOGGER.info("Target CaseID:: "+targetcaseID);
                                 claimreviewstate=false;
                                 claimsetupstate=false;
                             }else{
                                 sourcecaseId=caseId;
                                 LOGGER.info("Source CaseID:: "+sourcecaseId);
                                 
                             }
                             
                        
                    }
                 
                }
                if(targetcaseID!=null && sourcecaseId!=null){
                    
                    mergeWithWinningCase(sourcecaseId,targetcaseID,docType,subDocType,propArray,documentclass);
                }
               
            
            }

        }catch (Exception e) {
            LOGGER.error(e);
            throw new MetCaseOperationsException(e);
        }
       LOGGER.info("Exiting method:"+methodName);
    }
	/**
     * merge primary documents with existing primary case
     * 
     * @param sourceCaseFolderId
     * @param targetCaseFolderId
     * @param claimNumber
     * @param documentTypeProperty
     * @param subDocumentTypeProperty
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    private void mergeWithWinningCase(String sourceCaseFolderId, String targetCaseFolderId, String documentTypeProperty,
            String subDocumentTypeProperty, String[] propArray, String targetDocumentClass) throws  FileOperationsException{
        String methodName = "mergeWithWinningCase";
       LOGGER.info("Entering method:"+methodName);
        DocumentFilingUtil.loadMetCMProperties();
        try {

            ObjectStore targetOS = getConnection();
            ObjectStoreReference osr = new ObjectStoreReference(targetOS);
             if (targetCaseFolderId != null) {
                List<String> valid = new ArrayList<String>();
                List taskids =  new ArrayList(); 
                boolean claimreviewstate=false;
                boolean claimsetupstate=false;
                Task winningnewClaimSetuptask=null;
                Task losingnewClaimSetuptask=null;
                boolean losingnewclaimsetup = false;
                String winningnewclaimsetupid = null;
                String eventQuery=DocumentFilingUtil.getProperty(IConstants.EVENTQUERY);
                String winningtaskQuery = DocumentFilingUtil.getProperty(IConstants.WINNINGTASKQUERY);
                String losingtaskQuery = DocumentFilingUtil.getProperty(IConstants.LOSINGTASKQUERY);
                String deleteEvent=DocumentFilingUtil.getProperty(IConstants.DELETEEVENT);
                String deleteCaseorTask = DocumentFilingUtil.getProperty(IConstants.DELETECASEORTASK);
                String copyCaseprop = DocumentFilingUtil.getProperty(IConstants.COPYCASEPROPS);
                String modifiedwinningtaskQuery = winningtaskQuery.replace("replacewinningcaseid", "'"+targetCaseFolderId+ "'");
                String modifiedlosingtaskQuery =  losingtaskQuery.replace("replacelosingcaseid", "'"+sourceCaseFolderId+ "'");
                Folder sourcefolder = Factory.Folder.fetchInstance(targetOS, sourceCaseFolderId, null);
                Folder targetfolder = Factory.Folder.fetchInstance(targetOS, targetCaseFolderId, null);
                String targetCasePath = targetfolder.get_PathName();
                FolderSet mainFolders = sourcefolder.get_SubFolders();
                Iterator<Folder> iterator = mainFolders.iterator();


                Properties targetProperties=targetfolder.getProperties();

                Properties sourceProperties=sourcefolder.getProperties();
                sourceProperties.putValue(IConstants.DUPLICATECASEPROPERTY, "Duplicate");
                sourcefolder.save(RefreshMode.REFRESH);
               

                /**
                 * Included for Defect# 46660 and Defect# 46541: Associated Claims 
                 */
                String propertylist=DocumentFilingUtil.getProperty(IConstants.PROPERTIESLIST);
                LOGGER.info("Properties list mentioned:"+propertylist);

              
                String commentcreator = null;
                Date commentdate;
                String finalcommentDate=null;
                String casecomment=DocumentFilingUtil.getProperty(IConstants.CASECOMMENTVALUE);


                /**
                 * condition included to check if case comment is 'Y' - adds source case comment to target case comments.
                 * Comments will be added to target case only if the comment value is passed as 'Y' in property file. 
                 */


                if(casecomment.equalsIgnoreCase(IConstants.YESVALUE)){
                    ObjectStoreReference osReference = new ObjectStoreReference(targetOS);
                    Case sourcecase = Case.fetchInstance(osReference, new Id(sourceCaseFolderId), null,null);
                    Case targetcase = Case.fetchInstance(osReference, new Id(targetCaseFolderId), null,null);
                    List<Comment> comment =sourcecase.fetchCaseComments();
                    for(int l=0;l<comment.size();l++){
                        StringBuilder oldComment=new StringBuilder();
                        oldComment.append(comment.get(l).getText()).append("_");
                        DateFormat df = new SimpleDateFormat(IConstants.COMMENTDATE);
                        commentdate = comment.get(l).getDateCreated();
                        finalcommentDate = df.format(commentdate);
                        commentcreator = comment.get(l).getCreator();
                        oldComment.append(commentcreator).append("_").append(finalcommentDate);
                        Comment addcomment=targetcase.addCaseComment(CommentContext.CASE,oldComment.toString());
                        LOGGER.info("Comments added in case2 from case 1::"+addcomment.getText());
                    }
                }

                LOGGER.info("Duplicate Value Updated" +sourceProperties.getStringValue(IConstants.DUPLICATECASEPROPERTY));
                // splitting up the values from property file to get symbolic name, datatype and singleormulti seperately

                List<String> listOfValuesSplittedByComma = Arrays.asList(propertylist.split(","));
                LOGGER.info("Values splitted by comma "+"\t"+ listOfValuesSplittedByComma);
                
                // Losing case property values will be copied to winning case properties only if the "copyCaseprops" property value is updated as "Y" in the property file
                if(copyCaseprop.equalsIgnoreCase(IConstants.YESVALUE)){
                for(int i=0;i<listOfValuesSplittedByComma.size();i++){
                    String s= listOfValuesSplittedByComma.get(i);

                    List<String> listOfvaluesSplittedByColon = Arrays.asList(s.split(":"));
                    LOGGER.info("values splitted by colon "+"\t"+listOfvaluesSplittedByColon);
                    String symbolicName=listOfvaluesSplittedByColon.get(0);
                    String dataType=listOfvaluesSplittedByColon.get(1);
                    String singleormulti=listOfvaluesSplittedByColon.get(2);
                    LOGGER.info("Symbolic name:::"+symbolicName);
                    LOGGER.info("DataType:::"+dataType);
                    LOGGER.info("SingleorMulti:"+singleormulti);
                    if(symbolicName.equalsIgnoreCase("IDI_AssociatedFlagUpdated")){
                        String targetflagValue=targetProperties.getStringValue(symbolicName);
                        if(("DocumentAdded").equalsIgnoreCase(targetflagValue)|| ("Mixed").equalsIgnoreCase(targetflagValue) ||("Associated").equalsIgnoreCase(targetflagValue)){
                            targetProperties.putValue(symbolicName, "Mixed");
                        }else{
                            String sourceflagValue=sourceProperties.getStringValue(symbolicName);
                            targetProperties.putValue(symbolicName, sourceflagValue);
                        }
                    }
                    else
                    {
                        if(("String").equalsIgnoreCase(dataType)){
                            
                            if(("Single").equalsIgnoreCase(singleormulti)){
                                if((targetProperties.getStringValue(symbolicName) == null) && (sourceProperties.getStringValue(symbolicName) != null)){
                                targetProperties.putValue(symbolicName, sourceProperties.getStringValue(symbolicName));
                               }
                            }else{
                                // multi valued- holds the exisiting values and also adds the new value 
                             
                                StringList totallist = Factory.StringList.createList();
                                totallist.addAll(targetProperties.getStringListValue(symbolicName));
                                totallist.addAll(sourceProperties.getStringListValue(symbolicName));
                                //checking whether the existing value contains the new value. If true- removes duplicate
                                for(int f=0;f<totallist.size();f++){

                                    for(int k=f+1;k<totallist.size();k++){
                                        if(totallist.get(f).equals(totallist.get(k))){
                                            totallist.remove(k);
                                        }


                                    }
                                }
                                targetProperties.putValue(symbolicName, totallist);
                             
                                
                            }
                        }
                   
                        else if(("Date").equalsIgnoreCase(dataType)){
                            if(("Single").equalsIgnoreCase(singleormulti)){
                                if((targetProperties.getDateTimeValue(symbolicName) == null) && (sourceProperties.getDateTimeValue(symbolicName) != null)){
                                targetProperties.putValue(symbolicName, sourceProperties.getDateTimeValue(symbolicName));
                                }
                            }else{
                               
                                DateTimeList totalDateList=Factory.DateTimeList.createList();
                                totalDateList.addAll(targetProperties.getDateTimeListValue(symbolicName));
                                totalDateList.addAll(sourceProperties.getDateTimeListValue(symbolicName));
                                for(int f=0;f<totalDateList.size();f++){

                                    for(int k=f+1;k<totalDateList.size();k++){
                                        if(totalDateList.get(f).equals(totalDateList.get(k))){
                                            totalDateList.remove(k);
                                        }


                                    }
                                }
                             
                                targetProperties.putValue(symbolicName, totalDateList);

           
                            }
                        }else if(("Integer").equalsIgnoreCase(dataType)){
                            if(("Single").equalsIgnoreCase(singleormulti)){
                                if((targetProperties.getInteger32Value(symbolicName) == null) && (sourceProperties.getInteger32Value(symbolicName) != null)){
                                targetProperties.putValue(symbolicName, sourceProperties.getInteger32Value(symbolicName));
                                 }
                            }else{
                
                                Integer32List totalIntegerList=Factory.Integer32List.createList();
                                totalIntegerList.addAll(targetProperties.getInteger32ListValue(symbolicName));
                                totalIntegerList.addAll(sourceProperties.getInteger32ListValue(symbolicName));
                                for(int f=0;f<totalIntegerList.size();f++){

                                    for(int k=f+1;k<totalIntegerList.size();k++){
                                        if(totalIntegerList.get(f).equals(totalIntegerList.get(k))){
                                            totalIntegerList.remove(k);
                                        }


                                    }
                                }
                              
                                targetProperties.putValue(symbolicName, totalIntegerList);
                                
                            }

                        }else if(("Boolean").equalsIgnoreCase(dataType)){
                            
                            if(("Single").equalsIgnoreCase(singleormulti)){
                                LOGGER.info("Single Boolean");
                                if(sourceProperties.getBooleanValue(symbolicName) && (!targetProperties.getBooleanValue(symbolicName))){
                                    targetProperties.putObjectValue(symbolicName, sourceProperties.getObjectValue(symbolicName));
                               
                                }
                            }else{
                           
                                BooleanList totalBooleanList=Factory.BooleanList.createList();
                                
                                totalBooleanList.addAll(sourceProperties.getBooleanListValue(symbolicName));
                                totalBooleanList.addAll(targetProperties.getBooleanListValue(symbolicName));
                                for(int f=0;f<totalBooleanList.size();f++){

                                    for(int k=f+1;k<totalBooleanList.size();k++){
                                        if(totalBooleanList.get(f).equals(totalBooleanList.get(k))){
                                            totalBooleanList.remove(k);
                                        }


                                    }
                                }
                              
                                targetfolder.getProperties().putValue(symbolicName, totalBooleanList);
                                
                            }
                        }else if(("Object").equalsIgnoreCase(dataType)){
                            if((targetProperties.getObjectValue(symbolicName) == null) && (sourceProperties.getObjectValue(symbolicName) != null)){
                            targetProperties.putObjectValue(symbolicName, sourceProperties.getObjectValue(symbolicName));
                            }

                        }else if(("GUID").equalsIgnoreCase(dataType)){
                            if(("Single").equalsIgnoreCase(singleormulti)){
                                if((targetProperties.getIdValue(symbolicName) == null) && (sourceProperties.getIdValue(symbolicName) != null)){
                                targetProperties.putValue(symbolicName, sourceProperties.getIdValue(symbolicName));
                                }
                            }else{
                               
                                IdList totalIdList=Factory.IdList.createList();
                                totalIdList.addAll(targetProperties.getIdListValue(symbolicName));
                                totalIdList.addAll(sourceProperties.getIdListValue(symbolicName));
                                
                                for(int f=0;f<totalIdList.size();f++){
                                    for(int k=f+1;k<totalIdList.size();k++){
                                        if(totalIdList.get(f).equals(totalIdList.get(k))){
                                            totalIdList.remove(k);
                                        }
                                    }

                                }
                              
                                targetProperties.putValue(symbolicName, totalIdList);
                               
                            }
                         }
                        
                    
                   
                    }
             
                }
                targetfolder.save(RefreshMode.REFRESH);
             
                }


                /**
                 * End of code for the defect # 46660 and Defect# 46541:  
                 */



                while (iterator.hasNext()) {
                    Folder mainFolder = iterator.next();
                    DocumentSet documentSet = mainFolder.get_ContainedDocuments();
                    @SuppressWarnings("unchecked")
                    Iterator<Document> mainDocument = documentSet.iterator();
                    while (mainDocument.hasNext()) {
                        Document doc = mainDocument.next();
                        valid.add(doc.get_Id().toString());
                    }
                    Folder subFolders = Factory.Folder.fetchInstance(targetOS, mainFolder.get_Id(), null);
                    FolderSet subFolder1 = subFolders.get_SubFolders();
                    Iterator<Folder> iterator1 = subFolder1.iterator();
                    while (iterator1.hasNext()) {
                        Folder subFolder = iterator1.next();
                        DocumentSet documentSet1 = subFolder.get_ContainedDocuments();
                        @SuppressWarnings("unchecked")
                        Iterator<Document> subDocument = documentSet1.iterator();
                        while (subDocument.hasNext()) {
                            Document doc = subDocument.next();
                            valid.add(doc.get_Id().toString());
                            LOGGER.info("Documents from Source" +doc.get_Id().toString());
                        }
                    }
                }
                for (String validDocumentID : valid) {
                    String targetCaseFolderPath = targetCasePath;
                    Document doc = com.filenet.api.core.Factory.Document.fetchInstance(targetOS, validDocumentID, null);

                    LOGGER.info("targetCaseFolderPath"+targetCaseFolderPath);
                    Folder targetCaseFolder = Factory.Folder.fetchInstance(targetOS, targetCaseFolderPath, null);
                    Properties properties = doc.getProperties();
                    if(properties.getStringValue(IConstants.ORIGNALASSOCCASE).equals(sourceCaseFolderId))
                    {
                    for (String property : propArray) {
                        properties.putValue(property, targetCaseFolder.getProperties().getStringValue(property));

                    }
                    doc.setUpdateSequenceNumber(null);
                    doc.save(RefreshMode.REFRESH);
                    }
                   
                    LOGGER.info("Target doc saved" +doc.get_Id());
                    String sourceCasePath = sourcefolder.get_PathName();
                    if(doc.getProperties().get(documentTypeProperty).getStringValue() == null){
                        LOGGER.info("Document type is null.  Setting the path for Internal referral form for SourceFolder");
                        sourceCasePath = sourceCasePath
                                + "/"+IConstants.INTERNAL_REFERRAL_FORM;
                    }
                    if (doc.getProperties().get(documentTypeProperty).getStringValue() != null) {
                        sourceCasePath = sourceCasePath + "/"
                                + doc.getProperties().get(documentTypeProperty).getStringValue();
                    }
                    if (doc.getProperties().get(subDocumentTypeProperty).getStringValue() != null) {
                        sourceCasePath = sourceCasePath + "/"
                                + doc.getProperties().get(subDocumentTypeProperty).getStringValue();
                    }

                    Folder sourcePathfolder = Factory.Folder.fetchInstance(targetOS, sourceCasePath, null);
                    com.filenet.api.core.ReferentialContainmentRelationship relFrom = sourcePathfolder.unfile(doc);
                    relFrom.save(RefreshMode.REFRESH);


                    //Condition check for null documentType value. If document type is null , file directly under Internal Referral Form folder
                    if(doc.getProperties().get(documentTypeProperty).getStringValue() == null){
                        LOGGER.info("Document Type is Null.Appending path with Internal Referral Form for targetfolder");
                        targetCaseFolderPath=targetCaseFolderPath+"/"+IConstants.INTERNAL_REFERRAL_FORM;
                        targetCaseFolder = Factory.Folder.fetchInstance(targetOS, targetCaseFolderPath, null);
                        com.filenet.api.core.ReferentialContainmentRelationship relTo = targetCaseFolder.file(doc,
                                AutoUniqueName.AUTO_UNIQUE, null, DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
                        relTo.save(RefreshMode.REFRESH);
                        String duplicateValue = properties.getStringValue(IConstants.DUPLICATE);
                        String claimNumber = targetCaseFolder.getProperties().getStringValue(IConstants.CLAIMNUMBER);
                        StringList associatedClaimNumbers=Factory.StringList.createList();   
                        //adding the existing associated claims property to a new list
                        associatedClaimNumbers.addAll(doc.getProperties().getStringListValue(IConstants.ASSOCIATEDCLAIMNUMBERS));

                        //There might be a scenario to associate the same case multiple times , In order to avoid
                        //duplicate , we are checking if the claim number already exists or not
                        boolean flag=true;
                        for(int l=0;l<associatedClaimNumbers.size();l++){
                            if(associatedClaimNumbers.get(l).equals(claimNumber)){
                                LOGGER.info("Claim Number & associated Claim number is equal" +claimNumber);
                                flag=false;
                                break;
                            }
                        }
                        if(flag)
                        {
                            associatedClaimNumbers.add(claimNumber);
                            doc.getProperties().putValue(IConstants.ASSOCIATEDCLAIMNUMBERS, associatedClaimNumbers);
                        }
                        doc.getProperties().putValue(IConstants.DUPLICATE, duplicateValue);
                        doc.getProperties().putValue(IConstants.ORIGNALASSOCCASE, targetCaseFolderId);
                        doc.setUpdateSequenceNumber(null);
                        doc.save(RefreshMode.REFRESH);
                    }

                    else
                    {
                        com.filenet.api.core.ReferentialContainmentRelationship relTo = targetCaseFolder.file(doc,
                                AutoUniqueName.AUTO_UNIQUE, null, DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
                        relTo.save(RefreshMode.REFRESH);
                        String doctypevalue = properties.getStringValue(documentTypeProperty);
                        String claimNumber = targetCaseFolder.getProperties().getStringValue(IConstants.CLAIMNUMBER);
                        doc.getProperties().putValue(IConstants.ORIGNALASSOCCASE, targetCaseFolderId);
                        doc.getProperties().putValue(documentTypeProperty, doctypevalue);
                        StringList associatedClaimNumbers=Factory.StringList.createList();   
                        //adding the existing associated claims property to a new list
                        associatedClaimNumbers.addAll(doc.getProperties().getStringListValue(IConstants.ASSOCIATEDCLAIMNUMBERS));

                        //There might be a scenario to associate the same case multiple times , In order to avoid
                        //duplicate , we are checking if the claim number already exists or not
                        boolean flag=true;
                        for(int l=0;l<associatedClaimNumbers.size();l++){
                            if(associatedClaimNumbers.get(l).equals(claimNumber)){
                                LOGGER.info("Claim Number & associated Claim number is equal" +claimNumber);
                                flag=false;
                                break;
                            }
                        }
                        if(flag)
                        {
                            associatedClaimNumbers.add(claimNumber);
                            doc.getProperties().putValue(IConstants.ASSOCIATEDCLAIMNUMBERS, associatedClaimNumbers);
                        }
                        doc.setUpdateSequenceNumber(null);
                        doc.save(RefreshMode.REFRESH);
                    }
                }
                /**
                 *   New logic for Reporting New Claim Setup Received/ Completed reports
                 */
                Case winningcaseobject = Case.fetchInstance(osr, new Id(targetCaseFolderId), null, null);
                List winningtaskList = taskqueryResults(modifiedwinningtaskQuery,targetOS);
                List losingtaskList = taskqueryResults(modifiedlosingtaskQuery, targetOS);
                for(int i=0; i<winningtaskList.size();i++)
                {
                    String taskId= winningtaskList.get(i).toString();
                    Task task = Task.fetchInstance(osr, new Id(taskId));
                    String taskname=task.getName();
                    TaskState state = task.getState();
                    if(taskname.equals(IConstants.CLAIMREVIEWNAME) && state.equals(TaskState.WORKING))
                    {
                        claimreviewstate=true;
                        LOGGER.info("Claim review is working state");
                    }
                    else if(taskname.equals(IConstants.NEWCLAIMSETUPNAME) && state.equals(TaskState.WAITING_PRECONDITION))
                    {
                        claimsetupstate=true;
                        LOGGER.info("ClaimSetup is in waiting state");
                        winningnewClaimSetuptask =task;
                        winningnewclaimsetupid = task.getId().toString();
                        winningnewClaimSetuptask.setUpdateSequenceNumber(null);
                        winningnewClaimSetuptask.save(RefreshMode.REFRESH);
                        
                    }
                }
                for(int j=0; j<losingtaskList.size();j++)
                {
                   
                    String taskId= losingtaskList.get(j).toString();
                    taskids.add(taskId);
                    Task task = Task.fetchInstance(osr, new Id(taskId));
                    String taskname=task.getName();
                    TaskState state = task.getState();
                    if((taskname.equals(IConstants.NEWCLAIMSETUPNAME)) && (state.equals(TaskState.WORKING) || state.equals(TaskState.COMPLETE)))
                    {
                        losingnewclaimsetup= true;
                        LOGGER.info("ClaimSetup" +task.getState());
                        losingnewClaimSetuptask = task;
                        losingnewClaimSetuptask.setUpdateSequenceNumber(null);
                        losingnewClaimSetuptask.save(RefreshMode.REFRESH);
                       
                    }
                            
                }

                if(claimreviewstate && claimsetupstate)
                {
                    LOGGER.info("Both conditions passed");
                    String actionvalue = null;
               
                            if(losingnewclaimsetup)
                            {
                                String[] taskpropsarray=DocumentFilingUtil.getProperty(IConstants.TASKPROPARRAY).split(",");
                                CaseMgmtProperties losingtaskproperties = losingnewClaimSetuptask.getProperties();           
                                targetfolder.getProperties().putValue(IConstants.UDSSTATUSCODE, "NONE");
                                targetfolder.setUpdateSequenceNumber(null);
                                targetfolder.save(RefreshMode.REFRESH); 
                                LOGGER.info("UDSSTATUS Code" +targetfolder.getProperties().getStringValue(IConstants.UDSSTATUSCODE));
                                winningnewClaimSetuptask.setUpdateSequenceNumber(null);
                                winningnewClaimSetuptask.save(RefreshMode.REFRESH);
                                CaseMgmtProperties winningtaskproperties = winningnewClaimSetuptask.getProperties();
                               
                                for (String property : taskpropsarray) {
                                    
                                    if(property.equals(IConstants.ACTION))
                                    {
                                        actionvalue="Task Started Due to Merge By "+losingtaskproperties.getObjectValue(IConstants.CONSULTANT);
                                        winningtaskproperties.putObjectValue(property, actionvalue);
                                    }
                                    //If the losing & winning claim created on the same date, then the Request Date will be copied from losing to winning claim. 
                                    else if(property.equals(IConstants.REQUESTDATE))
                                    {
                                        SimpleDateFormat dt = new SimpleDateFormat(IConstants.CMDATEFORMAT); 
                                        SimpleDateFormat sdf = new SimpleDateFormat(IConstants.UTC_DATEFORMAT);
                                        String stringdate = winningtaskproperties.getObjectValue(IConstants.DATECREATED).toString();
                                        Date todaydate = new Date();
                                        Calendar cal = Calendar.getInstance();
                                        cal.setTime(dt.parse(stringdate));
                                        Date stringtodate = cal.getTime();
                                        stringtodate = sdf.parse(sdf.format(stringtodate));
                                        todaydate = sdf.parse(sdf.format(todaydate));
                                        if(todaydate.equals(stringtodate)){
                                            LOGGER.info("Date Matched");
                                            winningtaskproperties.putObjectValue(property, losingtaskproperties.getObjectValue(property));
                                        }
                                        
                                    }
                                    else
                                    {
                                        winningtaskproperties.putObjectValue(property, losingtaskproperties.getObjectValue(property));
                                    }
                                    

                                }
                               VWSession vwSession = winningcaseobject.getCaseType().getVWSession(); 
                               processIdvalue(vwSession, osr, winningnewclaimsetupid);
                               /* if(processInstanceId==null)
                                {
                                      processInstanceId = processIdvalue(osr, winningnewclaimsetupid);
                                    
                                 }*/
                                
                                winningnewClaimSetuptask.setUpdateSequenceNumber(null);
                                winningnewClaimSetuptask.save(RefreshMode.REFRESH);
                              
                        
                            }
           
                   
        
                }
                
                // Comments is added to the winning case
                winningcaseobject.addCaseComment(CommentContext.CASE,IConstants.DUPLICATECLAIMCOMMENT); 
                
                // Case Or Task will get deleted only if the "deleteCaseorTask" property value is updated as "Y" in the property file 
                if(deleteCaseorTask.equalsIgnoreCase("Y"))
                {
                FolderSet mainSourceFolders = sourcefolder.get_SubFolders();
                @SuppressWarnings("unchecked")
                Iterator<Folder> mainSourceiterator = mainSourceFolders.iterator();
                while (mainSourceiterator.hasNext()) {
                    Folder mainSourceFolder = mainSourceiterator.next();
                    Folder subSourceFolders = Factory.Folder.fetchInstance(targetOS, mainSourceFolder.get_Id(), null);
                    FolderSet subSourceFolder1 = subSourceFolders.get_SubFolders();
                    @SuppressWarnings("unchecked")
                    Iterator<Folder> subSourceiterator = subSourceFolder1.iterator();
                    while (subSourceiterator.hasNext()) {
                        Folder subFolder = subSourceiterator.next();
                        subFolder.delete();
                        subFolder.setUpdateSequenceNumber(null);
                        subFolder.save(RefreshMode.REFRESH);
                    }
                    mainSourceFolder.delete();
                    mainSourceFolder.setUpdateSequenceNumber(null);
                    mainSourceFolder.save(RefreshMode.REFRESH);

                }

                terminateCase(sourceCaseFolderId);
                }
                
                // Case Or Task Events will get deleted only if the "deleteEvents" property value is updated as "Y" in the property file 
                if(deleteEvent.equalsIgnoreCase("Y"))
                {
                for (int n = 0; n < taskids.size(); n++) {
                    String taskId = (String) taskids.get(n);
                    LOGGER.info("Task Event Deletion*********************** task Id: " +taskId);
                    getAllEventIds(taskId,eventQuery,targetOS);
                    }
                LOGGER.info("Case Event Deletion*********************** case Id: " +sourceCaseFolderId);
                getAllEventIds(sourceCaseFolderId,eventQuery,targetOS);
               }
                
            
            }
      
      
                
               } catch (Exception e) {
            
           LOGGER.info(e);
            
        }
     LOGGER.info("Exiting method"+methodName);
    }
  




	/**
     * merge primary documents with existing primary case
     * 
     * @param sourceCaseFolderId
     * @param targetCaseFolderId
     * @param claimNumber
     * @param documentTypeProperty
     * @param subDocumentTypeProperty
     * @throws Exception
     */
	@SuppressWarnings("unchecked")
	public void mergeWithPrimaryCase(String sourceCaseFolderId, String targetCaseFolderId, String documentTypeProperty,
	        String subDocumentTypeProperty, String[] propArray, String targetDocumentClass)
	                throws MetCaseOperationsException, FileOperationsException{
	    String METHOD_NAME = "mergeWithPrimaryCase";
	    DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
	            ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
	    DocumentFilingUtil.loadMetCMProperties();
	    try {
	        ObjectStore targetOS = getConnection();
	        ObjectStoreReference osr = new ObjectStoreReference(targetOS);
	        LOGGER.info("Entering new method merge");
	        if (targetCaseFolderId != null) {
	            List<String> valid = new ArrayList<String>();
	            List taskids =  new ArrayList(); 
	            boolean claimreviewstate=false;
                boolean claimsetupstate=false;
                String commentvalue = null;     
                Task winningnewClaimSetuptask=null;
                Task losingnewClaimSetuptask=null;
                boolean losingnewclaimsetup = false;
                String winningnewclaimsetupid = null;
	            String eventQuery=DocumentFilingUtil.getProperty(IConstants.EVENTQUERY);
	            String winningtaskQuery = DocumentFilingUtil.getProperty(IConstants.WINNINGTASKQUERY);
	            String losingtaskQuery = DocumentFilingUtil.getProperty(IConstants.LOSINGTASKQUERY);
	            String deleteEvent=DocumentFilingUtil.getProperty(IConstants.DELETEEVENT);
	            String deleteCaseorTask = DocumentFilingUtil.getProperty(IConstants.DELETECASEORTASK);
	            String copyCaseprop = DocumentFilingUtil.getProperty(IConstants.COPYCASEPROPS);
	            String modifiedwinningtaskQuery = winningtaskQuery.replace("replacewinningcaseid", "'"+targetCaseFolderId+ "'");
	            String modifiedlosingtaskQuery =  losingtaskQuery.replace("replacelosingcaseid", "'"+sourceCaseFolderId+ "'");
	            Folder sourcefolder = Factory.Folder.fetchInstance(targetOS, sourceCaseFolderId, null);
	            Folder targetfolder = Factory.Folder.fetchInstance(targetOS, targetCaseFolderId, null);
	            String targetCasePath = targetfolder.get_PathName();
	            FolderSet mainFolders = sourcefolder.get_SubFolders();
	            Iterator<Folder> iterator = mainFolders.iterator();


	            Properties targetProperties=targetfolder.getProperties();

	            Properties sourceProperties=sourcefolder.getProperties();
	            sourceProperties.putValue(IConstants.DUPLICATECASEPROPERTY, "Duplicate");
                sourcefolder.save(RefreshMode.REFRESH);
            

	            /**
	             * Included for Defect# 46660 and Defect# 46541: Associated Claims 
	             */
	            String propertylist=DocumentFilingUtil.getProperty(IConstants.PROPERTIESLIST);
	            LOGGER.info("Properties list mentioned:"+propertylist);

	           
	            String casecomment=DocumentFilingUtil.getProperty(IConstants.CASECOMMENTVALUE);
	            String commentcreator = null;
	            Date commentdate;
	            String finalcommentDate=null;


	            /**
	             * condition included to check if case comment is 'Y' - adds source case comment to target case comments.
	             * Comments will be added to target case only if the comment value is passed as 'Y' in property file. 
	             */


	            if(casecomment.equalsIgnoreCase(IConstants.YESVALUE)){
	                ObjectStoreReference osReference = new ObjectStoreReference(targetOS);
	                Case sourcecase = Case.fetchInstance(osReference, new Id(sourceCaseFolderId), null,null);
	                Case targetcase = Case.fetchInstance(osReference, new Id(targetCaseFolderId), null,null);
	                List<Comment> comment =sourcecase.fetchCaseComments();
	                for(int l=0;l<comment.size();l++){
	                    StringBuilder oldComment=new StringBuilder();
	                    oldComment.append(comment.get(l).getText()).append("_");
	                    DateFormat df = new SimpleDateFormat(IConstants.COMMENTDATE);
	                    commentdate = comment.get(l).getDateCreated();
	                    finalcommentDate = df.format(commentdate);
	                    commentcreator = comment.get(l).getCreator();
	                    oldComment.append(commentcreator).append("_").append(finalcommentDate);
	                    Comment addcomment=targetcase.addCaseComment(CommentContext.CASE,oldComment.toString());
	                    LOGGER.info("Comments added in case2 from case 1::"+addcomment.getText());
	                }
	            }

	            LOGGER.info("Duplicate Value Updated" +sourceProperties.getStringValue(IConstants.DUPLICATECASEPROPERTY));
	            // splitting up the values from property file to get symbolic name, datatype and singleormulti seperately

	            List<String> listOfValuesSplittedByComma = Arrays.asList(propertylist.split(","));
	            LOGGER.info("Values splitted by comma "+"\t"+ listOfValuesSplittedByComma);
	            
	            // Losing case property values will be copied to winning case properties only if the "copyCaseprops" property value is updated as "Y" in the property file
	            if(copyCaseprop.equalsIgnoreCase(IConstants.YESVALUE)){
	            for(int i=0;i<listOfValuesSplittedByComma.size();i++){
                    String s= listOfValuesSplittedByComma.get(i);

                    List<String> listOfvaluesSplittedByColon = Arrays.asList(s.split(":"));
                    LOGGER.debug("values splitted by colon "+"\t"+listOfvaluesSplittedByColon);
                    String symbolicName=listOfvaluesSplittedByColon.get(0);
                    String dataType=listOfvaluesSplittedByColon.get(1);
                    String singleormulti=listOfvaluesSplittedByColon.get(2);
                    LOGGER.debug("Symbolic name:::"+symbolicName);
                    LOGGER.debug("DataType:::"+dataType);
                    LOGGER.debug("SingleorMulti:"+singleormulti);
                   if(symbolicName.equalsIgnoreCase("IDI_AssociatedFlagUpdated")){
	                    String targetflagValue=targetProperties.getStringValue(symbolicName);
	                    if(("DocumentAdded").equalsIgnoreCase(targetflagValue)|| ("Mixed").equalsIgnoreCase(targetflagValue) ||("Associated").equalsIgnoreCase(targetflagValue)){
	                        targetProperties.putValue(symbolicName, "Mixed");
	                    }else{
	                        String sourceflagValue=sourceProperties.getStringValue(symbolicName);
	                        targetProperties.putValue(symbolicName, sourceflagValue);
	                    }
	                }
                   else
                   {
                        if(("String").equalsIgnoreCase(dataType)){
                            
                            if(("Single").equalsIgnoreCase(singleormulti)){
                                if((targetProperties.getStringValue(symbolicName) == null) && (sourceProperties.getStringValue(symbolicName) != null)){
                                targetProperties.putValue(symbolicName, sourceProperties.getStringValue(symbolicName));
                               }
                            }else{
                                // multi valued- holds the exisiting values and also adds the new value 
                              
                                StringList totallist = Factory.StringList.createList();
                                totallist.addAll(targetProperties.getStringListValue(symbolicName));
                                totallist.addAll(sourceProperties.getStringListValue(symbolicName));
                                //checking whether the existing value contains the new value. If true- removes duplicate
                                for(int f=0;f<totallist.size();f++){

                                    for(int k=f+1;k<totallist.size();k++){
                                        if(totallist.get(f).equals(totallist.get(k))){
                                            totallist.remove(k);
                                        }


                                    }
                                }
                                targetProperties.putValue(symbolicName, totallist);
                               
                                
                            }
                        }
                   
                        else if(("Date").equalsIgnoreCase(dataType)){
                            if(("Single").equalsIgnoreCase(singleormulti)){
                                if((targetProperties.getDateTimeValue(symbolicName) == null) && (sourceProperties.getDateTimeValue(symbolicName) != null)){
                                targetProperties.putValue(symbolicName, sourceProperties.getDateTimeValue(symbolicName));
                                }
                            }else{
                               
                                DateTimeList totalDateList=Factory.DateTimeList.createList();
                                totalDateList.addAll(targetProperties.getDateTimeListValue(symbolicName));
                                totalDateList.addAll(sourceProperties.getDateTimeListValue(symbolicName));
                                for(int f=0;f<totalDateList.size();f++){

                                    for(int k=f+1;k<totalDateList.size();k++){
                                        if(totalDateList.get(f).equals(totalDateList.get(k))){
                                            totalDateList.remove(k);
                                        }


                                    }
                                }
                             
                                targetProperties.putValue(symbolicName, totalDateList);

                               
                            }
                        }else if(("Integer").equalsIgnoreCase(dataType)){
                            if(("Single").equalsIgnoreCase(singleormulti)){
                                if((targetProperties.getInteger32Value(symbolicName) == null) && (sourceProperties.getInteger32Value(symbolicName) != null)){
                                targetProperties.putValue(symbolicName, sourceProperties.getInteger32Value(symbolicName));
                                 }
                            }else{
                              
                                Integer32List totalIntegerList=Factory.Integer32List.createList();
                                totalIntegerList.addAll(targetProperties.getInteger32ListValue(symbolicName));
                                totalIntegerList.addAll(sourceProperties.getInteger32ListValue(symbolicName));
                                for(int f=0;f<totalIntegerList.size();f++){

                                    for(int k=f+1;k<totalIntegerList.size();k++){
                                        if(totalIntegerList.get(f).equals(totalIntegerList.get(k))){
                                            totalIntegerList.remove(k);
                                        }


                                    }
                                }
                              
                                targetProperties.putValue(symbolicName, totalIntegerList);
                                
                            }

                        }else if(("Boolean").equalsIgnoreCase(dataType)){
                            if(("Single").equalsIgnoreCase(singleormulti)){
                               
                                if(sourceProperties.getBooleanValue(symbolicName) && (!targetProperties.getBooleanValue(symbolicName))){
     
                                    targetProperties.putObjectValue(symbolicName, sourceProperties.getObjectValue(symbolicName));
 }
                            }else{
                               
                                BooleanList totalBooleanList=Factory.BooleanList.createList();
                                
                                totalBooleanList.addAll(sourceProperties.getBooleanListValue(symbolicName));
                                totalBooleanList.addAll(targetProperties.getBooleanListValue(symbolicName));
                                for(int f=0;f<totalBooleanList.size();f++){

                                    for(int k=f+1;k<totalBooleanList.size();k++){
                                        if(totalBooleanList.get(f).equals(totalBooleanList.get(k))){
                                            totalBooleanList.remove(k);
                                        }


                                    }
                                }
                              
                                targetfolder.getProperties().putValue(symbolicName, totalBooleanList);
                                
                            }
                        }else if(("Object").equalsIgnoreCase(dataType)){
                            if((targetProperties.getObjectValue(symbolicName) == null) && (sourceProperties.getObjectValue(symbolicName) != null)){
                            targetProperties.putObjectValue(symbolicName, sourceProperties.getObjectValue(symbolicName));
                            }

                        }else if(("GUID").equalsIgnoreCase(dataType)){
                            if(("Single").equalsIgnoreCase(singleormulti)){
                                if((targetProperties.getIdValue(symbolicName) == null) && (sourceProperties.getIdValue(symbolicName) != null)){
                                targetProperties.putValue(symbolicName, sourceProperties.getIdValue(symbolicName));
                                }
                            }else{
                               
                                IdList totalIdList=Factory.IdList.createList();
                                totalIdList.addAll(targetProperties.getIdListValue(symbolicName));
                                totalIdList.addAll(sourceProperties.getIdListValue(symbolicName));
                                
                                for(int f=0;f<totalIdList.size();f++){
                                    for(int k=f+1;k<totalIdList.size();k++){
                                        if(totalIdList.get(f).equals(totalIdList.get(k))){
                                            totalIdList.remove(k);
                                        }
                                    }

                                }
                              
                                targetProperties.putValue(symbolicName, totalIdList);
                                
                            }
                         }
             
                }
                }
	            targetfolder.save(RefreshMode.REFRESH);
	            }


	            /**
	             * End of code for the defect # 46660 and Defect# 46541:  
	             */



	            while (iterator.hasNext()) {
	             
	                Folder mainFolder = iterator.next();
	                DocumentSet documentSet = mainFolder.get_ContainedDocuments();
	                @SuppressWarnings("unchecked")
	                Iterator<Document> mainDocument = documentSet.iterator();
	                while (mainDocument.hasNext()) {
	                
	                    Document doc = mainDocument.next();
	                    valid.add(doc.get_Id().toString());
	                }
	                Folder subFolders = Factory.Folder.fetchInstance(targetOS, mainFolder.get_Id(), null);
	                FolderSet subFolder1 = subFolders.get_SubFolders();
	                Iterator<Folder> iterator1 = subFolder1.iterator();
	                while (iterator1.hasNext()) {
	                   
	                    Folder subFolder = iterator1.next();
	                    DocumentSet documentSet1 = subFolder.get_ContainedDocuments();
	                    @SuppressWarnings("unchecked")
	                    Iterator<Document> subDocument = documentSet1.iterator();
	                    while (subDocument.hasNext()) {
	                        Document doc = subDocument.next();
	                        valid.add(doc.get_Id().toString());
	                    }
	                }
	            }
	            LOGGER.info("Valid document size" +valid.size());
	            for (String validDocumentID : valid) {
	                String targetCaseFolderPath = targetCasePath;
	                Document doc = com.filenet.api.core.Factory.Document.fetchInstance(targetOS, validDocumentID, null);

	                LOGGER.info("targetCaseFolderPath"+targetCaseFolderPath);
	                Folder targetCaseFolder = Factory.Folder.fetchInstance(targetOS, targetCaseFolderPath, null);
	                Properties properties = doc.getProperties();
	                if(properties.getStringValue(IConstants.ORIGNALASSOCCASE).equals(sourceCaseFolderId))
	                {
	                for (String property : propArray) {
	                    properties.putValue(property, targetCaseFolder.getProperties().getStringValue(property));

	                }
	                doc.setUpdateSequenceNumber(null);
                    doc.save(RefreshMode.REFRESH);
	                }
	               
	                LOGGER.info("Target doc saved");
	                String sourceCasePath = sourcefolder.get_PathName();
	                if(doc.getProperties().get(documentTypeProperty).getStringValue() == null){
	                    LOGGER.info("Document type is null.  Setting the path for Internal referral form for SourceFolder");
	                    sourceCasePath = sourceCasePath
	                            + "/"+IConstants.INTERNAL_REFERRAL_FORM;
	                }
	                if (doc.getProperties().get(documentTypeProperty).getStringValue() != null) {
	                    sourceCasePath = sourceCasePath + "/"
	                            + doc.getProperties().get(documentTypeProperty).getStringValue();
	                }
	                if (doc.getProperties().get(subDocumentTypeProperty).getStringValue() != null) {
	                    sourceCasePath = sourceCasePath + "/"
	                            + doc.getProperties().get(subDocumentTypeProperty).getStringValue();
	                }

	                Folder sourcePathfolder = Factory.Folder.fetchInstance(targetOS, sourceCasePath, null);
	                com.filenet.api.core.ReferentialContainmentRelationship relFrom = sourcePathfolder.unfile(doc);
	                relFrom.save(RefreshMode.REFRESH);


	                //Condition check for null documentType value. If document type is null , file directly under Internal Referral Form folder
	                if(doc.getProperties().get(documentTypeProperty).getStringValue() == null){
	                    LOGGER.info("Document Type is Null.Appending path with Internal Referral Form for targetfolder");
	                    targetCaseFolderPath=targetCaseFolderPath+"/"+IConstants.INTERNAL_REFERRAL_FORM;
	                    targetCaseFolder = Factory.Folder.fetchInstance(targetOS, targetCaseFolderPath, null);
	                    com.filenet.api.core.ReferentialContainmentRelationship relTo = targetCaseFolder.file(doc,
	                            AutoUniqueName.AUTO_UNIQUE, null, DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
	                    relTo.save(RefreshMode.REFRESH);
	                    String duplicateValue = properties.getStringValue(IConstants.DUPLICATE);
	                    String claimNumber = targetCaseFolder.getProperties().getStringValue(IConstants.CLAIMNUMBER);
	                    StringList associatedClaimNumbers=Factory.StringList.createList();   
                        //adding the existing associated claims property to a new list
                        associatedClaimNumbers.addAll(doc.getProperties().getStringListValue(IConstants.ASSOCIATEDCLAIMNUMBERS));

                        //There might be a scenario to associate the same case multiple times , In order to avoid
                        //duplicate , we are checking if the claim number already exists or not
                        boolean flag=true;
                        for(int l=0;l<associatedClaimNumbers.size();l++){
                            if(associatedClaimNumbers.get(l).equals(claimNumber)){
                                LOGGER.info("Claim Number & associated Claim number is equal" +claimNumber);
                                flag=false;
                                break;
                            }
                        }
                        if(flag)
                        {
                            associatedClaimNumbers.add(claimNumber);
                            doc.getProperties().putValue(IConstants.ASSOCIATEDCLAIMNUMBERS, associatedClaimNumbers);
                        }
	                    doc.getProperties().putValue(IConstants.DUPLICATE, duplicateValue);
	                    doc.getProperties().putValue(IConstants.ORIGNALASSOCCASE, targetCaseFolderId);
	                    doc.setUpdateSequenceNumber(null);
	                    doc.save(RefreshMode.REFRESH);
	                }

	                else
	                {
	                    com.filenet.api.core.ReferentialContainmentRelationship relTo = targetCaseFolder.file(doc,
	                            AutoUniqueName.AUTO_UNIQUE, null, DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
	                    relTo.save(RefreshMode.REFRESH);
	                    String doctypevalue = properties.getStringValue(documentTypeProperty);
	                    String claimNumber = targetCaseFolder.getProperties().getStringValue(IConstants.CLAIMNUMBER);
	                    doc.getProperties().putValue(IConstants.ORIGNALASSOCCASE, targetCaseFolderId);
	                    doc.getProperties().putValue(documentTypeProperty, doctypevalue);
	                    StringList associatedClaimNumbers=Factory.StringList.createList();   
	                    //adding the existing associated claims property to a new list
	                    associatedClaimNumbers.addAll(doc.getProperties().getStringListValue(IConstants.ASSOCIATEDCLAIMNUMBERS));

	                    //There might be a scenario to associate the same case multiple times , In order to avoid
	                    //duplicate , we are checking if the claim number already exists or not
	                    boolean flag=true;
	                    for(int l=0;l<associatedClaimNumbers.size();l++){
	                        if(associatedClaimNumbers.get(l).equals(claimNumber)){
	                            LOGGER.info("Claim Number & associated Claim number is equal" +claimNumber);
	                            flag=false;
	                            break;
	                        }
	                    }
	                    if(flag)
	                    {
	                        associatedClaimNumbers.add(claimNumber);
	                        doc.getProperties().putValue(IConstants.ASSOCIATEDCLAIMNUMBERS, associatedClaimNumbers);
	                    }
	                    doc.setUpdateSequenceNumber(null);
	                    doc.save(RefreshMode.REFRESH);
	                }
	            }
	            /**
	             *  New logic for Reporting New Claim Setup Received/ Completed reports
	             */
                Case winningcaseobject = Case.fetchInstance(osr, new Id(targetCaseFolderId), null, null);
	            List winningtaskList = taskqueryResults(modifiedwinningtaskQuery,targetOS);
	            List losingtaskList = taskqueryResults(modifiedlosingtaskQuery, targetOS);
	            for(int i=0; i<winningtaskList.size();i++)
	            {
	                String taskId= winningtaskList.get(i).toString();
	                Task task = Task.fetchInstance(osr, new Id(taskId));
	                String taskname=task.getName();
	                TaskState state = task.getState();
	                if(taskname.equals(IConstants.CLAIMREVIEWNAME) && state.equals(TaskState.WORKING))
                    {
                        claimreviewstate=true;
                        LOGGER.info("Claim review is working state");
                    }
	                else if(taskname.equals(IConstants.NEWCLAIMSETUPNAME) && state.equals(TaskState.WAITING_PRECONDITION))
                    {
                        claimsetupstate=true;
                        LOGGER.info("ClaimSetup is in waiting state");
                        winningnewClaimSetuptask =task;
                        winningnewclaimsetupid = task.getId().toString();
                        winningnewClaimSetuptask.setUpdateSequenceNumber(null);
                        winningnewClaimSetuptask.save(RefreshMode.REFRESH);
                        
                    }
	            }
	            for(int j=0; j<losingtaskList.size();j++)
                {
	               
	                String taskId= losingtaskList.get(j).toString();
	                taskids.add(taskId);
	                Task task = Task.fetchInstance(osr, new Id(taskId));
	                String taskname=task.getName();
	                TaskState state = task.getState();
	                if((taskname.equals(IConstants.NEWCLAIMSETUPNAME)) && (state.equals(TaskState.WORKING) || state.equals(TaskState.COMPLETE)))
                    {
	                    losingnewclaimsetup= true;
                        LOGGER.info("ClaimSetup" +task.getState());
                        losingnewClaimSetuptask = task; 
                        losingnewClaimSetuptask.setUpdateSequenceNumber(null);
                        losingnewClaimSetuptask.save(RefreshMode.REFRESH);
                        commentvalue = "Merge Requested by " +losingnewClaimSetuptask.getProperties().getObjectValue(IConstants.CONSULTANT);
                      
                        
                    }
	                        
                }

	            if(claimreviewstate && claimsetupstate)
	            {
	                LOGGER.info("Both conditions passed");
	                String actionvalue = null; 
	                        if(losingnewclaimsetup)
	                        {
	                            String[] taskpropsarray=DocumentFilingUtil.getProperty(IConstants.TASKPROPARRAY).split(",");
	                            CaseMgmtProperties losingtaskproperties = losingnewClaimSetuptask.getProperties();           
	                            targetfolder.getProperties().putValue(IConstants.UDSSTATUSCODE, "NONE");
	                            targetfolder.setUpdateSequenceNumber(null);
	                            targetfolder.save(RefreshMode.REFRESH); 
	                            LOGGER.info("UDSSTATUS Code" +targetfolder.getProperties().getStringValue(IConstants.UDSSTATUSCODE));
	                            winningnewClaimSetuptask.setUpdateSequenceNumber(null);
                                winningnewClaimSetuptask.save(RefreshMode.REFRESH);
	                             CaseMgmtProperties winningtaskproperties = winningnewClaimSetuptask.getProperties();
	                         
	                            
	                            for (String property : taskpropsarray) {
	                                
	                                if(property.equals(IConstants.ACTION))
	                                {
	                                    actionvalue="Task Started Due to Merge By "+losingtaskproperties.getObjectValue(IConstants.CONSULTANT);
	                                    winningtaskproperties.putObjectValue(property, actionvalue);
	                                }
	                                //If the losing & winning claim created on the same date, then the Request Date will be copied from losing to winning claim. 
	                                else if(property.equals(IConstants.REQUESTDATE))
	                                {
	                                    SimpleDateFormat dt = new SimpleDateFormat(IConstants.CMDATEFORMAT); 
	                                    SimpleDateFormat sdf = new SimpleDateFormat(IConstants.UTC_DATEFORMAT);
	                                    String stringdate = winningtaskproperties.getObjectValue(IConstants.DATECREATED).toString();
	                                    Date todaydate = new Date();
	                                    Calendar cal = Calendar.getInstance();
	                                    cal.setTime(dt.parse(stringdate));
	                                    Date stringtodate = cal.getTime();
	                                    stringtodate = sdf.parse(sdf.format(stringtodate));
	                                    todaydate = sdf.parse(sdf.format(todaydate));
	                                    if(todaydate.equals(stringtodate)){
	                                        LOGGER.info("Date Matched");
	                                        winningtaskproperties.putObjectValue(property, losingtaskproperties.getObjectValue(property));
	                                    }
	                                    
	                                }
	                                else
	                                {
	                                    winningtaskproperties.putObjectValue(property, losingtaskproperties.getObjectValue(property));
	                                }
	                                

	                            }
	                           VWSession vwSession = winningcaseobject.getCaseType().getVWSession(); 
	                           processIdvalue(vwSession, osr, winningnewclaimsetupid);
	                           /* if(processInstanceId==null)
	                            {
	                                  processInstanceId = processIdvalue(osr, winningnewclaimsetupid);
	                                
	                             }*/
	                            
	                            winningnewClaimSetuptask.setUpdateSequenceNumber(null);
	                            winningnewClaimSetuptask.save(RefreshMode.REFRESH);
	                          
	                    
	                        }
           
	            
        
	            }
	            // Comments is added to the winning case
	            Comment addcomment=winningcaseobject.addCaseComment(CommentContext.CASE,commentvalue); 
	            // Case Or Task will get deleted only if the "deleteCaseorTask" property value is updated as "Y" in the property file 
	            if(deleteCaseorTask.equalsIgnoreCase("Y"))
	            {
	            FolderSet mainSourceFolders = sourcefolder.get_SubFolders();
	            @SuppressWarnings("unchecked")
	            Iterator<Folder> mainSourceiterator = mainSourceFolders.iterator();
	            while (mainSourceiterator.hasNext()) {
	                Folder mainSourceFolder = mainSourceiterator.next();
	                Folder subSourceFolders = Factory.Folder.fetchInstance(targetOS, mainSourceFolder.get_Id(), null);
	                FolderSet subSourceFolder1 = subSourceFolders.get_SubFolders();
	                @SuppressWarnings("unchecked")
	                Iterator<Folder> subSourceiterator = subSourceFolder1.iterator();
	                while (subSourceiterator.hasNext()) {
	                    Folder subFolder = subSourceiterator.next();
	                    subFolder.delete();
	                    subFolder.setUpdateSequenceNumber(null);
	                    subFolder.save(RefreshMode.REFRESH);
	                }
	                mainSourceFolder.delete();
	                mainSourceFolder.setUpdateSequenceNumber(null);
	                mainSourceFolder.save(RefreshMode.REFRESH);

	            }

	            terminateCase(sourceCaseFolderId);
	            }
	            
	            // Case Or Task Events will get deleted only if the "deleteEvents" property value is updated as "Y" in the property file 
	            if(deleteEvent.equalsIgnoreCase("Y"))
	            {
	            for (int n = 0; n < taskids.size(); n++) {
	                String taskId = (String) taskids.get(n);
	                LOGGER.info("Task Event Deletion*********************** task Id: " +taskId);
	                getAllEventIds(taskId,eventQuery,targetOS);
	                }
	            LOGGER.info("Case Event Deletion*********************** case Id: " +sourceCaseFolderId);
	            getAllEventIds(sourceCaseFolderId,eventQuery,targetOS);
	           }
	            
	        
	        }
	    } catch (Exception e) {
	        LOGGER.error(e);
	        throw new MetCaseOperationsException(e);
	    }
	    DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
	            ILoggerConstants.METHOD_EXIT + METHOD_NAME);
	}

	
	
	/**
	 * To retrieve the processinstanceid
	 * @param vwSession
	 * @param osr
	 * @param winningnewclaimsetupid
	 * @throws MetCaseOperationsException
	 */
	private void processIdvalue(VWSession vwSession, ObjectStoreReference osr, String winningnewclaimsetupid) throws MetCaseOperationsException
	{
	    String METHOD_NAME = "processIdvalue";
        DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
                ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
        String wobnum=null;
        int count = 0;
	    try{   
	        
	       Task newtask = Task.fetchInstance(osr, new Id(winningnewclaimsetupid));
	       wobnum = newtask.getProcessInstanceId();
	       LOGGER.info("Wob Number" +wobnum);     
	       if(wobnum==null)
	       {
	          
	           /*int StoppingTime = 1;
	           LOGGER.info("Stopping time" +StoppingTime);
	           int loop = 1;
	           long StartTime = System.currentTimeMillis() / 1000 ;
	           for (int i=0; i<loop; ++i) {
	               // your code here
	               loop++;
	          
	               if (((System.currentTimeMillis()/1000) - StartTime) > StoppingTime)
	                   loop=0;
	           }*/
	           Thread.sleep(1000);
	           if(count<5)
	           {
	               LOGGER.info("Number of times tried to retrieve the processinstanceid" +count);
	               count++;
	               processIdvalue(vwSession,osr, winningnewclaimsetupid);
	               
	             
	           }

	       }
	       else
	       { 
              
              LOGGER.info("Process ID" +wobnum);
              processsingInstance(wobnum,vwSession, osr);
           }
          
	         
	        
	        }catch (Exception e) {
	            LOGGER.error(e);
	            throw new MetCaseOperationsException(e);
	        }
	
	    DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
                ILoggerConstants.METHOD_EXIT + METHOD_NAME);
    
	
	}
	
	/**
	 * Task is completed from component step user's inbox
	 * @param processid
	 * @param vwSession
	 * @param osr
	 * @throws MetCaseOperationsException
	 */
	private void processsingInstance(String processid,VWSession vwSession, ObjectStoreReference osr)throws MetCaseOperationsException
    {
	    String METHOD_NAME = "processsingInstance";
        DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
                ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
        try{   
         
         WorkItem item = WorkItem.fetchInstance(vwSession, IConstants.INBOX, processid, osr, null);
                item.lockStep();
                item.saveStep();
                item.completeStep();
                LOGGER.info("Task completed from Inbox");
               
        
        }catch (Exception e) {
            LOGGER.error(e);
            throw new MetCaseOperationsException(e);
        }
        DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
                ILoggerConstants.METHOD_EXIT + METHOD_NAME);
    }
	
	/**
	 * Retrieving all events from case or task with respect to query
	 * @param id
	 * @param eventQuery
	 * @param os
	 * @throws MetCaseOperationsException
	 */
	private void getAllEventIds(String id, String eventQuery, ObjectStore os) throws MetCaseOperationsException
	{ 
	    String METHOD_NAME = "getAllEventIds";
        DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
                ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
	    eventQuery = eventQuery + "'" + id + "'" ;
	    LOGGER.info("Event Query" +eventQuery);
	    List EventIds = new ArrayList();
	    try{   
	    SearchScope scope = new SearchScope(os);
	    SearchSQL sql = new SearchSQL(eventQuery);
	    RepositoryRowSet rows = scope.fetchRows(sql, Integer.valueOf(10), null, Boolean.valueOf(true));
	    @SuppressWarnings("rawtypes")
	    Iterator<Document> itRow = rows.iterator();
	    RepositoryRow row;
	    LOGGER.info("Outside While");
	    while (itRow.hasNext()) {
	        LOGGER.info("Inside While");
	        row = (RepositoryRow) itRow.next();
	        Properties props = row.getProperties();
	        @SuppressWarnings("rawtypes")
	        Iterator itProp = props.iterator();
	        Property prop;
	        while (itProp.hasNext()) {
	            prop = (Property) itProp.next();

	        }

	        Object valVo = props.get("ID").getObjectValue();
	        LOGGER.info("Event ID" +props.get("ID").getObjectValue().toString());
	        EventIds.add(valVo);

	    }
	    deleteEvent(EventIds,os);
	    }
	    catch (Exception e) {
            LOGGER.error(e);
            throw new MetCaseOperationsException(e);
        }
	    DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
                ILoggerConstants.METHOD_EXIT + METHOD_NAME);
	    

	}
	
	/**
	 * To retrieve the task list by querying on case. 
	 * @param query
	 * @param os
	 * @return
	 * @throws MetCaseOperationsException
	 */
	private List taskqueryResults(String query,ObjectStore os) throws MetCaseOperationsException
	{
	    String METHOD_NAME = "queryResults";
        DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
                ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
      
     
        List TaskIds = new ArrayList();
        try{   
        SearchScope scope = new SearchScope(os);
        SearchSQL sql = new SearchSQL(query);
        RepositoryRowSet rows = scope.fetchRows(sql, Integer.valueOf(10), null, Boolean.valueOf(true));
        @SuppressWarnings("rawtypes")
        Iterator<Document> itRow = rows.iterator();
        RepositoryRow row;

        while (itRow.hasNext()) {
            row = (RepositoryRow) itRow.next();
            Properties props = row.getProperties();
            @SuppressWarnings("rawtypes")
            Iterator itProp = props.iterator();
            Property prop;
            while (itProp.hasNext()) {
                prop = (Property) itProp.next();
                if(prop.getPropertyName().equals("Id"))
                {
                   
                    TaskIds.add(prop.getObjectValue());
                }

            }

           
           

        }
       
        }
        catch (Exception e) {
            LOGGER.error(e);
            throw new MetCaseOperationsException(e);
        }
        DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
                ILoggerConstants.METHOD_EXIT + METHOD_NAME);
        return TaskIds;
	    
	}
	
	/**
	 * Deleting case or task events 
	 * @param EventIds
	 * @param os
	 * @throws MetCaseOperationsException
	 */
	private void deleteEvent(List EventIds,ObjectStore os)  throws MetCaseOperationsException
    {
	    String METHOD_NAME = "deleteEvent";
        DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
                ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
	    try{   
        for (int ce = 0; ce < EventIds.size(); ce++) {
            Object cEventid = (Object) EventIds.get(ce);
            LOGGER.info("Deleting event id --> " + cEventid);
            Id objId = null;
            if(cEventid instanceof String )
                objId=new Id(cEventid.toString());
            else if(cEventid instanceof Id)
                objId =(Id)cEventid;
            
            Event evt = Factory.Event.fetchInstance(os, objId, null);
            evt.delete();
            evt.save(RefreshMode.NO_REFRESH);
            
        }
	    }
	    catch (Exception e) {
            LOGGER.error(e);
            throw new MetCaseOperationsException(e);
        }
        
	    DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
                ILoggerConstants.METHOD_EXIT + METHOD_NAME);
    }
	    
	/**
	 * copy all case properties to document properties
	 * 
	 * @param sourceCaseFolderId
	 * @param propArray
	 * @throws Exception
	 */

	public void copyCasePropertiesToDocument(String sourceCaseFolderId, String[] propArray, String[] Documentclasses)
			throws MetCaseOperationsException {
		String METHOD_NAME = "copyCasePropertiesToDocument";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			ObjectStore targetOS = getConnection();

			List<String> documents = new ArrayList<String>();
			Folder sourcefolder = Factory.Folder.fetchInstance(targetOS, sourceCaseFolderId, null);

			FolderSet mainFolders = sourcefolder.get_SubFolders();
			Iterator<Folder> iterator = mainFolders.iterator();
			while (iterator.hasNext()) {
				Folder mainFolder = iterator.next();
				DocumentSet documentSet = mainFolder.get_ContainedDocuments();
				@SuppressWarnings("unchecked")
				Iterator<Document> mainDocument = documentSet.iterator();
				while (mainDocument.hasNext()) {
					Document doc = mainDocument.next();
					documents.add(doc.get_Id().toString());
				}
				Folder subFolders = Factory.Folder.fetchInstance(targetOS, mainFolder.get_Id(), null);
				FolderSet subFolder1 = subFolders.get_SubFolders();
				Iterator<Folder> iterator1 = subFolder1.iterator();
				while (iterator1.hasNext()) {
					Folder subFolder = iterator1.next();
					DocumentSet documentSet1 = subFolder.get_ContainedDocuments();
					@SuppressWarnings("unchecked")
					Iterator<Document> subDocument = documentSet1.iterator();
					while (subDocument.hasNext()) {
						Document doc = subDocument.next();
						documents.add(doc.get_Id().toString());
					}
				}
			}
			  String claimNumber = sourcefolder.getProperties().getStringValue(IConstants.CLAIMNUMBER);
			  LOGGER.info("Updating document properties from claim number "+claimNumber);
              //Change made related to defect #46541  (associated documents not appearing in book view)
              //While copying the properties , we are checking if the claim number is present in 
              //the associated claims property and adding the claim number if not present
			for (String docID : documents) {

				Document doc = com.filenet.api.core.Factory.Document.fetchInstance(targetOS, docID, null);
				for (String doclass : Documentclasses) {
					if (doc.getClassName().equals(doclass)) {

						Properties properties = doc.getProperties();
						if(properties.getStringValue(IConstants.ORIGNALASSOCCASE).equals(sourceCaseFolderId))
						{
						for (String property : propArray) {

							properties.putValue(property, sourcefolder.getProperties().getStringValue(property));

						}
						}
						 boolean flag=true;
					     StringList associatedClaimNumbers=Factory.StringList.createList();   
	                        //adding the existing associated claims property to a new list
	                        associatedClaimNumbers.addAll(doc.getProperties().getStringListValue(IConstants.ASSOCIATEDCLAIMNUMBERS));
	                      
	                        for(int l=0;l<associatedClaimNumbers.size();l++){
	                            if(associatedClaimNumbers.get(l).equals(claimNumber)){
	                                LOGGER.info("Claim Number & associated Claim number is equal" +claimNumber);
	                                flag=false;
	                                break;
	                            }
	                        }
	                        if(flag)
	                        {
	                            associatedClaimNumbers.add(claimNumber);
	                            doc.getProperties().putValue(IConstants.ASSOCIATEDCLAIMNUMBERS, associatedClaimNumbers);
	                        }
					/*	if(doc.getProperties().getStringValue(IConstants.CLAIMNUMBER)!=null)
						{
						StringList totallist = Factory.StringList.createList();   
		                totallist.add(doc.getProperties().getStringValue(IConstants.CLAIMNUMBER));
		                doc.getProperties().putValue(IConstants.ASSOCIATEDCLAIMNUMBERS, totallist);     
						}*/
						doc.setUpdateSequenceNumber(null);
						doc.save(RefreshMode.REFRESH);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);

	}

	/**
	 * 
	 * @param CaseID
	 * @param queuename
	 * @param udstaskname
	 * @throws MetCaseOperationsException
	 */

	public void UDSCompletestep(String CaseID, String queuename, String udstaskname) throws MetCaseOperationsException {
		String METHOD_NAME = "UDSCompletestep";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			ObjectStore targetOS = getConnection();
			ObjectStoreReference osr = new ObjectStoreReference(targetOS);
			String processInstanceId = null;
			Case caseobject = Case.fetchInstance(osr, new Id(CaseID), null, null);
			VWSession vwSession = caseobject.getCaseType().getVWSession();
			// LOGGER.info("Session" +vwSession.getConnectionPointName());
			List taskList = caseobject.fetchTasks();
			Iterator iter = taskList.iterator();
			while (iter.hasNext()) {
				Task task = (Task) iter.next();
				String taskname = task.getName();
				TaskState state = task.getState();
				LOGGER.info("Task Status" + state);
				if (taskname.equals(udstaskname) && state.equals(TaskState.WORKING)) {
					processInstanceId = task.getProcessInstanceId();
					LOGGER.info("Wobnumber" + processInstanceId);
					WorkItem item = WorkItem.fetchInstance(vwSession, queuename, processInstanceId, osr, null);
				
					VWParticipant participant = item.getLockedUserParticipant();
					if (participant != null) {
						LOGGER.info("Participant name" + participant.getDisplayName());
						item.overrideLockStep();
						item.saveStep();
						item.completeStep();
					} else {
						item.lockStep();
						item.saveStep();
						item.completeStep();
					}
				}
			}

		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);

	}

	/**
	 * 
	 * @param caseID
	 * @param parentCaseId
	 * @throws Exception
	 *             Update CaseID
	 */
	public void UpdateCaseID(String caseID, String parentCaseId) throws Exception {
		ObjectStore targetOS = getConnection();
		String METHOD_NAME = "UpdateCaseID";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			com.filenet.api.core.Folder folder = Factory.Folder.fetchInstance(targetOS, caseID, null);
			com.filenet.api.property.Properties prop = folder.getProperties();
			FolderSet mainFolders = folder.get_SubFolders();

			String secondaryFolderName = null;
			Iterator<Folder> iterator = mainFolders.iterator();
			while (iterator.hasNext()) {

				Folder primarySubFolder = iterator.next();
				Properties prop1 = primarySubFolder.getProperties();
				prop1.putValue(parentCaseId, caseID);
				primarySubFolder.setUpdateSequenceNumber(null);
				primarySubFolder.save(RefreshMode.REFRESH);
				FolderSet subFolders = ((com.filenet.api.core.Folder) primarySubFolder).get_SubFolders();

				Iterator<Folder> iterator1 = subFolders.iterator();
				while (iterator1.hasNext()) {
					Folder secondarySubFolder = iterator1.next();
					Properties prop2 = secondarySubFolder.getProperties();
					secondaryFolderName = secondarySubFolder.get_FolderName();
					prop2.putValue(parentCaseId, caseID);
					secondarySubFolder.setUpdateSequenceNumber(null);
					secondarySubFolder.save(RefreshMode.REFRESH);
				}
			}
		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);

	}

	public void checkAndUpdateCaseId(String caseID, String parentCaseId) throws Exception {
		ObjectStore targetOS = getConnection();
		String METHOD_NAME = "UpdateCaseID";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			com.filenet.api.core.Folder folder = Factory.Folder.fetchInstance(targetOS, caseID, null);
			com.filenet.api.property.Properties prop = folder.getProperties();
			FolderSet mainFolders = folder.get_SubFolders();

			String secondaryFolderName = null;
			Iterator<Folder> iterator = mainFolders.iterator();
			while (iterator.hasNext()) {
				LOGGER.info("iNSIDE WHILE");
				Folder primarySubFolder = iterator.next();
				Properties prop1 = primarySubFolder.getProperties();
				if (prop1.getStringValue(parentCaseId) == null || prop1.getStringValue(parentCaseId) == "") {
					prop1.putValue(parentCaseId, caseID);
					primarySubFolder.setUpdateSequenceNumber(null);
					primarySubFolder.save(RefreshMode.REFRESH);
					FolderSet subFolders = ((com.filenet.api.core.Folder) primarySubFolder).get_SubFolders();

					Iterator<Folder> iterator1 = subFolders.iterator();
					while (iterator1.hasNext()) {
						Folder secondarySubFolder = iterator1.next();
						Properties prop2 = secondarySubFolder.getProperties();
						secondaryFolderName = secondarySubFolder.get_FolderName();
						prop2.putValue(parentCaseId, caseID);
						secondarySubFolder.setUpdateSequenceNumber(null);
						secondarySubFolder.save(RefreshMode.REFRESH);
					}
				} else {
					break;
				}
			}
		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);

	}

	/**
	 * to classify valid and inValid documents
	 * 
	 * @param sourceCaseFolderId
	 * @param documentType
	 * @param targetOS
	 * @return
	 * @throws Exception
	 */
	private Map<String, List<String>> classifyValidAndInvalidDocuments(String sourceCaseFolderId, String documentType,
			ObjectStore targetOS) throws MetCaseOperationsException {
		String METHOD_NAME = "classifyValidAndInvalidDocuments";

		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		List<String> valid = new ArrayList<String>();
		List<String> inValid = new ArrayList<String>();
		Map<String, List<String>> documentIDs = new HashMap<String, List<String>>();
		try {
			Folder sourcefolder = Factory.Folder.fetchInstance(targetOS, sourceCaseFolderId, null);
			DocumentSet docs = ((com.filenet.api.core.Folder) sourcefolder).get_ContainedDocuments();
			@SuppressWarnings("unchecked")
			Iterator<Document> documents = docs.iterator();
			while (documents.hasNext()) {
				Document doc = documents.next();
				LOGGER.info("Value" + doc.getProperties().get(documentType).getStringValue());
				/*
				 * LOGGER.info("true  " + doc.getProperties().get(documentType)
				 * .getStringValue().equals(IConstants.INVALID));
				 */
				if (doc.getProperties().get(documentType).getStringValue() != null) {
					if (doc.getProperties().get(documentType).getStringValue().contains(IConstants.INVALID)) {
						LOGGER.info("If condition satisfied");
						inValid.add(doc.get_Id().toString());
					} else {
						valid.add(doc.get_Id().toString());
					}
				} else {
					LOGGER.info("Else Condtion");
					valid.add(doc.get_Id().toString());
				}
			}
			documentIDs.put(IConstants.VALID, valid);

			documentIDs.put(IConstants.INVALID, inValid);

		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}

		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
		return documentIDs;

	}

	/**
	 * to move validDocuments to primaryCase
	 * 
	 * @param documentIDs
	 * @param targetCaseFolderId
	 * @param sourceCaseFolderId
	 * @param propSearchCriteria
	 * @param propCriteriaValue
	 * @param targetCaseType
	 * @param targetDocumentClass
	 * @param documentTypeProperty
	 * @param subDocumentTypeProperty
	 * @throws Exception
	 */

	private void filingValidDocuments(List<String> documentIDs, String targetCaseFolderId, String sourceCaseFolderId,
			String propSearchCriteria, String propCriteriaValue, String targetCaseType, String targetDocumentClass,
			String documentTypeProperty, String subDocumentTypeProperty, ObjectStore targetOS, String[] propArray,
			String IndexingCaseFolderID) throws MetCaseOperationsException {
		String METHOD_NAME = "filingVaildDocuments";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			if (targetCaseFolderId == null || targetCaseFolderId == "") {
				targetCaseFolderId = searchCase(propSearchCriteria, propCriteriaValue, targetOS, targetCaseType);
			}

			if (targetCaseFolderId != null) {

				String targetCaseFolderPath = null;
				Boolean flag = false;
				Folder sourcefolder = Factory.Folder.fetchInstance(targetOS, sourceCaseFolderId, null);
				Folder targetCaseFolder = Factory.Folder.fetchInstance(targetOS, targetCaseFolderId, null);
				String targetCasePath = targetCaseFolder.get_PathName();
				for (String validDocumentID : documentIDs) {
					targetCaseFolderPath = targetCasePath;
					Document doc = com.filenet.api.core.Factory.Document.fetchInstance(targetOS, validDocumentID, null);

					Properties props = doc.getProperties();
					String doctypevalue = props.getStringValue(documentTypeProperty);

					LOGGER.info("DocumentType Value---" + doctypevalue);
					LOGGER.info("SubDocumentType Value---" + props.getStringValue(subDocumentTypeProperty));

					DateFormat df = new SimpleDateFormat(IConstants.DATEFORMAT);
					String finaldates = "";
					finaldates = df.format(props.getDateTimeValue(IConstants.DATECREATED));
					// props.putValue((IConstants.DOCUMENTTITLE), finaldates);
					// //commented by 393802
					props.putValue(documentTypeProperty, "");
					// props.putValue(subDocumentTypeProperty,
					// "");
					// doc.setUpdateSequenceNumber(null);
					// doc.save(RefreshMode.REFRESH); //commented by 393802

					com.filenet.api.core.ReferentialContainmentRelationship relFrom = sourcefolder.unfile(doc);
					relFrom.save(RefreshMode.REFRESH);
					LOGGER.info("Indexing Document Removed");
					if (targetDocumentClass != null) {
						com.filenet.api.core.ReferentialContainmentRelationship relTo = targetCaseFolder.file(doc,
								AutoUniqueName.AUTO_UNIQUE, doc.get_Name(),
								DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
						relTo.save(RefreshMode.REFRESH);
						LOGGER.info("Before Change Class" + doc.get_Name());
						doc.changeClass(targetDocumentClass);

						if (propArray != null) {
						    Properties properties = doc.getProperties();
							for (String property : propArray) {
								
								LOGGER.info("Property Name" + property);
								if (!property.equals(IndexingCaseFolderID)) {
									properties.putValue(property,
											targetCaseFolder.getProperties().getStringValue(property));
								}

							}
							/*
							 * doc.getProperties().putValue(IConstants.
							 * ORIGNALASSOCCASE, targetCaseFolderId);
							 * doc.setUpdateSequenceNumber(null);
							 */
							// doc.setUpdateSequenceNumber(null);
							// doc.save(RefreshMode.REFRESH); //commented by
							// 393802
						}
					}

					LOGGER.info("Document Class Name" + doc.getClassName());
					LOGGER.info("Final Dates" + finaldates);
					Properties properties = doc.getProperties();
					String documentNotes = props.getStringValue(IConstants.DOCUMENTNOTES);
					
					properties.putValue((IConstants.DOCUMENTTITLE), finaldates); // newly
					properties.putValue(IConstants.ORIGNALASSOCCASE, targetCaseFolderId);
					LOGGER.info("Document Title " + properties.getStringValue(IConstants.DOCUMENTTITLE));
					LOGGER.info("Original Associated Case " + properties.getStringValue(IConstants.ORIGNALASSOCCASE));

					// properties.putValue(documentTypeProperty,
					// "Authorization");
					// properties.putValue(subDocumentTypeProperty,
					// "General Authorization");
					// doc.setUpdateSequenceNumber(null);
					// doc.save(RefreshMode.REFRESH);

					LOGGER.info("TargetCasefolderID --" + targetCaseFolderId);
					// LOGGER.info("orgassoccase-----CHCK");
					// doc.setUpdateSequenceNumber(null);
					doc.getProperties().putValue(documentTypeProperty, doctypevalue);
					doc.getProperties().putValue(IConstants.DOCUMENTNOTES, documentNotes);
					doc.setUpdateSequenceNumber(null);
					doc.save(RefreshMode.REFRESH);
					LOGGER.info("Document is finally saved");
					LOGGER.info("Final Doctype--" + doc.getProperties().getStringValue(documentTypeProperty));
					LOGGER.info("Sub Doctype----" + doc.getProperties().getStringValue(subDocumentTypeProperty));

					/*
					 * ReferentialContainmentRelationshipSet rcrs = doc
					 * .get_Containers(); LOGGER.info("ans----" +
					 * rcrs.isEmpty()); Iterator iter = rcrs.iterator(); while
					 * (iter.hasNext()) { ReferentialContainmentRelationship rcr
					 * = (ReferentialContainmentRelationship) iter .next();
					 * Folder folder = (Folder) rcr.get_Tail();
					 * 
					 * if(folder.get_PathName().contains(targetCaseFolderPath))
					 * { flag=true; LOGGER.info("Folder"+folder.get_PathName());
					 * } } if(flag.equals(false)) {
					 * com.filenet.api.core.ReferentialContainmentRelationship
					 * relTo = targetCaseFolder .file(doc,
					 * AutoUniqueName.AUTO_UNIQUE, doc.get_Name(),
					 * DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE)
					 * ; relTo.save(RefreshMode.REFRESH); }
					 */

				}
				DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
						ILoggerConstants.FILING_VALIDDOCUMENTS);

			}
		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
	}

	/**
	 * to search a primary case by querying claimNumber
	 * 
	 * @param propSearchCriteria
	 * @param propCriteriaValue
	 * @param objectStore
	 * @param targetCaseType
	 * @return
	 * @throws Exception
	 */
	private String searchCase(String propSearchCriteria, String propCriteriaValue, ObjectStore objectStore,
			String targetCaseType) throws MetCaseOperationsException {
		String METHOD_NAME = "searchCase";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		String caseId = null;
		try {
			if (propSearchCriteria != null) {
				SearchScope scope = new SearchScope(objectStore);
				SearchSQL sql = new SearchSQL(ILoggerConstants.SQL_SELECT + targetCaseType + ILoggerConstants.SQL_WHERE
						+ propSearchCriteria + "='" + propCriteriaValue + "'");
				LOGGER.info("sql Query : " + sql.toString());
				RepositoryRowSet rows = scope.fetchRows(sql, Integer.valueOf(10), null, Boolean.valueOf(true));
				@SuppressWarnings("rawtypes")
				Iterator<Document> itRow = rows.iterator();
				RepositoryRow row;
				while (itRow.hasNext()) {
					row = (RepositoryRow) itRow.next();
					Properties props = row.getProperties();
					@SuppressWarnings("rawtypes")
					Iterator itProp = props.iterator();
					Property prop;
					while (itProp.hasNext()) {
						prop = (Property) itProp.next();
						caseId = prop.getObjectValue().toString();
					}
				}
			}

		} catch (Exception e) {
			LOGGER.error(e);
			e.printStackTrace();
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
		return caseId;

	}

	/**
	 * to file documents in target folder and unfile from source folder
	 * 
	 * @param doc
	 *            - document object
	 * @param objectStore
	 * @param duplicateToFolderPath
	 * @param sourcefolder
	 */
	private void documentFiling(Document doc, ObjectStore objectStore, String targetCaseFolderPath, Folder sourcefolder,
			String IndexingCaseFolderID,String targetCaseType) throws MetCaseOperationsException {
		String METHOD_NAME = "documentFiling";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			if (targetCaseFolderPath != null) {
				Folder targetCaseFolder = Factory.Folder.fetchInstance(objectStore, targetCaseFolderPath, null);
				/**
				 * Below code piece is modified to resolve the invalid type document issue(RITM0698387 -  Cognos - Incorrect data on the 'New Scanned Mail' reports) in PROD
				 */
				if(IConstants.INDEXINGCASETYPE.equals(targetCaseType))
				{
				    Properties docprops = doc.getProperties();
	                docprops.putValue(IndexingCaseFolderID, targetCaseFolderPath);
	                doc.save(RefreshMode.REFRESH);
				}
				LOGGER.info("TargetCaseFolderID" + targetCaseFolderPath);
				com.filenet.api.core.ReferentialContainmentRelationship relTo = targetCaseFolder.file(doc,
						AutoUniqueName.AUTO_UNIQUE, doc.get_Name(),
						DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
				relTo.save(RefreshMode.REFRESH);

				com.filenet.api.core.ReferentialContainmentRelationship relFrom = sourcefolder.unfile(doc);
				relFrom.save(RefreshMode.REFRESH);
				DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
						ILoggerConstants.DOCUMENT_FILING);

			}
		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
	}

	/**
	 * Used to create new case
	 * 
	 * @param targetOS
	 * @param targetCaseType
	 * @param propArray
	 * @param sourcefolder
	 * @param RouteDirectToResearch
	 * @param IsCaseCreatedByIndexing
	 *            - used routing in workflow
	 * @param AssignToFromIndexer
	 *            - used for routing
	 * @return
	 * @throws Exception
	 */
	private String createNewCase(ObjectStore targetOS, String targetCaseType, String[] propArray, Folder sourcefolder,
			String RouteDirectToResearch, String originator, String AssignToFromIndexer, String IndexingStartFlag,
			String AssignTo) throws MetCaseOperationsException {
		String METHOD_NAME = "createNewCase";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		String caseId = null;
		try {

			LOGGER.info("Originator of Claim Processing " + originator);
			LOGGER.info("AssignTo value " + AssignTo);
			ObjectStoreReference osr = new ObjectStoreReference(targetOS);
			CaseType caseType = CaseType.fetchInstance(osr, targetCaseType);
			Case pendingCase = Case.createPendingInstanceFetchDefaults(caseType);
			Properties sourceFolderProperties=sourcefolder.getProperties();//declared here to avoid calling it again everywhere
			if (targetCaseType.contains(IConstants.CLAIM_INDEXING)) {

				LOGGER.info("INSIDE PENDING CASE");
				pendingCase.getProperties().putObjectValue(RouteDirectToResearch, true);
				pendingCase.getProperties().putObjectValue(IndexingStartFlag,
						sourceFolderProperties.getStringValue(IndexingStartFlag));
				LOGGER.info("AFTER PENDING CASE");
			}
			if (targetCaseType.contains(IConstants.CLAIM_PROCESSING)) {

				// pendingCase.getProperties().putObjectValue(IsCaseCreatedByIndexing,
				// true);
				pendingCase.getProperties().putObjectValue(AssignTo, originator);
				LOGGER.info("Originator of Claim Processing is set" + originator);
				LOGGER.info("AssignTo value is set " + AssignTo);
				pendingCase.getProperties().putObjectValue(AssignToFromIndexer,
						sourceFolderProperties.getStringValue(AssignToFromIndexer));
			}
			pendingCase.save(RefreshMode.REFRESH, null, null);
			caseId = pendingCase.getId().toString();
			/**
			 * Below code piece modified as per req "Duplicate claim record appeared in Case Manager  for an existing claim" in IDI Claims Phase 1.5
			 * Claim metadata will not be copied to the "Initial Claim".
			 */
			if (targetCaseType.contains(IConstants.CLAIM_INDEXING))
			{
			
			Folder pendingCaseFolder = Factory.Folder.fetchInstance(targetOS, caseId, null);

			Properties properties = pendingCaseFolder.getProperties();
			for (String property : propArray) {
				String propValue=sourceFolderProperties.getStringValue(property);//declared here to avoid calling same method again
				LOGGER.info("Properties List" + property +propValue );
				properties.putValue(property,propValue);
			}
			pendingCaseFolder.setUpdateSequenceNumber(null);
			pendingCaseFolder.save(RefreshMode.REFRESH);
			}
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.CREATE_NEW_CASE + caseId);

		}

		catch (Exception e) {
			LOGGER.error(e);
			e.printStackTrace();
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
		return caseId;

	}

	/**
	 * to move inValidDocuments to targetCase
	 * 
	 * @param documentIDs
	 * @param invalidCaseID
	 * @param caseTypeName
	 * @param targetDocumentClass
	 * @param sourceCaseFolderId
	 */

	private void filingInvalidDocuments(List<String> documentIDs, String invalidCaseID, String targetCaseType,
			String sourceCaseFolderId, ObjectStore targetOS, String[] propArray, String RouteDirectToResearch,
			String IndexingStartFlag, String IndexingCaseFolderID) throws MetCaseOperationsException {
		String METHOD_NAME = "filingInvalidDocuments";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			Folder sourcefolder = Factory.Folder.fetchInstance(targetOS, sourceCaseFolderId, null);

			if (invalidCaseID == null) {
				LOGGER.info("Inside Invalidif" + invalidCaseID);
				String caseId = createNewCase(targetOS, targetCaseType, propArray, sourcefolder, RouteDirectToResearch,
						null, null, IndexingStartFlag, null);
				invalidCaseID = caseId;
				LOGGER.info("EndofIf Invalid" + invalidCaseID);
			}
			for (String inValidDocumentID : documentIDs) {
				LOGGER.info("Inside forloop invalid documents filing" + inValidDocumentID);
				Document invalidDoc = com.filenet.api.core.Factory.Document.fetchInstance(targetOS, inValidDocumentID,
						null);
				invalidDoc.save(RefreshMode.REFRESH);

				documentFiling(invalidDoc, targetOS, invalidCaseID, sourcefolder, IndexingCaseFolderID,targetCaseType);
			}
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.FILING_INVALIDDOCUMENTS);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
	}

	/**
	 * terminate case form process engine and content engine
	 * 
	 * @param caseID
	 * @param targetOS
	 */
	public void terminateCase(String caseID) throws MetCaseOperationsException {
		String METHOD_NAME = "terminateCase";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			ObjectStore targetOS = getConnection();
			ObjectStoreReference osr = new ObjectStoreReference(targetOS);
			Case invalidCase = Case.fetchInstance(osr, new Id(caseID), null, null);
			Id caseId = invalidCase.getId();
			List taskList = invalidCase.fetchTasks();
			Iterator iter = taskList.iterator();
			while (iter.hasNext()) {
				Task task = (Task) iter.next();
				TaskState state = task.getState();
				if ((state != TaskState.COMPLETE) && (task.getProcessInstanceId() != null)
						&& (task.getDisabledState() != TaskDisabledState.DISABLED_ABORTED)) {
					task.setStopped();
					task.save(RefreshMode.REFRESH);
				}
			}
			Folder targetCaseFolder = Factory.Folder.fetchInstance(targetOS, caseId, null);
			targetCaseFolder.delete();

			targetCaseFolder.save(RefreshMode.REFRESH);
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.TERMINATE_CASE + caseID);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
	}

	/**
	 * Updating the document source property using Indexingstartflag case
	 * property
	 */
	public void updatedocumentProperty(String CaseID, String IndexingStartFlag, String Source, String flag)
			throws MetCaseOperationsException {
		String METHOD_NAME = "updateDocumentProperty";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);

		try {
			ObjectStore targetOS = getConnection();
			Folder sourcefolder = Factory.Folder.fetchInstance(targetOS, CaseID, null);
			Properties props = sourcefolder.getProperties();
			String IndexingStartFlagvalue = props.get(IndexingStartFlag).getStringValue();
			DocumentSet docs = ((com.filenet.api.core.Folder) sourcefolder).get_ContainedDocuments();
			String[] values = flag.trim().split(",");
			@SuppressWarnings("unchecked")
			Iterator<Document> documents = docs.iterator();
			while (documents.hasNext()) {
				Document doc = documents.next();
				LOGGER.info("Content ElementSize :" + doc.get_ContentElements().size());
				Properties docprops = doc.getProperties();
				docprops.putValue(IConstants.INDEXINGCASEFOLDERID, CaseID);
				for (int i = 0; i < values.length; i++) {
					LOGGER.info("IndexingStartFlagvalue" + IndexingStartFlagvalue);
					String[] splitValueArr=values[i].trim().split(":");// declared here to avoid calling the split 3 times below
					if (IndexingStartFlagvalue.equals(splitValueArr[0])) {
						docprops.putValue(Source, splitValueArr[1]);
						doc.setUpdateSequenceNumber(null);
						doc.save(RefreshMode.REFRESH);
						LOGGER.info("Updated document property " + splitValueArr[1]);
					}
				}
				/**
                 *  Below code modified for the PROD Issue Indexed documents with Incorrect Timestamp in PRIDE_claim files not in chronological order
                 *  Modified the condition contentelements size should be greater than 0 instead of 1. Due to this change, single page tiff also converted as pdf.
                 *  
                 */
				if(IndexingStartFlagvalue.equals("Scanning"))
				{
				if (doc.get_ContentElements().size() > 0) {
					getContentElement(doc);
				}
				}
				
			}

		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);

	}

	/**
	 * Updating the document source property using Indexingstartflag case
	 * property
	 */
	public void updateSourceProperty(String CaseID, String IndexingStartFlag, String Source, String Scanflag,
			String mailflag, String paramflag, String releaseflag, String Scanflagvalue, String mailflagvalue,
			String paramflagvalue, String releaseflagvalue) throws MetCaseOperationsException {
		String METHOD_NAME = "updateSourceProperty";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);

		try {
			ObjectStore targetOS = getConnection();
			Folder sourcefolder = Factory.Folder.fetchInstance(targetOS, CaseID, null);
			Properties props = sourcefolder.getProperties();
			String IndexingStartFlagvalue = props.get(IndexingStartFlag).getStringValue();
			DocumentSet docs = ((com.filenet.api.core.Folder) sourcefolder).get_ContainedDocuments();
			@SuppressWarnings("unchecked")
			Iterator<Document> documents = docs.iterator();
			while (documents.hasNext()) {
				Document doc = documents.next();
				Properties docprops = doc.getProperties();
				if (IndexingStartFlagvalue.equals(Scanflag)) {
					docprops.putValue(Source, Scanflagvalue);
				} else if (IndexingStartFlagvalue.equals(mailflag)) {
					docprops.putValue(Source, mailflagvalue);
				} else if (IndexingStartFlagvalue.equals(paramflag)) {
					docprops.putValue(Source, paramflagvalue);
				} else if (IndexingStartFlagvalue.equals(releaseflag)) {
					docprops.putValue(Source, releaseflagvalue);
				}
				doc.save(RefreshMode.REFRESH);
			}

		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);

	}
	
	
	
	/**
	 * Filing html template to case document to replacing form
	 * This method added for IDI project due to IBM Form replacement and CM property widgets are getting converted into HTML templates
	 * 
	 * 
	 * @param attachment
	 * @param caseProperties
	 * @param templatePath
	 * @param targetCaseFolderId
	 * @param documentTypeValue
	 * @param srcDocumentClassId
	 * @param targetDocumentClassId
	 * @return VWAttachment[] array of attachments
	 * @throws MetCaseOperationsException
	 */
	public VWAttachment[] filingHtmlTemplateFileToCaseDocument(VWAttachment[] attachment, String[] caseProperties,
	        String templatePath, String targetCaseFolderId, String documentTypeValue, 
	        String srcDocumentClassId, String targetDocumentClassId,String taskPropForDocId,String taskID)
	                throws MetCaseOperationsException, FileOperationsException {
	    String METHOD_NAME = "New filingHtmlTemplateFileToCaseDocument";
	    DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
	            ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
	    VWAttachment[] returnAttachment = null;
	    DocumentFilingUtil.loadMetCMProperties();
	    try {
	        ObjectStore targetOS = getConnection();
	        Document targetDoc = null;
	        String stringprodDate;
	        Document templateDoc = null;
	        boolean flag=false;
	        boolean phase12Flag=false;
	        Folder targetFolder = Factory.Folder.fetchInstance(targetOS,targetCaseFolderId, null);
	        StringBuilder docFilingFolderPath = new StringBuilder();
	        docFilingFolderPath.append(targetFolder.get_PathName()).append("/").append(documentTypeValue);
	        CmTask cmTask = Factory.CmTask.fetchInstance(targetOS, new Id(taskID), null);
	        Properties taskProps = cmTask.getProperties();
	        LOGGER.info("Checking the Template type");
	        String templatelist= DocumentFilingUtil.getProperty(IConstants.REFERALTEMPLATES);
	        String referraltempleteListphase14 = DocumentFilingUtil.getProperty(IConstants.REFERALTEMPLATESPHASE14);
	        String[] formName=templatePath.split("/");
            String currentFormName=formName[formName.length-1];
            LOGGER.info("form name" +currentFormName);
          //Commented if and else part as part of IDI Phase 1.7 Release
            //Since there are no items created before IDI Phase 1.2
            //if(templatelist.contains(currentFormName))
            //{
            String[] phase12List=templatelist.split(",");
            for(int j=0;j<phase12List.length;j++)
            {
                if(phase12List[j].equals(currentFormName))
                {
                    phase12Flag = true;
	            LOGGER.info("Template fetched from Phase12 list");
	            Date taskCreated = cmTask.get_DateCreated(); 
	            SimpleDateFormat sdf = new SimpleDateFormat(IConstants.PRODDATECHECK);
	            String[] phase14List=referraltempleteListphase14.split(",");
	            for(int i=0;i<phase14List.length;i++)
	            {
	                if(phase14List[i].equals(currentFormName))
	                {
	                    flag = true;
	                }

	            }
	            if(flag)
	            {
	                stringprodDate= DocumentFilingUtil.getProperty(IConstants.PRODUCTIONDATEPHASE14);
	                LOGGER.info("Newly added referral part of Phase 1.4");
	            }
	            else
	            {
	                stringprodDate= DocumentFilingUtil.getProperty(IConstants.PRODUCTIONDATE);
	            }
	            Date lastProdDate = sdf.parse(stringprodDate);
	            if (taskCreated.compareTo(lastProdDate) > 0) {
	                LOGGER.info("Task created after prodRelease");
	                templateDoc = Factory.Document.fetchInstance(targetOS,templatePath, null);
	                targetDoc = filingHTMLTemplate(targetOS, srcDocumentClassId,
	                        templateDoc, cmTask);
	            } else {
	                LOGGER.info("Task created before prodRelease");
	                Document doc = Factory.Document.fetchInstance(targetOS,
	                        templatePath, null);
	                VersionableSet versions = doc.get_Versions();
	                Versionable version;
	                // Iterate the set and print information about each version.
	                Iterator iter = versions.iterator();
	                while (iter.hasNext() )
	                {
	                    LOGGER.info("Entered While loop");
	                    version = (Versionable)iter.next();
	                    if(!version.get_IsCurrentVersion())
	                    {   
	                        templateDoc= (Document)version;
	                        LOGGER.info("Document Version : Major Version :" +templateDoc.get_MajorVersionNumber() + "Minor Version :" +templateDoc.get_MinorVersionNumber());
	                        if(templateDoc.get_DateCreated().compareTo(lastProdDate)<0)
	                        {
	                            targetDoc = filingHTMLTemplate(targetOS, srcDocumentClassId,
	                                    templateDoc, cmTask);
	                            break;
	                        }
	                    }

	                }

	            }
	            break;
                }
            }
	       // }
	      /*  else
	        {
	            LOGGER.info("No template checking required");
	            templateDoc = Factory.Document.fetchInstance(targetOS,templatePath, null);
	            targetDoc = filingHTMLTemplate(targetOS, srcDocumentClassId,
	                    templateDoc, cmTask);
	        }*/
            if(!phase12Flag)
            {
                LOGGER.info("No template checking required");
                templateDoc = Factory.Document.fetchInstance(targetOS,templatePath, null);
                targetDoc = filingHTMLTemplate(targetOS, srcDocumentClassId,
                        templateDoc, cmTask);
            }
	        Folder folder = Factory.Folder.fetchInstance(getConnection(),
	                docFilingFolderPath.toString(), null);
	        ReferentialContainmentRelationship rel = folder.file(targetDoc,
	                AutoUniqueName.AUTO_UNIQUE, templateDoc.get_Name(),
	                DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
	        rel.save(RefreshMode.NO_REFRESH);
	        LOGGER.info("Case property Array :" + caseProperties);
	        Properties docProperties = targetDoc.getProperties();
	        Properties targetFolderProperties = targetFolder.getProperties();
	        for (String property : caseProperties) {
	            LOGGER.info("Property name :" + property + " Value :"
	                    + targetFolderProperties.getStringValue(property));
	            docProperties.putValue(property,
	                    targetFolderProperties.getStringValue(property));
	        }
	        docProperties.putValue(IConstants.ORIGNALASSOCCASE,
	                targetCaseFolderId);
	        targetDoc.changeClass(targetDocumentClassId);
	        docProperties.putValue(IConstants.SOURCE, "Referrals");
	        targetDoc.setUpdateSequenceNumber(null);
	        targetDoc.save(RefreshMode.REFRESH);
	        LOGGER.info("Target class Filing has Completed Sucessfully");
	        taskProps.putObjectValue(taskPropForDocId, targetDoc.get_Id()
	                .toString());
	        cmTask.save(RefreshMode.REFRESH);
	        LOGGER.info("Doc Id Successfully updated to task property"
	                + taskProps.getStringValue(taskPropForDocId));
	        LOGGER.info("Add attachement Started");
	        returnAttachment = new VWAttachment[attachment.length + 1];
	        for (int i = 0; i < attachment.length; i++) {
	            returnAttachment[i] = attachment[i];
	        }

	        if (targetDoc != null) {
	            VWAttachment vwAttachent = new VWAttachment();
	            vwAttachent.setAttachmentName(targetDoc.get_Name());
	            vwAttachent.setLibraryName(targetOS.get_Name().toString());
	            vwAttachent
	            .setLibraryType(VWLibraryType.LIBRARY_TYPE_CONTENT_ENGINE);
	            vwAttachent.setType(VWAttachmentType.ATTACHMENT_TYPE_DOCUMENT);
	            VersionSeries vs = targetDoc.get_VersionSeries();
	            vwAttachent.setId(vs.get_Id().toString());
	            vwAttachent.setVersion(targetDoc.get_Id().toString());
	            returnAttachment[attachment.length] = vwAttachent;
	        }

	    } catch (Exception e) {
	        LOGGER.error(e);
	        throw new MetCaseOperationsException(e);
	    }
	    DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
	            ILoggerConstants.METHOD_EXIT + METHOD_NAME);

	    return returnAttachment;
	}


	private Document filingHTMLTemplate(ObjectStore targetOS,String srcDocumentClassId,Document templateDoc,CmTask cmTask)
	{
	    /* Change done as part of IDI 1.7 release */
	    String retrievalName = null;
        ContentElementList docContentList = templateDoc.get_ContentElements();
        if (docContentList.size() > 0) {
            
                int pageCnt = 0;
                Iterator iter = docContentList.iterator();
                while (iter.hasNext()) {
                    ContentTransfer ct = (ContentTransfer) iter.next();
                    retrievalName = ct.get_RetrievalName();
                    LOGGER.info("Retrieval name "+retrievalName);
                    
                }
          
        }
        /*End of change*/
        retrievalName=retrievalName.split("\\.")[0];
	    Document targetDoc = Factory.Document.createInstance(targetOS, srcDocumentClassId);
	    ContentElementList contentList = Factory.ContentElement.createList();
	    ContentTransfer content = Factory.ContentTransfer.createInstance();
	    content.setCaptureSource(templateDoc.accessContentStream(0));
	    content.set_RetrievalName(templateDoc.get_Name()+".html");
	    contentList.add(content);
	    targetDoc.set_ContentElements(contentList);
	    targetDoc.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
	    Properties properties = targetDoc.getProperties();
	    Properties taskProps = cmTask.getProperties();
	    DateFormat taskCreatedDateFormat = new SimpleDateFormat(IConstants.DATEFORMAT);
        DateFormat completedDateFormat = new SimpleDateFormat(IConstants.DATEFORMAT);
        Date todaydate = new Date();
        LOGGER.info("Format complete date" +completedDateFormat.format(todaydate));
        /* Change done as part of IDI 1.7 release */
        String templateName=completedDateFormat.format(todaydate)+"-"+retrievalName+"-"+taskCreatedDateFormat.format(taskProps.getDateTimeValue(IConstants.DATECREATED));
        LOGGER.info("Document Title "+templateName);
        /* End of change*/
       
	    properties.putValue("DocumentTitle", templateName);
	    targetDoc.set_MimeType("text/html");
	    targetDoc.setUpdateSequenceNumber(null);
	    targetDoc.save(RefreshMode.REFRESH);


	    LOGGER.info("Source class Filing has Completed Sucessfully");
	    return targetDoc;

	}

	/**
	 * This method will populate the CM properties to a HTML template which has same properties defined as symbolic names
	 * It will also take care of conversion based on data type
	 * @param templatePath
	 * @param fieldTypes - possible values - String,Date,Checkbox,MultiValue
	 * @param symbolicNames
	 * @param values
	 * @param docId
	 * @throws MetCaseOperationsException
	 */
	   public void populateHtmlFormValues(String[] fieldTypes,String[] symbolicNames,String[] values,String docId) throws MetCaseOperationsException{
	        String METHOD_NAME = "populateHtmlFormValues";
	        DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
	                ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
	        try {
	            ObjectStore targetOS = getConnection();
	            LOGGER.info("Document ID :"+docId);
	            Document doc = Factory.Document.fetchInstance(targetOS,
	                    docId, null);           
	            LOGGER.info("Document Name :"+doc.get_Name());
	            // Check out the Document object and save it.
	            if (doc.get_VersionStatus().getValue() != VersionStatus.RESERVATION_AS_INT) {
	                doc.checkout(com.filenet.api.constants.ReservationType.EXCLUSIVE, null, doc.getClassName(),
	                        doc.getProperties());
	                doc.setUpdateSequenceNumber(null);
	                doc.save(RefreshMode.REFRESH);
	            }
	            org.jsoup.nodes.Document htmlDoc = Jsoup.parse(doc.accessContentStream(0), "UTF-8", "");
	            int multiValueRowCount = 1;
	            for(int i=0;i<symbolicNames.length;i++){
	                LOGGER.debug(symbolicNames[i]+":"+values[i]);
	                Element element = htmlDoc.getElementById(symbolicNames[i]);
	                LOGGER.debug(element);
	                if(fieldTypes[i].equalsIgnoreCase("Date")&& values[i]!=null && !values[i].isEmpty())
	                {
	                    element.text(DocumentFilingUtil.getTimeInUTCTimeZone(values[i], IConstants.UTC_DATEFORMAT));
	                }else if(fieldTypes[i].equalsIgnoreCase("Checkbox"))
	                {
	                    Element checkBoxLbl = htmlDoc.getElementById(symbolicNames[i]);
	                    LOGGER.debug("Checkbox Element"+checkBoxLbl);
	                    if(values[i]!=null && values[i].equalsIgnoreCase("true")){
	                        checkBoxLbl.child(0).text("X");
	                    }
	                } else if (fieldTypes[i].equalsIgnoreCase("MultiValue")) {
	                    LOGGER.debug("MultiValue :"+values[i]);
	                    Element multiValueElement = htmlDoc.getElementById("MultiValueHeader");
	                    multiValueElement.appendElement("td").attr("id", "cellborder").text(symbolicNames[i]);
	                    String[] multiValueArray = values[i].split(",");

	                    for (int indx = 0; indx < multiValueArray.length; indx++) {
	                        if (multiValueRowCount == 1) {
	                            if (multiValueArray[indx] != null && !multiValueArray[indx].isEmpty()) {
	                                multiValueElement.parent().appendElement("tr").attr("id", "row" + (indx + 1))
	                                        .appendElement("td").attr("id", "cellborder")
	                                        .attr("style", "padding-right: 1px; padding-bottom: 1px;").appendElement("p")
	                                        .text(multiValueArray[indx]);
	                            } else {
	                                multiValueElement.parent().appendElement("tr").attr("id", "row" + (indx + 1))
	                                        .appendElement("td").attr("id", "cellborder")
	                                        .attr("style", "padding-right: 1px; padding-bottom: 1px;")
	                                        .text(multiValueArray[indx]);
	                            }
	                        } else {
	                            if (multiValueArray[indx] != null && !multiValueArray[indx].isEmpty()) {
	                                multiValueElement.parent().getElementById("row" + String.valueOf(indx + 1))
	                                        .appendElement("td").attr("id", "cellborder")
	                                        .attr("style", "padding-right: 1px; padding-bottom: 1px;").appendElement("p")
	                                        .text(multiValueArray[indx]);
	                            } else {
	                                multiValueElement.parent().getElementById("row" + String.valueOf(indx + 1))
	                                        .appendElement("td").attr("id", "cellborder")
	                                        .attr("style", "padding-right: 1px; padding-bottom: 1px;")
	                                        .text(multiValueArray[indx]);
	                            }

	                        }
	                    }
	                    multiValueRowCount = multiValueRowCount + 1;
	                } 
	                else{
	                    element.text(values[i]);
	                }
	                
	            }
	            Document reservation = (Document) doc.get_Reservation();
	            InputStream inputstreams = new ByteArrayInputStream(htmlDoc.toString().getBytes());
	            ContentElementList contentList = null;
	            contentList = Factory.ContentElement.createList();

	            ContentTransfer ct = Factory.ContentTransfer.createInstance();
	            ct.setCaptureSource(inputstreams);
	            ct.set_RetrievalName(doc.get_Name() + ".html");
	            ct.set_ContentType("text/html");
	            contentList.add(ct);
	            reservation.set_ContentElements(contentList);
	            reservation.setUpdateSequenceNumber(null);
	            reservation.save(RefreshMode.REFRESH);
	            reservation.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
	            reservation.setUpdateSequenceNumber(null);
	            reservation.save(RefreshMode.REFRESH);
	            LOGGER.info(doc.getProperties().getStringValue(IConstants.SOURCE));
	            LOGGER.info(reservation.get_Id());
	        } catch (Exception e) {
	            LOGGER.error(e);
	            throw new MetCaseOperationsException(e);
	        }
	        
	        DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
	                ILoggerConstants.METHOD_EXIT + METHOD_NAME);
	    }


	private void getContentElement(Document doc) throws MetCaseOperationsException {
		String METHOD_NAME = "getContentElement";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		try {
			ContentElementList docContentList;
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			RandomAccessFileOrArray tiffImg = null;
			InputStream stream = null;
			com.lowagie.text.Document document = null;
			Image img = null;
			float pageHeight;
			float pageWidth;
			document = new com.lowagie.text.Document(com.lowagie.text.PageSize.A4);
			PdfWriter.getInstance(document, baos);
			//Included below line to set default margin related to defect # 46935 (Truncation)  
			document.setMargins(0, 0, 0, 0);
			document.open();
			docContentList = doc.get_ContentElements();
	
			 /**
             *  Below code modified for the PROD Issue Indexed documents with Incorrect Timestamp in PRIDE_claim files not in chronological order
             *  Modified the condition contentelements size should be greater than 0 instead of 1. Due to this change, single page tiff also converted as pdf.
             *  
             */
			if (docContentList.size() > 0) {
				try {
					int pageCnt = 0;
					Iterator iter = docContentList.iterator();
					while (iter.hasNext()) {
						ContentTransfer ct = (ContentTransfer) iter.next();
						LOGGER.info("Document Name:" + doc.get_Name() + " Content Type :" + ct.get_ContentType());
						if (ct.get_ContentType().equalsIgnoreCase("image/tiff")) {
							ByteArrayInputStream bArrayReader = new ByteArrayInputStream(
									generateTiffToOutPutStream(ct.accessContentStream(), pageCnt + 1).toByteArray());
							tiffImg = new RandomAccessFileOrArray(bArrayReader);
							img = TiffImage.getTiffImage(tiffImg, 1);
							/* pageHeight = document.getPageSize().getHeight() / img.getHeight() * 98;
                            pageWidth = document.getPageSize().getWidth() / img.getWidth() * 98;*/
							//Change made from 98 to 100 related to defect # 46935 (Truncation)  
							pageHeight = document.getPageSize().getHeight() / img.getHeight() * 100;
							pageWidth = document.getPageSize().getWidth() / img.getWidth() * 100;
							img.scalePercent(pageWidth, pageHeight);
							document.add(img);
							document.newPage();
							bArrayReader.close();
							pageCnt++;
						} else if (ct.get_ContentType().equalsIgnoreCase("image/jpeg")) {
							BufferedImage bufferedImage = generateJpeg(ct.accessContentStream(), document);
							img = Image.getInstance(bufferedImage, null);
							document.add(img);
							document.newPage();
							pageCnt++;
						}	
					}
					if (document != null) {
                        document.close();
                         /**
                         *  Below code modified for the PROD Issue Indexed documents with Incorrect Timestamp in PRIDE_claim files not in chronological order
                         *  Modified the condition pageCnt size should be greater than 0 instead of 1. 
                         *  
                         */
                        if (pageCnt > 0) {
                        
                            updateContentElement(doc, baos.toByteArray());
                        }
                    }
                    
					
					
				} catch (Exception e) {
					LOGGER.error(e);
					throw new MetCaseOperationsException(e);
				} finally {
					try {
						baos.flush();
						baos.close();
					} catch (Exception ie) {
						LOGGER.error(ie);
						throw new MetCaseOperationsException(ie);
					}
				}
			}

		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
	}

	private ByteArrayOutputStream generateTiffToOutPutStream(InputStream in, int pageNumber)
			throws MetCaseOperationsException {
		ByteArrayOutputStream baos;
		try {
			String METHOD_NAME = "generateTiffToOutPutStream";
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
			SeekableStream st;
			BufferedImage image;

			st = new MemoryCacheSeekableStream(in);

			TIFFDecodeParam param = null;
			int imageToLoad = 0;
			ImageDecoder dec = ImageCodec.createImageDecoder("tiff", st, param);
			RenderedImage img = dec.decodeAsRenderedImage(imageToLoad);
			image = convertRenderedImageToBufferedImage(img);
			baos = new ByteArrayOutputStream();

			TIFFEncodeParam paramsOut = new TIFFEncodeParam();

			paramsOut.setCompression(TIFFEncodeParam.COMPRESSION_NONE);

			ImageEncoder encoder = ImageCodec.createImageEncoder("TIFF", baos, paramsOut);

			encoder.encode(image);
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.METHOD_EXIT + METHOD_NAME);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		return baos;
	}

	private BufferedImage generateJpeg(InputStream in, com.lowagie.text.Document documents)
			throws MetCaseOperationsException {
		String METHOD_NAME = "generateJpeg";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		BufferedImage resizedImage;
		try {
			SeekableStream st;
			BufferedImage image;
			st = new MemoryCacheSeekableStream(in);
			JPEGDecodeParam param = null;
			int imageToLoad = 0;
			ImageDecoder dec = ImageCodec.createImageDecoder("jpeg", st, param);
			RenderedImage img = dec.decodeAsRenderedImage(imageToLoad);
			image = convertRenderedImageToBufferedImage(img);
			 /* int pageHeight = (int) (documents.getPageSize().getHeight()-75);
            int pageWidth = (int) (documents.getPageSize().getWidth()-75);*/
            //Removed -75 scaling related to defect # 46935 (Truncation)   
			int pageHeight = (int) (documents.getPageSize().getHeight());
			int pageWidth = (int) (documents.getPageSize().getWidth());
			resizedImage = new BufferedImage(pageWidth, pageHeight, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = resizedImage.createGraphics();
			g.setComposite(AlphaComposite.Src);
			g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
			g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			g.drawImage(image, 0, 0, pageWidth, pageHeight, null);
			g.dispose();
			DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
					ILoggerConstants.METHOD_EXIT + METHOD_NAME);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new MetCaseOperationsException(e);
		}
		return resizedImage;
	}

	private BufferedImage convertRenderedImageToBufferedImage(RenderedImage renderedImage) {
		String METHOD_NAME = "convertRenderedImageToBufferedImage";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		ColorModel cm = renderedImage.getColorModel();
		int width = renderedImage.getWidth();
		int height = renderedImage.getHeight();
		WritableRaster raster = cm.createCompatibleWritableRaster(width, height);
		boolean isAlphaPremultiplied = cm.isAlphaPremultiplied();
		Hashtable<String, Object> properties = new Hashtable<String, Object>();
		String[] keys = renderedImage.getPropertyNames();
		if (keys != null) {
			for (int i = 0; i < keys.length; i++) {
				properties.put(keys[i], renderedImage.getProperty(keys[i]));
			}
		}
		BufferedImage result = new BufferedImage(cm, raster, isAlphaPremultiplied, properties);
		renderedImage.copyData(raster);
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
		return result;
	}

	private void updateContentElement(Document doc, byte[] pdfByte) {
		String METHOD_NAME = "updateContentElement";
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
		if (doc.get_VersionStatus().getValue() != VersionStatus.RESERVATION_AS_INT) {
			doc.checkout(com.filenet.api.constants.ReservationType.EXCLUSIVE, null, doc.getClassName(),
					doc.getProperties());
			doc.setUpdateSequenceNumber(null);
			doc.save(RefreshMode.REFRESH);
		}

		Document reservation = (Document) doc.get_Reservation();
		InputStream inputstreams = new ByteArrayInputStream(pdfByte);
		ContentElementList contentList = null;
		contentList = Factory.ContentElement.createList();

		ContentTransfer ct = Factory.ContentTransfer.createInstance();
		ct.setCaptureSource(inputstreams);
		ct.set_RetrievalName(doc.get_Name() + ".pdf");
		ct.set_ContentType("application/pdf");
		contentList.add(ct);
		reservation.set_ContentElements(contentList);
		reservation.setUpdateSequenceNumber(null);
		reservation.save(RefreshMode.REFRESH);
		reservation.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
		reservation.setUpdateSequenceNumber(null);
		reservation.save(RefreshMode.REFRESH);
		LOGGER.info("Document Reservation ID :" + reservation.get_Id());
		DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
				ILoggerConstants.METHOD_EXIT + METHOD_NAME);
	}
	
	   /**
     * This method is copy of populateHtmlFormValues method. It is exposed in the field general task. Multivalue property logic has specially handled here. 
     * @param taskId
     * @param caseId
     * @param fieldTypes - possible values - String,Date,Checkbox,MultiValue
     * @param symbolicNames
     * @param values
     * @param docId
     * @throws MetCaseOperationsException
     */
       public void populateHtmlWithMultiValuedFormValues(String taskId,String caseId,String[] fieldTypes,String[] symbolicNames,String[] values,String docId) throws MetCaseOperationsException{
            String METHOD_NAME = "populateHtmlWithMultiValuedFormValues";
            DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
                    ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
            try {
                ObjectStore targetOS = getConnection();
                ObjectStoreReference osr = new ObjectStoreReference(targetOS);
                LOGGER.info("Document ID :"+docId);
                Document doc = Factory.Document.fetchInstance(targetOS,
                        docId, null);           
                LOGGER.info("Document Name :"+doc.get_Name());
                // Check out the Document object and save it.
                if (doc.get_VersionStatus().getValue() != VersionStatus.RESERVATION_AS_INT) {
                    doc.checkout(com.filenet.api.constants.ReservationType.EXCLUSIVE, null, doc.getClassName(),
                            doc.getProperties());
                    doc.setUpdateSequenceNumber(null);
                    doc.save(RefreshMode.REFRESH);
                }
                org.jsoup.nodes.Document htmlDoc = Jsoup.parse(doc.accessContentStream(0), "UTF-8", "");
                int multiValueRowCount = 1;
                for(int i=0;i<symbolicNames.length;i++){
                    LOGGER.debug(symbolicNames[i]+":"+values[i]);
                    Element element = htmlDoc.getElementById(symbolicNames[i]);
                    LOGGER.debug(element);
                    if(fieldTypes[i].equalsIgnoreCase("Date")&& values[i]!=null && !values[i].isEmpty())
                    {
                        element.text(DocumentFilingUtil.getTimeInUTCTimeZone(values[i], IConstants.UTC_DATEFORMAT));
                    }else if(fieldTypes[i].equalsIgnoreCase("Checkbox"))
                    {
                        Element checkBoxLbl = htmlDoc.getElementById(symbolicNames[i]);
                        LOGGER.debug("Checkbox Element"+checkBoxLbl);
                        if(values[i]!=null && values[i].equalsIgnoreCase("true")){
                            checkBoxLbl.child(0).text("X");
                        }
                    } else if (fieldTypes[i].equalsIgnoreCase("MultiValue")) {
                        LOGGER.debug("MultiValue :"+values[i]);
                        Element multiValueElement = htmlDoc.getElementById("MultiValueHeader");
                        String propertyValues []=symbolicNames[i].split(":");
                        String displayName=propertyValues[0];
                        String symbolicName=propertyValues[1];
                        multiValueElement.appendElement("td").attr("id", "cellborder").text(displayName);
                        /**
                         * Changes has been done to get the multivalue property values from the task object due to 
                         * the PROD Defect RITM0584659/TASK0367908 - Document Search ("BookView") is unaccessible
                         */
                        Task task = Task.fetchInstance(osr, new Id(taskId));  
                        List<String>  multiValueArray =  (List<String>) task.getProperties().get(symbolicName).getValue();
                        for (int indx = 0; indx < multiValueArray.size(); indx++) {
                            LOGGER.debug("List of value" +multiValueArray.get(indx));
                            if (multiValueRowCount == 1) {
                                if (multiValueArray.get(indx) != null && !multiValueArray.get(indx).isEmpty()) {
                                    multiValueElement.parent().appendElement("tr").attr("id", "row" + (indx + 1))
                                            .appendElement("td").attr("id", "cellborder")
                                            .attr("style", "padding-right: 1px; padding-bottom: 1px;").appendElement("p")
                                            .text(multiValueArray.get(indx));
                                } else {
                                    multiValueElement.parent().appendElement("tr").attr("id", "row" + (indx + 1))
                                            .appendElement("td").attr("id", "cellborder")
                                            .attr("style", "padding-right: 1px; padding-bottom: 1px;")
                                            .text(multiValueArray.get(indx));
                                }
                            } else {
                                if (multiValueArray.get(indx) != null && !multiValueArray.get(indx).isEmpty()) {
                                    multiValueElement.parent().getElementById("row" + String.valueOf(indx + 1))
                                            .appendElement("td").attr("id", "cellborder")
                                            .attr("style", "padding-right: 1px; padding-bottom: 1px;").appendElement("p")
                                            .text(multiValueArray.get(indx));
                                } else {
                                    multiValueElement.parent().getElementById("row" + String.valueOf(indx + 1))
                                            .appendElement("td").attr("id", "cellborder")
                                            .attr("style", "padding-right: 1px; padding-bottom: 1px;")
                                            .text(multiValueArray.get(indx));
                                }

                            }
                        }
                        multiValueRowCount = multiValueRowCount + 1;
                    } 
                    else{
                        element.text(values[i]);
                    }
                    
                }
                Document reservation = (Document) doc.get_Reservation();
                InputStream inputstreams = new ByteArrayInputStream(htmlDoc.toString().getBytes());
                ContentElementList contentList = null;
                contentList = Factory.ContentElement.createList();

                ContentTransfer ct = Factory.ContentTransfer.createInstance();
                ct.setCaptureSource(inputstreams);
                ct.set_RetrievalName(doc.get_Name() + ".html");
                ct.set_ContentType("text/html");
                contentList.add(ct);
                reservation.set_ContentElements(contentList);
                reservation.setUpdateSequenceNumber(null);
                reservation.save(RefreshMode.REFRESH);
                reservation.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
                reservation.setUpdateSequenceNumber(null);
                reservation.save(RefreshMode.REFRESH);
                LOGGER.info(doc.getProperties().getStringValue(IConstants.SOURCE));
                LOGGER.info(reservation.get_Id());
            } catch (Exception e) {
                LOGGER.error(e);
                throw new MetCaseOperationsException(e);
            }
            
            DocumentFilingUtil.logtheMessage(LOGGER, ILoggerConstants.LOGGER_LEVEL_INFO,
                    ILoggerConstants.METHOD_EXIT + METHOD_NAME);
        }
       
       public void deleteCaseComments(String annotationID) throws Exception
       {
           String METHOD_NAME = "deleteCaseComments";
           DocumentFilingUtil.logtheMessage(LOGGER,
                   ILoggerConstants.LOGGER_LEVEL_INFO,
                   ILoggerConstants.METHOD_ENTRY + METHOD_NAME);

           try{
               ObjectStore targetOS=getConnection();
               if (annotationID != null) 
               {
                   Id objId = null;
                   if(annotationID instanceof String )
                       objId=new Id(annotationID);
                   
                   Annotation annObject = Factory.Annotation.fetchInstance(targetOS, objId, null);
                   annObject.delete();
                   annObject.save(RefreshMode.NO_REFRESH);
               }
           }
           catch(Exception e){

               LOGGER.error(e);
               throw new DETCaseOperationsException(e);
           }
           DocumentFilingUtil.logtheMessage(LOGGER,
                   ILoggerConstants.LOGGER_LEVEL_INFO,
                   ILoggerConstants.METHOD_EXIT + METHOD_NAME);


       } 

}
