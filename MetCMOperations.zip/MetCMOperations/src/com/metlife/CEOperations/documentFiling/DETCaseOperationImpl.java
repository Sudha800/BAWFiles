package com.metlife.CEOperations.documentFiling;

import java.util.List;
import javax.security.auth.Subject;
import org.apache.log4j.Logger;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.Annotation;
import com.filenet.api.core.Connection;
import com.filenet.api.core.Domain;
import com.filenet.api.core.EntireNetwork;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.util.Id;
import com.filenet.api.util.UserContext;
import com.ibm.casemgmt.api.Case;
import com.ibm.casemgmt.api.Comment;
import com.ibm.casemgmt.api.context.CaseMgmtContext;
import com.ibm.casemgmt.api.context.SimpleP8ConnectionCache;
import com.ibm.casemgmt.api.context.SimpleVWSessionCache;
import com.ibm.casemgmt.api.objectref.ObjectStoreReference;
import com.metlife.CEOperations.documentFiling.Constants.IConstants;
import com.metlife.CEOperations.documentFiling.Constants.ILoggerConstants;
import com.metlife.CEOperations.documentFiling.Exceptions.DETCaseOperationsException;
import com.metlife.CEOperations.documentFiling.Util.DocumentFilingUtil;
import filenet.vw.api.VWSession;
import filenet.vw.integrator.CMUserContext;
import filenet.vw.server.Configuration;
import filenet.vw.server.VWLoginModule;

public class DETCaseOperationImpl {

    private static final Logger LOGGER =Logger.getLogger(DETCaseOperationImpl.class);

    public static boolean log4jInitFlag;
    
    public DETCaseOperationImpl() throws Exception {

        if (!log4jInitFlag) {
            DocumentFilingUtil.loadLog4j();
            log4jInitFlag = true;
        }


    }
    private ObjectStore getConnection() throws Exception {

        String METHOD_NAME = "getConnection";
        DocumentFilingUtil.logtheMessage(LOGGER,
                ILoggerConstants.LOGGER_LEVEL_INFO,
                ILoggerConstants.METHOD_ENTRY + METHOD_NAME);
        UserContext old = UserContext.get();
        CaseMgmtContext oldCmc = null;
        Subject sub = CMUserContext.getSubject();
        String ceURI = null;
        try {
            VWSession vwSession = VWLoginModule.getSession();
            String OSSymbolicName = vwSession.getObjectStoreSymbolicName();
            ceURI = Configuration.GetCEURI(null, null);
            Connection connection = Factory.Connection.getConnection(ceURI);
            UserContext uc = new UserContext();
            uc.pushSubject(sub);
            UserContext.set(uc);
            EntireNetwork entireNetwork = Factory.EntireNetwork.fetchInstance(
                    connection, null);
            if (entireNetwork == null) {
                Exception e = new Exception();
                throw e;
            }

            Domain domain = entireNetwork.get_LocalDomain();
            ObjectStore targetOS = (ObjectStore) domain.fetchObject(
                    IConstants.OBJECT_STORE, OSSymbolicName, null);
            SimpleVWSessionCache vwSessCache = new SimpleVWSessionCache();
            CaseMgmtContext cmc = new CaseMgmtContext(vwSessCache,
                    new SimpleP8ConnectionCache());

            oldCmc = CaseMgmtContext.set(cmc);
            return targetOS;
        } catch (Exception e) {

            LOGGER.error(e);
            throw new DETCaseOperationsException(e);

        } finally {
            if (oldCmc != null) {
                CaseMgmtContext.set(oldCmc);
            }
            if (old != null) {
                UserContext.set(old);
            }
            DocumentFilingUtil.logtheMessage(LOGGER,
                    ILoggerConstants.LOGGER_LEVEL_INFO,
                    ILoggerConstants.METHOD_EXIT + METHOD_NAME);
        }
    }
    
    public void deleteCaseComments(String annotationID) throws Exception
    {
        String METHOD_NAME = "getCaseComments";
        DocumentFilingUtil.logtheMessage(LOGGER,
                ILoggerConstants.LOGGER_LEVEL_INFO,
                ILoggerConstants.METHOD_ENTRY + METHOD_NAME);

        try{
            ObjectStore targetOS=getConnection();
            if (annotationID != null) 
            {
                Id objId = null;
                if(annotationID instanceof String )
                    objId=new Id(annotationID);
                
                Annotation annObject = Factory.Annotation.fetchInstance(targetOS, objId, null);
                annObject.delete();
                annObject.save(RefreshMode.NO_REFRESH);
            }
        }
        catch(Exception e){

            LOGGER.error(e);
            throw new DETCaseOperationsException(e);
        }
        DocumentFilingUtil.logtheMessage(LOGGER,
                ILoggerConstants.LOGGER_LEVEL_INFO,
                ILoggerConstants.METHOD_EXIT + METHOD_NAME);


    } 

   

}
