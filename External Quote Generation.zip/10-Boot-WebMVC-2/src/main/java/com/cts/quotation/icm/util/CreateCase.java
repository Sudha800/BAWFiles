package com.cts.quotation.icm.util;

import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.ObjectStore;
import com.ibm.casemgmt.api.Case;
import com.ibm.casemgmt.api.CaseType;
import com.ibm.casemgmt.api.constants.ModificationIntent;
import com.ibm.casemgmt.api.objectref.ObjectStoreReference;

public class CreateCase {

	public String createCaseCM(String firstName, String lastName,String ssn,double beneAmount,String beneType,String brokerName,String brokerEmail) {
		ObjectStore targetOs = CaseManagerConnection.getConnection();
		ObjectStoreReference targetOsRef = new ObjectStoreReference(targetOs);
		CaseType caseType = CaseType.fetchInstance(targetOsRef, "DEMO_NewBusiness");
		Case pendingCase = Case.createPendingInstance(caseType);
		pendingCase.getProperties().putObjectValue("DEMO_FirstName", firstName);
		pendingCase.getProperties().putObjectValue("DEMO_LastName", lastName);
		pendingCase.getProperties().putObjectValue("DEMO_SSN", ssn);
		pendingCase.getProperties().putObjectValue("DEMO_BenefitAmount", beneAmount);
		pendingCase.getProperties().putObjectValue("DEMO_BenefitType", beneType);
		pendingCase.getProperties().putObjectValue("DEMO_BrokerName", brokerName);
		pendingCase.getProperties().putObjectValue("DEMO_BrokerEmail", brokerEmail);
		pendingCase.save(RefreshMode.REFRESH, null, ModificationIntent.MODIFY);
		String caseId = pendingCase.getId().toString();
		//System.out.println(caseId);
		return caseId;
	}
}

