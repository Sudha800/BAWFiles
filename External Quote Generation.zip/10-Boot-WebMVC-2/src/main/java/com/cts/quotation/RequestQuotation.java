package com.cts.quotation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RequestQuotation {

	public static void main(String[] args) {
		SpringApplication.run(RequestQuotation.class, args);
	}

}
