package com.cts.quotation.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.quotation.icm.util.CreateCase;

@Controller
public class QuotationController {

	@RequestMapping("/")
	public String welcome() {
		return "index";
	}

	// load product form

	@RequestMapping("/createCaseForm")
	public String loadQuotationForm() {
		return "caseDetailForm";
	}

	// create new quote
	@RequestMapping("/generateQuote")
	public ModelAndView generateQuote(@RequestParam("firstName") String firstName, @RequestParam("lastName") String lastName,
			@RequestParam("ssn") String ssn, @RequestParam("beneAmount") double beneAmount,@RequestParam("beneType") String beneType,@RequestParam("brokerName") String brokerName,@RequestParam("brokerEmail") String brokerEmail) {
		CreateCase cs = new CreateCase();
		String caseID=cs.createCaseCM(firstName, lastName,ssn,beneAmount,beneType,brokerName,brokerEmail);
		ModelAndView model =new ModelAndView();
		model.setViewName("success");
		model.addObject("msg", "Case has been created successfully. Case ID is "+ caseID);
		
		
		//ps.saveProduct(prod);
		return model;
	}	

}
